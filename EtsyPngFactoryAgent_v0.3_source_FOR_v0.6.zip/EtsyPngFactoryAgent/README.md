# PNG Factory Agent v0.13-test

Samsung/Android üzerinde ChatGPT popup penceresiyle Etsy PNG üretim akışını yöneten test uygulaması.

## v0.13
- Ürün kimliği artık yalnız `P0001` değildir. Uygulama içinde ürün adı `P0001 · Niş · Alt niş` olarak gösterilir.
- Ürün klasörü deterministik olarak `P0001__Niş__Alt_Niş` biçiminde oluşturulur.
- Final ZIP bu klasörde `P0001__Niş__Alt_Niş__SELLER_BUNDLE.zip` adıyla kaydedilir.
- Tamamlanma doğrulaması yalnız o ürünün niş+alt niş adına ait standart final ZIP üzerinden yapılır; başka ürünün ZIP'i tamamlanma kanıtı sayılmaz.
- Download klasöründeki kaynak ZIP'in özgün adı ne olursa olsun ürün arşivinde standart ada çevrilir.
- Son tamamlanan ürün kartında P numarası, niş, alt niş ve kaydedilen ZIP adı birlikte gösterilir.
- v0.12'nin aktif/yarım ürün state'i yükseltmede korunur; isim değişikliği mevcut üretimi sıfırlamaz.

## Korunan v0.12 state makinesi
- Final ZIP fiziksel olarak Download klasöründe görülmeden ve hedef ürün klasöründe doğrulanmadan yeni ürüne geçilmez.
- Uygulama veya ChatGPT kapanırsa aktif ürün korunur ve `Üretime devam et` ile aynı ürün kontrol edilerek sürdürülür.
- ChatGPT yanıtında geçici olarak Dur/Çalışıyor kontrolü kaybolsa bile ürün tamamlandı varsayılmaz; final ZIP beklenir.
- Ekran kilitliyken state kaybolmaz. Android güvenli kilidi otomatik atlanmaz; kilit açıldığında aynı üründen devam edilir.
