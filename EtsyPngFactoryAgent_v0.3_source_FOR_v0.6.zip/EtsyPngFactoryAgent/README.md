# PNG Factory Agent v0.6 — Popup Engine

Samsung A36 test build.

## Amaç
ChatGPT'yi Samsung **Açılır görünüm (Pop-up view)** penceresinde ekranda küçük tutarken, ana ekranda kurye uygulamasını kullanmaya devam etmek. Accessibility servisi `getWindows()` ile yalnız `com.openai.chatgpt` penceresinin kök ağacını bulur; aktif pencerenin kurye uygulaması olması otomasyonu durdurmaz.

## Test akışı
1. Ürün ve ChatGPT indirme klasörlerini seç.
2. PNG Factory Agent erişilebilirlik servisini aç.
3. ChatGPT'yi Samsung Açılır görünümde aç ve küçültmeden görünür bırak. Mesaj alanı görülebilecek kadar büyük olması önerilir.
4. Kurye uygulamasını ana alana getir.
5. Agent'ta `SÜREKLİ ÜRETİMİ BAŞLAT` de.
6. Bildirim `Popup` durumlarıyla ilerlemeli. Büyük sorunda durup uyarı verir.

## Düşük güç yaklaşımı
- Yalnız ChatGPT accessibility olayları dinlenir.
- OCR/sürekli screenshot yok.
- 6 saniyelik hafif heartbeat yalnız fabrika aktifken kullanılır.
- Başka uygulamaların accessibility düğümlerine tıklanmaz.
