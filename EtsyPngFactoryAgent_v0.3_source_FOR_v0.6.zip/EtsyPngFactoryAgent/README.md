# PNG Factory Agent v0.11-test

Samsung/Android üzerinde ChatGPT popup penceresiyle Etsy PNG üretim akışını yöneten test uygulaması.

## v0.11
- Ana ekran sadeleştirildi ve canlı üretim panosuna dönüştürüldü.
- Teknik state adları kullanıcıya gösterilmiyor.
- Aktif ürün numarası, niş/alt niş, üretim aşaması, geçen süre, limit bekleme süresi ve son tamamlanan ürün tek ekrandan izleniyor.
- Gereksiz kurulum butonları ana ekrandan kaldırıldı; klasörler, erişilebilirlik ve tanı verisi tek `Ayarlar` menüsünde.
- Ana kontroller yalnız bağlama göre gösteriliyor: Başlat veya Duraklat/Durdur.
- Ekran açıkken durum her saniye güncellenir; servis durum değişiklikleri anında yansır.
- Üretim motoru v0.10 davranışını korur: otomatik Samsung popup açma/kapatma, eski iş kurtarma yok, ürün başına download baseline.
