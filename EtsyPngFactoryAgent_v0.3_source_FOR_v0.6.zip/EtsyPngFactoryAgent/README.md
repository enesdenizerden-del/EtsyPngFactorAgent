# PNG Factory Agent v0.10 — Auto Popup

- Starting continuous production automatically launches ChatGPT and tries to place it into Samsung Pop-up view.
- If public launch bounds are ignored by One UI, Accessibility automates Recents -> ChatGPT -> Open in pop-up view.
- Normal production touches only the visible ChatGPT popup window. System UI/launcher access is used only during popup open/close.
- Pressing Stop requests ChatGPT popup closure too.
- If the PNG Factory Agent task is actually removed from Recents, the accessibility heartbeat stops the factory and closes ChatGPT popup. Merely switching to another app does not stop production.
- Old/partial jobs are not recovered on upgrade.
- Factory status is no longer inferred from stale historical “Çalışıyor / Gönderilmeyi bekliyor” text. Active generation is identified from the live Stop control and queued state is scoped to the latest product command.
- Download snapshot and attachment baseline are captured once for each new product.
- Newly created files are expected in the selected Android Download folder, then copied to `P0001_<subniche>/...` under the chosen product root.
