package com.deniz.etsypngfactory;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class ControlReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String a = intent.getAction();
        SharedPreferences p = Prefs.get(context);
        if ("OPEN_CHATGPT".equals(a)) {
            if (!AppLauncher.openChatGPT(context)) {
                NotificationUtil.alert(context, "ChatGPT açılamadı", "ChatGPT uygulaması başlatılamadı.");
            }
        } else if ("STOP".equals(a)) {
            FactoryAccessibilityService.stopAndClose(context);
        } else if ("PAUSE".equals(a)) {
            if (!p.getBoolean(Prefs.ENABLED, false)) return;
            p.edit().putBoolean(Prefs.PAUSED, true)
                    .putString(Prefs.STATUS_DETAIL, "Üretim bildirimden duraklatıldı")
                    .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis()).apply();
            NotificationUtil.status(context, "Duraklatıldı — uygulamayı açarak devam ettir");
        } else if ("LIMIT_WAKE".equals(a)) {
            if (!p.getBoolean(Prefs.ENABLED, false)) return;
            String resume = p.getString(Prefs.LIMIT_RESUME_STATE, AutomationState.WAIT_PRODUCT);
            p.edit()
                    .putBoolean(Prefs.PAUSED, false)
                    .putString(Prefs.STATE, resume)
                    .putBoolean(Prefs.AFTER_LIMIT, true)
                    .remove(Prefs.LAST_ERROR)
                    .remove(Prefs.LIMIT_UNTIL)
                    .putString(Prefs.STATUS_DETAIL, "Kullanım hakkı yenilendi; ürün akışı yeniden kontrol ediliyor")
                    .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis())
                    .apply();
            NotificationUtil.status(context, "Kullanım hakkı yenilendi · ürün akışı yeniden kontrol ediliyor");
            FactoryAccessibilityService.kickIfVisible();
        }
    }
}
