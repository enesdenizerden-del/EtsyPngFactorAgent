package com.deniz.etsypngfactory;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.text.Normalizer;
import java.util.Set;

final class NodeUtil {
    static AccessibilityNodeInfo findText(AccessibilityNodeInfo root, String needle) {
        if (root == null || needle == null) return null;
        List<AccessibilityNodeInfo> found = root.findAccessibilityNodeInfosByText(needle);
        if (found == null || found.isEmpty()) return null;
        for (AccessibilityNodeInfo n : found) {
            CharSequence t = n.getText();
            CharSequence d = n.getContentDescription();
            String s = ((t == null ? "" : t.toString()) + " " + (d == null ? "" : d.toString())).toLowerCase(Locale.ROOT);
            if (s.contains(needle.toLowerCase(Locale.ROOT))) return n;
        }
        return found.get(0);
    }

    static AccessibilityNodeInfo findTextLoose(AccessibilityNodeInfo root, String needle) {
        AccessibilityNodeInfo exact = findText(root, needle);
        if (exact != null) return exact;
        if (root == null || needle == null) return null;
        String target = normalize(needle);
        ArrayList<AccessibilityNodeInfo> all = new ArrayList<>();
        collect(root, all, 0, 2200);
        AccessibilityNodeInfo best = null;
        int bestExtra = Integer.MAX_VALUE;
        for (AccessibilityNodeInfo n : all) {
            String value = normalize(textAndDesc(n));
            if (value.isEmpty()) continue;
            if (value.equals(target)) return n;
            if (value.contains(target) || target.contains(value)) {
                int extra = Math.abs(value.length() - target.length());
                if (extra < bestExtra) { best = n; bestExtra = extra; }
            }
        }
        return best;
    }

    static AccessibilityNodeInfo findByTextOrDescription(AccessibilityNodeInfo root, String... needles) {
        if (root == null) return null;
        ArrayList<AccessibilityNodeInfo> all = new ArrayList<>();
        collect(root, all, 0, 1800);
        for (AccessibilityNodeInfo n : all) {
            String s = textAndDesc(n).toLowerCase(Locale.ROOT);
            for (String needle : needles) {
                if (needle != null && s.contains(needle.toLowerCase(Locale.ROOT))) return n;
            }
        }
        return null;
    }

    static AccessibilityNodeInfo findEditable(AccessibilityNodeInfo root) {
        if (root == null) return null;
        ArrayList<AccessibilityNodeInfo> all = new ArrayList<>();
        collect(root, all, 0, 1800);
        AccessibilityNodeInfo fallback = null;
        for (AccessibilityNodeInfo n : all) {
            if (n.isEditable()) return n;
            CharSequence cls = n.getClassName();
            if (cls != null && cls.toString().toLowerCase(Locale.ROOT).contains("edittext")) fallback = n;
        }
        return fallback;
    }

    static boolean click(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo n = node;
        for (int i = 0; n != null && i < 7; i++) {
            if (n.isClickable() && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            n = n.getParent();
        }
        return node != null && node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    static boolean setText(AccessibilityNodeInfo node, String text) {
        if (node == null) return false;
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }

    // Popup penceresinde klavyeyi gereksiz yere açmadan önce doğrudan ACTION_SET_TEXT dene.
    // Bazı One UI/ChatGPT sürümlerinde odak gerekiyorsa yalnız accessibility focus/focus verir;
    // koordinat tıklaması yapmaz ve kurye uygulamasına dokunmaz.
    static boolean setTextPopupSafe(AccessibilityNodeInfo node, String text) {
        if (node == null) return false;
        if (setText(node, text)) return true;
        try { node.performAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS); } catch (Throwable ignored) { }
        try { node.performAction(AccessibilityNodeInfo.ACTION_FOCUS); } catch (Throwable ignored) { }
        return setText(node, text);
    }

    static String dumpText(AccessibilityNodeInfo root) {
        if (root == null) return "";
        ArrayList<AccessibilityNodeInfo> all = new ArrayList<>();
        collect(root, all, 0, 2500);
        Set<String> lines = new LinkedHashSet<>();
        for (AccessibilityNodeInfo n : all) {
            CharSequence t = n.getText();
            if (t != null) {
                String x = t.toString().trim();
                if (!x.isEmpty()) lines.add(x);
            }
            CharSequence d = n.getContentDescription();
            if (d != null) {
                String x = d.toString().trim();
                if (!x.isEmpty() && !lines.contains(x)) lines.add(x);
            }
        }
        StringBuilder sb = new StringBuilder();
        for (String s : lines) sb.append(s).append('\n');
        return sb.toString();
    }

    static List<AccessibilityNodeInfo> clickableDownloads(AccessibilityNodeInfo root) {
        ArrayList<AccessibilityNodeInfo> all = new ArrayList<>();
        collect(root, all, 0, 2500);
        ArrayList<AccessibilityNodeInfo> out = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        for (AccessibilityNodeInfo n : all) {
            String fileName = fileNameSignature(n);
            if (fileName.isEmpty()) continue;
            if (!(n.isClickable() || hasClickableParent(n))) continue;
            if (seen.add(fileName)) out.add(n);
        }
        return out;
    }

    static String downloadBaseline(AccessibilityNodeInfo root) {
        StringBuilder sb = new StringBuilder();
        Set<String> seen = new LinkedHashSet<>();
        for (AccessibilityNodeInfo n : clickableDownloads(root)) {
            String sig = fileNameSignature(n);
            if (!sig.isEmpty() && seen.add(sig)) sb.append(sig).append('\n');
        }
        return sb.toString();
    }

    static List<AccessibilityNodeInfo> newClickableDownloads(AccessibilityNodeInfo root, String baseline) {
        Set<String> old = new LinkedHashSet<>();
        if (baseline != null) {
            for (String s : baseline.split("\\n")) {
                if (!s.trim().isEmpty()) old.add(s.trim().toLowerCase(Locale.ROOT));
            }
        }
        ArrayList<AccessibilityNodeInfo> out = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        for (AccessibilityNodeInfo n : clickableDownloads(root)) {
            String sig = fileNameSignature(n);
            if (sig.isEmpty() || old.contains(sig) || !seen.add(sig)) continue;
            out.add(n);
        }
        return out;
    }


    static List<AccessibilityNodeInfo> newClickableZipDownloads(AccessibilityNodeInfo root, String baseline) {
        ArrayList<AccessibilityNodeInfo> out = new ArrayList<>();
        for (AccessibilityNodeInfo n : newClickableDownloads(root, baseline)) {
            String sig = fileNameSignature(n);
            if (sig.endsWith(".zip")) out.add(n);
        }
        return out;
    }

    static boolean generatingNearBottom(String dump) {
        if (dump == null || dump.isEmpty()) return false;
        String[] lines = dump.split("\\n");
        int start = Math.max(0, lines.length - 24);
        StringBuilder sb = new StringBuilder();
        for (int i = start; i < lines.length; i++) sb.append(lines[i]).append('\n');
        String x = normalize(sb.toString());
        if (x.contains("yaniti durdur") || x.contains("stop generating") || x.contains("calisiyor") || x.contains("working")) return true;
        for (int i = start; i < lines.length; i++) {
            String line = normalize(lines[i]);
            if (line.equals("dur") || line.equals("stop")) return true;
        }
        return false;
    }

    static String downloadFileName(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo p = n;
        for (int hops = 0; p != null && hops < 5; hops++, p = p.getParent()) {
            String file = firstFileName(textAndDesc(p));
            if (!file.isEmpty()) return file;
        }
        return "";
    }

    // Eski sürüm parent hiyerarşisini imzaya katıyordu. ChatGPT yeni mesaj eklediğinde
    // aynı eski dosyanın parent metni değişebildiği için dosya yanlışlıkla "yeni" sayılıyordu.
    // v0.9 yalnız gerçek dosya adını imza olarak kullanır.
    private static String fileNameSignature(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo p = n;
        for (int hops = 0; p != null && hops < 5; hops++, p = p.getParent()) {
            String value = textAndDesc(p);
            String file = firstFileName(value);
            if (!file.isEmpty()) return file.toLowerCase(Locale.ROOT);
        }
        return "";
    }

    private static String firstFileName(String value) {
        if (value == null || value.isEmpty()) return "";
        String[] tokens = value.replace('\n', ' ').split("\\s+");
        for (String raw : tokens) {
            String t = raw.trim();
            while (!t.isEmpty() && "([{<\"'".indexOf(t.charAt(0)) >= 0) t = t.substring(1);
            while (!t.isEmpty() && ")]}>,;:\"'".indexOf(t.charAt(t.length() - 1)) >= 0) t = t.substring(0, t.length() - 1);
            String l = t.toLowerCase(Locale.ROOT);
            if (l.endsWith(".zip") || l.endsWith(".png") || l.endsWith(".mp4") || l.endsWith(".json") || l.endsWith(".pdf") || l.endsWith(".txt")) return t;
        }
        return "";
    }

    static boolean looksQueued(String dump) {
        String s = normalize(dump);
        return s.contains("gonderilmeyi bekliyor") || s.contains("gonderim bekleniyor") || s.contains("queued") || s.contains("waiting to send");
    }

    static boolean looksGenerating(String dump) {
        String s = normalize(dump);
        if (s.contains("yaniti durdur") || s.contains("stop generating") || s.contains("calisiyor") || s.contains("working")) return true;
        if (dump != null) {
            for (String line : dump.split("\\n")) {
                String x = normalize(line);
                if (x.equals("dur") || x.equals("stop")) return true;
            }
        }
        return false;
    }


    static boolean hasActiveStopControl(AccessibilityNodeInfo root) {
        if (root == null) return false;
        ArrayList<AccessibilityNodeInfo> all = new ArrayList<>();
        collect(root, all, 0, 2200);
        for (AccessibilityNodeInfo n : all) {
            String x = normalize(textAndDesc(n));
            if (!(x.equals("dur") || x.equals("stop") || x.contains("yaniti durdur") || x.contains("stop generating"))) continue;
            if (n.isClickable() || hasClickableParent(n)) return true;
        }
        return false;
    }

    static boolean latestFactoryQueued(String dump, String niche, String subNiche) {
        String slice = latestFactorySlice(dump, niche, subNiche);
        String x = normalize(slice);
        return x.contains("gonderilmeyi bekliyor") || x.contains("gonderim bekleniyor") || x.contains("queued") || x.contains("waiting to send");
    }

    static boolean queuedNearBottom(String dump) {
        if (dump == null || dump.isEmpty()) return false;
        String[] lines = dump.split("\\n");
        int start = Math.max(0, lines.length - 18);
        StringBuilder sb = new StringBuilder();
        for (int i = start; i < lines.length; i++) sb.append(lines[i]).append('\n');
        String x = normalize(sb.toString());
        return x.contains("gonderilmeyi bekliyor") || x.contains("gonderim bekleniyor") || x.contains("queued") || x.contains("waiting to send");
    }

    private static String latestFactorySlice(String dump, String niche, String subNiche) {
        if (dump == null || dump.isEmpty()) return "";
        String[] lines = dump.split("\\n");
        String nn = normalize(niche);
        String ss = normalize(subNiche);
        int start = -1;
        for (int i = 0; i < lines.length; i++) {
            String x = normalize(lines[i]);
            if (!x.contains("uretime basla")) continue;
            boolean nicheOk = nn.isEmpty() || x.contains(nn);
            boolean subOk = ss.isEmpty() || x.contains(ss);
            if (nicheOk && subOk) start = i;
        }
        if (start < 0) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = start; i < lines.length && i <= start + 24; i++) {
            if (i > start && normalize(lines[i]).contains("uretime basla")) break;
            sb.append(lines[i]).append('\n');
        }
        return sb.toString();
    }

    static AccessibilityNodeInfo findClickableNearText(AccessibilityNodeInfo root, Rect target, String... needles) {
        if (root == null) return null;
        ArrayList<AccessibilityNodeInfo> all = new ArrayList<>();
        collect(root, all, 0, 2200);
        AccessibilityNodeInfo best = null;
        double bestScore = Double.MAX_VALUE;
        for (AccessibilityNodeInfo n : all) {
            String x = normalize(textAndDesc(n));
            boolean match = false;
            for (String needle : needles) {
                if (needle != null && x.contains(normalize(needle))) { match = true; break; }
            }
            if (!match || !(n.isClickable() || hasClickableParent(n))) continue;
            Rect b = new Rect();
            n.getBoundsInScreen(b);
            if (b.isEmpty()) continue;
            double dx = b.exactCenterX() - target.exactCenterX();
            double dy = b.exactCenterY() - target.top;
            double score = Math.abs(dx) + Math.abs(dy) * 0.7;
            if (score < bestScore) { best = n; bestScore = score; }
        }
        return best;
    }

    static boolean openDrawerFallback(AccessibilityService service, AccessibilityNodeInfo root) {
        // Önce erişilebilirlik etiketi olan gerçek navigasyon düğmesini kullan.
        AccessibilityNodeInfo n = findByTextOrDescription(root,
                "kenar çubuğunu aç", "kenar cubugunu ac", "menüyü aç", "menuyu ac",
                "yan menüyü aç", "yan menuyu ac", "sohbet geçmişini aç", "sohbet gecmisini ac",
                "open sidebar", "open navigation", "navigation menu", "open menu", "sidebar");
        if (n != null && click(n)) return true;

        // ChatGPT bazı sürümlerde hamburger düğmesine metin/description vermiyor.
        // Sabit piksel yerine üst-sol bölgedeki tıklanabilir küçük UI düğümünü bul.
        AccessibilityNodeInfo topLeft = findTopLeftClickable(root);
        if (topLeft != null && click(topLeft)) return true;

        // Son çare: ekran boyutuna göre göreli koordinat. Bu, A36 çözünürlüğü/density değişse de çalışır.
        Rect bounds = new Rect();
        root.getBoundsInScreen(bounds);
        int w = Math.max(1, bounds.width());
        int h = Math.max(1, bounds.height());
        float x = bounds.left + w * 0.075f;
        float y = bounds.top + h * 0.075f;
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(p, 0, 90);
        GestureDescription g = new GestureDescription.Builder().addStroke(stroke).build();
        return service.dispatchGesture(g, null, null);
    }

    private static AccessibilityNodeInfo findTopLeftClickable(AccessibilityNodeInfo root) {
        if (root == null) return null;
        Rect rb = new Rect();
        root.getBoundsInScreen(rb);
        int w = Math.max(1, rb.width());
        int h = Math.max(1, rb.height());
        ArrayList<AccessibilityNodeInfo> all = new ArrayList<>();
        collect(root, all, 0, 1800);
        AccessibilityNodeInfo best = null;
        double bestScore = Double.MAX_VALUE;
        for (AccessibilityNodeInfo n : all) {
            if (!n.isClickable()) continue;
            Rect b = new Rect();
            n.getBoundsInScreen(b);
            if (b.width() <= 0 || b.height() <= 0) continue;
            float cx = b.exactCenterX() - rb.left;
            float cy = b.exactCenterY() - rb.top;
            if (cx < 0 || cy < 0 || cx > w * 0.28f || cy > h * 0.20f) continue;
            // Aşırı büyük container'ları ele. Hamburger genellikle küçük bir butondur.
            if (b.width() > w * 0.32f || b.height() > h * 0.16f) continue;
            double score = (cx / w) * 0.65 + (cy / h) * 0.35 + ((double)b.width() * b.height()) / ((double)w * h) * 0.25;
            if (score < bestScore) { best = n; bestScore = score; }
        }
        return best;
    }

    private static String normalize(String s) {
        if (s == null) return "";
        String x = Normalizer.normalize(s, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .toLowerCase(Locale.ROOT)
                .replace('ı', 'i')
                .replaceAll("[^a-z0-9]+", " ")
                .trim()
                .replaceAll("\\s+", " ");
        return x;
    }

    private static boolean hasClickableParent(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo p = node;
        for (int i = 0; p != null && i < 5; i++, p = p.getParent()) if (p.isClickable()) return true;
        return false;
    }

    private static String textAndDesc(AccessibilityNodeInfo n) {
        CharSequence t = n.getText();
        CharSequence d = n.getContentDescription();
        return (t == null ? "" : t.toString()) + " " + (d == null ? "" : d.toString());
    }

    private static void collect(AccessibilityNodeInfo n, List<AccessibilityNodeInfo> out, int depth, int max) {
        if (n == null || out.size() >= max || depth > 40) return;
        out.add(n);
        for (int i = 0; i < n.getChildCount() && out.size() < max; i++) collect(n.getChild(i), out, depth + 1, max);
    }
}
