package com.deniz.etsypngfactory;

import android.content.Context;
import android.net.Uri;

import androidx.documentfile.provider.DocumentFile;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashSet;
import java.util.Set;

final class StorageUtil {
    static String snapshot(Context c) {
        DocumentFile tree = downloadTree(c);
        if (tree == null) return "";
        StringBuilder sb = new StringBuilder();
        for (DocumentFile f : tree.listFiles()) {
            if (f.isFile()) sb.append(key(f)).append('\n');
        }
        return sb.toString();
    }

    /**
     * Ürün bitmiş sayılmadan önce fiziksel final ZIP'in Download klasörüne gerçekten
     * düştüğünü doğrular. Snapshot'ta zaten bulunan eski ZIP'ler kabul edilmez.
     */
    static boolean hasNewZipInDownload(Context c, String oldSnapshot, long startedAt) {
        return newestCandidate(c, downloadTree(c), oldSnapshot, startedAt) != null;
    }

    /**
     * Bu ürün için gelen final ZIP'i tek ve deterministik bir klasöre, tek ve
     * anlaşılır bir dosya adıyla kaydeder:
     * P0001__NIS__ALT_NIS/P0001__NIS__ALT_NIS__SELLER_BUNDLE.zip
     */
    static int archiveNewFiles(Context c, int seq, String niche, String subNiche,
                               String oldSnapshot, long startedAt) throws Exception {
        DocumentFile src = downloadTree(c);
        DocumentFile dst = factoryTree(c);
        if (src == null || dst == null) return 0;

        DocumentFile candidate = newestCandidate(c, src, oldSnapshot, startedAt);
        if (candidate == null) return 0;

        String folderName = ProductNaming.folderName(seq, niche, subNiche);
        DocumentFile folder = findDir(dst, folderName);
        if (folder == null) folder = dst.createDirectory(folderName);
        if (folder == null) throw new IllegalStateException("Ürün klasörü oluşturulamadı");

        String targetName = ProductNaming.finalZipName(seq, niche, subNiche);
        return copyAs(c, candidate, folder, targetName) ? 1 : 0;
    }

    /**
     * Tamamlanma kanıtı yalnızca o ürünün niş+alt niş adına ait klasördeki
     * standart final ZIP'tir. Böylece başka ürünün ZIP'i yanlışlıkla kabul edilmez.
     */
    static boolean hasVerifiedProductZip(Context c, int seq, String niche, String subNiche, long startedAt) {
        DocumentFile dst = factoryTree(c);
        if (dst == null) return false;

        DocumentFile folder = findDir(dst, ProductNaming.folderName(seq, niche, subNiche));
        if (folder == null) return false;

        DocumentFile zip = folder.findFile(ProductNaming.finalZipName(seq, niche, subNiche));
        if (!isUsableZip(zip)) return false;

        long m = zip.lastModified();
        return startedAt <= 0 || m <= 0 || m + 60_000L >= startedAt;
    }

    private static DocumentFile newestCandidate(Context c, DocumentFile src, String oldSnapshot, long startedAt) {
        if (src == null) return null;
        Set<String> old = snapshotSet(oldSnapshot);
        String expected = Prefs.get(c).getString(Prefs.EXPECTED_DOWNLOAD_NAME, "");
        DocumentFile best = null;
        long bestModified = Long.MIN_VALUE;

        for (DocumentFile f : src.listFiles()) {
            if (!isUsableZip(f)) continue;
            if (old.contains(key(f))) continue;
            long m = f.lastModified();
            if (startedAt > 0 && m > 0 && m + 60_000L < startedAt) continue;
            if (!expected.isBlank() && !matchesExpectedName(f.getName(), expected)) continue;

            // Aynı üretim penceresinde birden fazla ZIP görünürse en yenisini al.
            long rank = m > 0 ? m : 0;
            if (best == null || rank >= bestModified) {
                best = f;
                bestModified = rank;
            }
        }
        return best;
    }

    private static boolean matchesExpectedName(String actual, String expected) {
        if (actual == null || expected == null) return false;
        String a = actual.trim().toLowerCase(java.util.Locale.ROOT);
        String e = expected.trim().toLowerCase(java.util.Locale.ROOT);
        if (a.equals(e)) return true;

        // Android aynı isim daha önce varsa " (1)" gibi bir ek koyabilir.
        if (e.endsWith(".zip") && a.endsWith(").zip")) {
            String stem = e.substring(0, e.length() - 4);
            String prefix = stem + " (";
            if (a.startsWith(prefix)) {
                String digits = a.substring(prefix.length(), a.length() - 5);
                if (!digits.isEmpty()) {
                    for (int i = 0; i < digits.length(); i++) {
                        if (!Character.isDigit(digits.charAt(i))) return false;
                    }
                    return true;
                }
            }
        }
        return false;
    }

    private static DocumentFile downloadTree(Context c) {
        String uri = Prefs.get(c).getString(Prefs.DOWNLOAD_TREE, null);
        if (uri == null) return null;
        try { return DocumentFile.fromTreeUri(c, Uri.parse(uri)); }
        catch (Throwable ignored) { return null; }
    }

    private static DocumentFile factoryTree(Context c) {
        String uri = Prefs.get(c).getString(Prefs.FACTORY_TREE, null);
        if (uri == null) return null;
        try { return DocumentFile.fromTreeUri(c, Uri.parse(uri)); }
        catch (Throwable ignored) { return null; }
    }

    private static Set<String> snapshotSet(String snapshot) {
        Set<String> old = new HashSet<>();
        if (snapshot != null) {
            for (String s : snapshot.split("\\n")) if (!s.isBlank()) old.add(s);
        }
        return old;
    }

    private static boolean isUsableZip(DocumentFile f) {
        if (f == null || !f.isFile()) return false;
        String name = f.getName();
        if (name == null || !name.toLowerCase(java.util.Locale.ROOT).endsWith(".zip")) return false;
        return f.length() > 0;
    }

    private static boolean copyAs(Context c, DocumentFile src, DocumentFile folder, String targetName) throws Exception {
        DocumentFile existing = folder.findFile(targetName);
        if (existing != null && existing.isFile()) {
            if (existing.length() == src.length() && src.length() > 0) return true;
            if (!existing.delete()) return false;
        }

        DocumentFile outFile = folder.createFile("application/zip", targetName);
        if (outFile == null) return false;

        try (InputStream in = c.getContentResolver().openInputStream(src.getUri());
             OutputStream out = c.getContentResolver().openOutputStream(outFile.getUri(), "w")) {
            if (in == null || out == null) return false;
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
            out.flush();
        }
        return outFile.length() > 0 || src.length() > 0;
    }

    private static DocumentFile findDir(DocumentFile parent, String name) {
        DocumentFile f = parent.findFile(name);
        return f != null && f.isDirectory() ? f : null;
    }

    private static String key(DocumentFile f) {
        return (f.getName() == null ? "" : f.getName()) + "|" + f.length() + "|" + f.lastModified();
    }
}
