package com.deniz.etsypngfactory;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    static final String NAME = "factory_prefs";
    static final String ENABLED = "enabled";
    static final String PAUSED = "paused";
    static final String STATE = "state";
    static final String FACTORY_TREE = "factory_tree";
    static final String DOWNLOAD_TREE = "download_tree";
    static final String NICHE = "niche";
    static final String SUBNICHE = "subniche";
    static final String PRODUCT_SEQ = "product_seq";
    static final String PRODUCT_STARTED = "product_started";
    static final String DOWNLOAD_SNAPSHOT = "download_snapshot";
    static final String LAST_TREE = "last_tree";
    static final String LAST_ERROR = "last_error";
    static final String LAST_ACTION = "last_action";
    static final String ATTEMPTS = "attempts";
    static final String LIMIT_RESUME_STATE = "limit_resume_state";
    static final String LIMIT_UNTIL = "limit_until";
    static final String AFTER_LIMIT = "after_limit";
    static final String DOWNLOAD_UI_BASELINE = "download_ui_baseline";
    static final String PRODUCT_ACTIVE_SEEN = "product_active_seen";
    // Legacy key: v0.9 only clears it; no recovery behavior uses it.
    static final String UPGRADE_RECOVERY = "upgrade_recovery";
    static final String RUNTIME_VERSION = "runtime_version";
    static final String POPUP_SETUP_STATE = "popup_setup_state";
    static final String POPUP_SETUP_STARTED = "popup_setup_started";
    static final String POPUP_CLOSE_REQUESTED = "popup_close_requested";

    static SharedPreferences get(Context c) {
        return c.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }
}
