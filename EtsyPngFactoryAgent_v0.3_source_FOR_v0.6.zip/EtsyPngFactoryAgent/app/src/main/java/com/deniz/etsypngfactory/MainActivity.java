package com.deniz.etsypngfactory;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements SharedPreferences.OnSharedPreferenceChangeListener {
    private static final int REQ_FACTORY = 201;
    private static final int REQ_DOWNLOAD = 202;

    private static final int BG = 0xFF0A0C0F;
    private static final int CARD = 0xFF15181D;
    private static final int CARD_SOFT = 0xFF111419;
    private static final int TEXT = 0xFFF5F7FA;
    private static final int MUTED = 0xFF9CA3AF;
    private static final int ACCENT = 0xFF7C5CFC;
    private static final int GOOD = 0xFF39C778;
    private static final int WARN = 0xFFF0B44D;
    private static final int BAD = 0xFFFF626B;

    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            refresh();
            uiHandler.postDelayed(this, 1000L);
        }
    };

    private TextView statePill;
    private TextView productId;
    private TextView stageTitle;
    private TextView stageDetail;
    private TextView metaLine;
    private ProgressBar progress;
    private LinearLayout nicheCard;
    private TextView nicheText;
    private TextView subNicheText;
    private LinearLayout limitCard;
    private TextView limitText;
    private LinearLayout lastCard;
    private TextView lastText;
    private LinearLayout errorCard;
    private TextView errorText;
    private LinearLayout setupCard;
    private TextView setupText;
    private LinearLayout controls;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        NotificationUtil.ensureChannels(this);
        resetRuntimeAfterUpgrade();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 55);
        }
        Prefs.get(this).registerOnSharedPreferenceChangeListener(this);
        buildUi();
    }

    @Override protected void onResume() {
        super.onResume();
        uiHandler.removeCallbacks(ticker);
        uiHandler.post(ticker);
    }

    @Override protected void onPause() {
        uiHandler.removeCallbacks(ticker);
        super.onPause();
    }

    @Override protected void onDestroy() {
        uiHandler.removeCallbacks(ticker);
        Prefs.get(this).unregisterOnSharedPreferenceChangeListener(this);
        if (isFinishing() && Prefs.get(this).getBoolean(Prefs.ENABLED, false)) {
            FactoryAccessibilityService.stopAndClose(this);
        }
        super.onDestroy();
    }

    @Override public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        uiHandler.post(this::refresh);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int side = dp(18);
        root.setPadding(side, dp(18), side, dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        header.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView title = text("PNG Fabrikası", 27, TEXT, true);
        titleBox.addView(title);
        TextView subtitle = text("ChatGPT otomatik üretim · v0.11", 13, MUTED, false);
        subtitle.setPadding(0, dp(3), 0, 0);
        titleBox.addView(subtitle);

        TextView settings = actionChip("Ayarlar", CARD, TEXT);
        settings.setOnClickListener(v -> showSettings());
        header.addView(settings, new LinearLayout.LayoutParams(dp(86), dp(40)));

        LinearLayout statusCard = card(CARD, 18);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-1, -2);
        statusLp.topMargin = dp(20);
        root.addView(statusCard, statusLp);

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);
        statusCard.addView(topRow, new LinearLayout.LayoutParams(-1, -2));

        productId = text("P0001", 14, MUTED, true);
        topRow.addView(productId, new LinearLayout.LayoutParams(0, -2, 1f));
        statePill = actionChip("Hazır", CARD_SOFT, TEXT);
        statePill.setGravity(Gravity.CENTER);
        topRow.addView(statePill, new LinearLayout.LayoutParams(dp(112), dp(34)));

        stageTitle = text("Üretime hazır", 23, TEXT, true);
        stageTitle.setPadding(0, dp(17), 0, dp(5));
        statusCard.addView(stageTitle);

        stageDetail = text("Başlatınca niş araştırması otomatik başlayacak.", 15, 0xFFD4D7DD, false);
        stageDetail.setLineSpacing(0f, 1.15f);
        statusCard.addView(stageDetail);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress(0);
        if (Build.VERSION.SDK_INT >= 21) progress.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        LinearLayout.LayoutParams progressLp = new LinearLayout.LayoutParams(-1, dp(8));
        progressLp.topMargin = dp(18);
        statusCard.addView(progress, progressLp);

        metaLine = text("Sıradaki ürün hazırlanıyor", 13, MUTED, false);
        metaLine.setPadding(0, dp(10), 0, 0);
        statusCard.addView(metaLine);

        nicheCard = compactCard(root, "AKTİF ÜRÜN");
        nicheText = text("—", 18, TEXT, true);
        nicheCard.addView(nicheText);
        subNicheText = text("—", 14, 0xFFD0D4DA, false);
        subNicheText.setPadding(0, dp(5), 0, 0);
        nicheCard.addView(subNicheText);

        limitCard = compactCard(root, "BEKLEME");
        limitText = text("", 16, TEXT, true);
        limitCard.addView(limitText);

        errorCard = compactCard(root, "MÜDAHALE GEREKİYOR");
        errorText = text("", 14, 0xFFFFD2D5, false);
        errorText.setLineSpacing(0f, 1.15f);
        errorCard.addView(errorText);

        lastCard = compactCard(root, "SON TAMAMLANAN");
        lastText = text("", 14, 0xFFD0D4DA, false);
        lastCard.addView(lastText);

        setupCard = compactCard(root, "KURULUM");
        setupText = text("", 14, 0xFFD0D4DA, false);
        setupCard.addView(setupText);
        TextView setupAction = actionChip("Kurulumu tamamla", ACCENT, Color.WHITE);
        setupAction.setGravity(Gravity.CENTER);
        setupAction.setOnClickListener(v -> showSettings());
        LinearLayout.LayoutParams setupActionLp = new LinearLayout.LayoutParams(-1, dp(44));
        setupActionLp.topMargin = dp(12);
        setupCard.addView(setupAction, setupActionLp);

        controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams controlsLp = new LinearLayout.LayoutParams(-1, -2);
        controlsLp.topMargin = dp(18);
        root.addView(controls, controlsLp);

        setContentView(scroll);
        refresh();
    }

    private LinearLayout compactCard(LinearLayout root, String label) {
        LinearLayout c = card(CARD_SOFT, 16);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        root.addView(c, lp);
        TextView l = text(label, 11, MUTED, true);
        l.setLetterSpacing(0.08f);
        l.setPadding(0, 0, 0, dp(8));
        c.addView(l);
        return c;
    }

    private LinearLayout card(int color, int paddingDp) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(paddingDp), dp(paddingDp), dp(paddingDp), dp(paddingDp));
        c.setBackground(roundRect(color, 18));
        if (Build.VERSION.SDK_INT >= 21) c.setElevation(dp(1));
        return c;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private TextView actionChip(String value, int bg, int fg) {
        TextView t = text(value, 14, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(roundRect(bg, 14));
        t.setPadding(dp(12), 0, dp(12), 0);
        t.setClickable(true);
        t.setFocusable(true);
        return t;
    }

    private Button controlButton(String value, boolean primary, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(value);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(roundRect(primary ? ACCENT : 0xFF262A31, 16));
        b.setOnClickListener(listener);
        return b;
    }

    private GradientDrawable roundRect(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private void showSettings() {
        SharedPreferences p = Prefs.get(this);
        String factory = p.getString(Prefs.FACTORY_TREE, null) != null ? "✓" : "Eksik";
        String download = p.getString(Prefs.DOWNLOAD_TREE, null) != null ? "✓" : "Eksik";
        String access = isAccessibilityEnabled() ? "✓" : "Eksik";
        String[] items = new String[]{
                "Ürün klasörü   " + factory,
                "ChatGPT indirme klasörü   " + download,
                "Erişilebilirlik izni   " + access,
                "Tanı verisini kopyala"
        };
        new AlertDialog.Builder(this)
                .setTitle("Ayarlar")
                .setItems(items, (dialog, which) -> {
                    if (which == 0) pickTree(REQ_FACTORY);
                    else if (which == 1) pickTree(REQ_DOWNLOAD);
                    else if (which == 2) startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                    else copyDebug();
                })
                .setNegativeButton("Kapat", null)
                .show();
    }

    private void pickTree(int req) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(i, req);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try { getContentResolver().takePersistableUriPermission(uri, flags); } catch (Exception ignored) { }
        String key = requestCode == REQ_FACTORY ? Prefs.FACTORY_TREE : Prefs.DOWNLOAD_TREE;
        Prefs.get(this).edit().putString(key, uri.toString()).apply();
        refresh();
    }

    private void startFactory() {
        SharedPreferences p = Prefs.get(this);
        if (!setupReady()) {
            Toast.makeText(this, "Önce kurulumu tamamla.", Toast.LENGTH_LONG).show();
            showSettings();
            return;
        }
        p.edit()
                .putBoolean(Prefs.ENABLED, true)
                .putBoolean(Prefs.PAUSED, false)
                .putString(Prefs.STATE, AutomationState.OPEN_NICHE_CHAT)
                .putString(Prefs.STATUS_DETAIL, "ChatGPT açılır penceresi hazırlanıyor")
                .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis())
                .remove(Prefs.LAST_ERROR)
                .remove(Prefs.NICHE)
                .remove(Prefs.SUBNICHE)
                .remove(Prefs.PRODUCT_STARTED)
                .remove(Prefs.DOWNLOAD_SNAPSHOT)
                .remove(Prefs.DOWNLOAD_UI_BASELINE)
                .remove(Prefs.PRODUCT_ACTIVE_SEEN)
                .remove(Prefs.LIMIT_RESUME_STATE)
                .remove(Prefs.LIMIT_UNTIL)
                .remove(Prefs.UPGRADE_RECOVERY)
                .putInt(Prefs.POPUP_SETUP_STATE, 0)
                .remove(Prefs.POPUP_SETUP_STARTED)
                .putBoolean(Prefs.POPUP_CLOSE_REQUESTED, false)
                .putBoolean(Prefs.AFTER_LIMIT, false)
                .putInt(Prefs.ATTEMPTS, 0)
                .apply();
        NotificationUtil.status(this, "ChatGPT popup otomatik açılıyor");
        if (!FactoryAccessibilityService.requestAutoPopupStart(this)) {
            p.edit().putBoolean(Prefs.ENABLED, false).putString(Prefs.STATE, AutomationState.ERROR)
                    .putString(Prefs.LAST_ERROR, "ChatGPT uygulaması başlatılamadı.")
                    .putString(Prefs.STATUS_DETAIL, "ChatGPT uygulaması başlatılamadı")
                    .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis()).apply();
            NotificationUtil.alert(this, "ChatGPT açılamadı", "ChatGPT uygulaması başlatılamadı.");
        }
        FactoryAccessibilityService.kickIfVisible();
        refresh();
    }

    private void resetRuntimeAfterUpgrade() {
        SharedPreferences p = Prefs.get(this);
        int v = p.getInt(Prefs.RUNTIME_VERSION, 0);
        if (v >= 10) return;
        p.edit()
                .putInt(Prefs.RUNTIME_VERSION, 10)
                .putBoolean(Prefs.ENABLED, false)
                .putBoolean(Prefs.PAUSED, false)
                .putString(Prefs.STATE, AutomationState.IDLE)
                .remove(Prefs.LAST_ERROR)
                .remove(Prefs.NICHE)
                .remove(Prefs.SUBNICHE)
                .remove(Prefs.PRODUCT_STARTED)
                .remove(Prefs.DOWNLOAD_SNAPSHOT)
                .remove(Prefs.DOWNLOAD_UI_BASELINE)
                .remove(Prefs.PRODUCT_ACTIVE_SEEN)
                .remove(Prefs.LIMIT_RESUME_STATE)
                .remove(Prefs.LIMIT_UNTIL)
                .remove(Prefs.UPGRADE_RECOVERY)
                .putInt(Prefs.POPUP_SETUP_STATE, 0)
                .remove(Prefs.POPUP_SETUP_STARTED)
                .putBoolean(Prefs.POPUP_CLOSE_REQUESTED, false)
                .putBoolean(Prefs.AFTER_LIMIT, false)
                .putInt(Prefs.ATTEMPTS, 0)
                .apply();
    }

    private void togglePause() {
        SharedPreferences p = Prefs.get(this);
        if (!p.getBoolean(Prefs.ENABLED, false)) return;
        boolean paused = !p.getBoolean(Prefs.PAUSED, false);
        p.edit().putBoolean(Prefs.PAUSED, paused)
                .putString(Prefs.STATUS_DETAIL, paused ? "Üretim kullanıcı tarafından duraklatıldı" : "Üretim devam ediyor")
                .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis()).apply();
        NotificationUtil.status(this, paused ? "Duraklatıldı" : "Popup motoru hazır");
        FactoryAccessibilityService.kickIfVisible();
        refresh();
    }

    private void stopFactory() {
        FactoryAccessibilityService.stopAndClose(this);
        refresh();
    }

    private void copyDebug() {
        SharedPreferences p = Prefs.get(this);
        long until = p.getLong(Prefs.LIMIT_UNTIL, 0L);
        String s = "STATE=" + p.getString(Prefs.STATE, "") +
                "\nDETAIL=" + p.getString(Prefs.STATUS_DETAIL, "") +
                "\nERROR=" + p.getString(Prefs.LAST_ERROR, "") +
                "\nNICHE=" + p.getString(Prefs.NICHE, "") +
                "\nSUBNICHE=" + p.getString(Prefs.SUBNICHE, "") +
                "\nLIMIT_UNTIL=" + until +
                "\nAFTER_LIMIT=" + p.getBoolean(Prefs.AFTER_LIMIT, false) +
                "\nPRODUCT_ACTIVE_SEEN=" + p.getBoolean(Prefs.PRODUCT_ACTIVE_SEEN, false) +
                "\n\nTREE:\n" + p.getString(Prefs.LAST_TREE, "");
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("PNG Factory debug", s));
        Toast.makeText(this, "Tanı verisi kopyalandı.", Toast.LENGTH_SHORT).show();
    }

    private void refresh() {
        if (stageTitle == null) return;
        SharedPreferences p = Prefs.get(this);
        boolean enabled = p.getBoolean(Prefs.ENABLED, false);
        boolean paused = p.getBoolean(Prefs.PAUSED, false);
        String state = p.getString(Prefs.STATE, AutomationState.IDLE);
        int seq = p.getInt(Prefs.PRODUCT_SEQ, 1);
        long until = p.getLong(Prefs.LIMIT_UNTIL, 0L);
        boolean limitWait = enabled && paused && until > System.currentTimeMillis();
        String error = p.getString(Prefs.LAST_ERROR, "");

        productId.setText("ÜRÜN  P" + String.format(Locale.US, "%04d", seq));

        String pill;
        int pillColor;
        if (AutomationState.ERROR.equals(state) || !error.isEmpty()) {
            pill = "Hata"; pillColor = BAD;
        } else if (!enabled) {
            pill = "Hazır"; pillColor = GOOD;
        } else if (limitWait) {
            pill = "Bekliyor"; pillColor = WARN;
        } else if (paused) {
            pill = "Duraklatıldı"; pillColor = WARN;
        } else {
            pill = "Çalışıyor"; pillColor = GOOD;
        }
        statePill.setText(pill);
        statePill.setBackground(roundRect(pillColor, 14));

        String title = friendlyStage(state, enabled, paused, limitWait);
        stageTitle.setText(title);
        String detail = p.getString(Prefs.STATUS_DETAIL, "");
        if (detail.isEmpty()) detail = friendlyDetail(state, enabled, paused, limitWait, p);
        if (AutomationState.ERROR.equals(state) && !error.isEmpty()) detail = "Üretim durdu. Ayrıntı aşağıda.";
        stageDetail.setText(detail);
        progress.setProgress(progressFor(state, enabled, p));

        long started = p.getLong(Prefs.PRODUCT_STARTED, 0L);
        String meta = "Sıradaki ürün: P" + String.format(Locale.US, "%04d", seq);
        if (started > 0 && enabled && (AutomationState.WAIT_PRODUCT.equals(state) || AutomationState.ARCHIVE.equals(state))) {
            meta = "Geçen süre: " + formatDuration(System.currentTimeMillis() - started);
        } else {
            long updated = p.getLong(Prefs.STATUS_UPDATED, 0L);
            if (updated > 0 && enabled) meta = "Son güncelleme: " + new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date(updated));
        }
        metaLine.setText(meta);

        String niche = p.getString(Prefs.NICHE, "").trim();
        String sub = p.getString(Prefs.SUBNICHE, "").trim();
        boolean hasNiche = !niche.isEmpty() || !sub.isEmpty();
        nicheCard.setVisibility(hasNiche ? View.VISIBLE : View.GONE);
        nicheText.setText(niche.isEmpty() ? "Niş belirleniyor…" : niche);
        subNicheText.setText(sub.isEmpty() ? "Alt niş bekleniyor" : sub);

        limitCard.setVisibility(limitWait ? View.VISIBLE : View.GONE);
        if (limitWait) {
            long remain = Math.max(0L, until - System.currentTimeMillis());
            String at = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(until));
            limitText.setText("ChatGPT kullanım hakkı " + at + "'da yenilenecek\nKalan: " + formatDuration(remain));
        }

        errorCard.setVisibility(!error.isEmpty() ? View.VISIBLE : View.GONE);
        errorText.setText(error);

        int lastSeq = p.getInt(Prefs.LAST_COMPLETED_SEQ, 0);
        String lastLabel = p.getString(Prefs.LAST_COMPLETED_LABEL, "");
        lastCard.setVisibility(lastSeq > 0 ? View.VISIBLE : View.GONE);
        if (lastSeq > 0) {
            String when = "";
            long lastAt = p.getLong(Prefs.LAST_COMPLETED_AT, 0L);
            if (lastAt > 0) when = " · " + new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(lastAt));
            lastText.setText("P" + String.format(Locale.US, "%04d", lastSeq) + (lastLabel.isEmpty() ? "" : " · " + lastLabel) + when);
        }

        boolean ready = setupReady();
        setupCard.setVisibility(ready ? View.GONE : View.VISIBLE);
        if (!ready) {
            setupText.setText("Ürün klasörü " + check(p.getString(Prefs.FACTORY_TREE, null) != null) +
                    "   •   İndirme " + check(p.getString(Prefs.DOWNLOAD_TREE, null) != null) +
                    "   •   Erişim " + check(isAccessibilityEnabled()));
        }

        rebuildControls(enabled, paused, limitWait, state);
    }

    private void rebuildControls(boolean enabled, boolean paused, boolean limitWait, String state) {
        controls.removeAllViews();
        if (!enabled) {
            Button start = controlButton("Üretimi başlat", true, v -> startFactory());
            controls.addView(start, new LinearLayout.LayoutParams(-1, dp(56)));
            return;
        }

        if (AutomationState.ERROR.equals(state)) {
            Button stop = controlButton("Kapat ve sıfırla", false, v -> stopFactory());
            controls.addView(stop, new LinearLayout.LayoutParams(-1, dp(54)));
            return;
        }

        Button pause = controlButton(paused && !limitWait ? "Devam et" : "Duraklat", false, v -> togglePause());
        if (limitWait) {
            pause.setEnabled(false);
            pause.setAlpha(0.45f);
            pause.setText("Limit bekleniyor");
        }
        LinearLayout.LayoutParams half1 = new LinearLayout.LayoutParams(0, dp(54), 1f);
        half1.rightMargin = dp(6);
        controls.addView(pause, half1);

        Button stop = controlButton("Durdur", true, v -> stopFactory());
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, dp(54), 1f);
        half2.leftMargin = dp(6);
        controls.addView(stop, half2);
    }

    private String friendlyStage(String state, boolean enabled, boolean paused, boolean limitWait) {
        if (!enabled) return "Üretime hazır";
        if (limitWait) return "Kullanım hakkı bekleniyor";
        if (paused) return "Üretim duraklatıldı";
        switch (state) {
            case AutomationState.OPEN_NICHE_CHAT:
            case AutomationState.SEND_NICHE:
            case AutomationState.WAIT_NICHE_REPLY: return "Yeni niş aranıyor";
            case AutomationState.OPEN_FACTORY_CHAT:
            case AutomationState.SEND_FACTORY: return "Üretim hazırlanıyor";
            case AutomationState.WAIT_PRODUCT: return "Ürün üretiliyor";
            case AutomationState.ARCHIVE: return "Dosyalar kaydediliyor";
            case AutomationState.ERROR: return "Üretim durdu";
            default: return "Çalışıyor";
        }
    }

    private String friendlyDetail(String state, boolean enabled, boolean paused, boolean limitWait, SharedPreferences p) {
        if (!enabled) return "Başlatınca niş araştırması, üretim ve dosya kaydı otomatik ilerler.";
        if (limitWait) return "ChatGPT kullanım hakkı yenilenince otomasyon kaldığı yerden devam edecek.";
        if (paused) return "Devam et dediğinde mevcut aşamadan sürer.";
        switch (state) {
            case AutomationState.OPEN_NICHE_CHAT: return "Niş araştırma sohbeti açılıyor.";
            case AutomationState.SEND_NICHE: return "ChatGPT'ye yeni niş isteği gönderiliyor.";
            case AutomationState.WAIT_NICHE_REPLY: return "Niş ve alt niş sonucu bekleniyor.";
            case AutomationState.OPEN_FACTORY_CHAT: return "Fabrika sohbeti açılıyor.";
            case AutomationState.SEND_FACTORY: return "Üretim komutu hazırlanıyor; fabrika meşgulse bitmesi bekleniyor.";
            case AutomationState.WAIT_PRODUCT:
                return p.getBoolean(Prefs.PRODUCT_ACTIVE_SEEN, false) ? "ChatGPT mevcut ürünü üretiyor." : "Üretimin başlaması bekleniyor.";
            case AutomationState.ARCHIVE: return "Yeni dosyalar indiriliyor ve ürün klasörüne aktarılıyor.";
            case AutomationState.ERROR: return "Müdahale gerekiyor.";
            default: return "Otomasyon çalışıyor.";
        }
    }

    private int progressFor(String state, boolean enabled, SharedPreferences p) {
        if (!enabled) return 0;
        switch (state) {
            case AutomationState.OPEN_NICHE_CHAT: return 8;
            case AutomationState.SEND_NICHE: return 15;
            case AutomationState.WAIT_NICHE_REPLY: return 28;
            case AutomationState.OPEN_FACTORY_CHAT: return 38;
            case AutomationState.SEND_FACTORY: return 48;
            case AutomationState.WAIT_PRODUCT: return p.getBoolean(Prefs.PRODUCT_ACTIVE_SEEN, false) ? 72 : 58;
            case AutomationState.ARCHIVE: return 94;
            case AutomationState.ERROR: return 0;
            default: return 5;
        }
    }

    private boolean setupReady() {
        SharedPreferences p = Prefs.get(this);
        return p.getString(Prefs.FACTORY_TREE, null) != null && p.getString(Prefs.DOWNLOAD_TREE, null) != null && isAccessibilityEnabled();
    }

    private String check(boolean ok) { return ok ? "✓" : "✕"; }

    private String formatDuration(long ms) {
        long total = Math.max(0L, ms / 1000L);
        long h = total / 3600L;
        long m = (total % 3600L) / 60L;
        long s = total % 60L;
        if (h > 0) return String.format(Locale.getDefault(), "%d sa %02d dk", h, m);
        return String.format(Locale.getDefault(), "%02d:%02d", m, s);
    }

    private boolean isAccessibilityEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        String flat = new ComponentName(this, FactoryAccessibilityService.class).flattenToString();
        return enabled.toLowerCase(Locale.ROOT).contains(flat.toLowerCase(Locale.ROOT));
    }

    private int dp(int x) { return Math.round(x * getResources().getDisplayMetrics().density); }
}
