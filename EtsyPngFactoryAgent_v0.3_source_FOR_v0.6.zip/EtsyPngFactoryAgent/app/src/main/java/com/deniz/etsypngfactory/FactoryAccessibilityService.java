package com.deniz.etsypngfactory;

import android.accessibilityservice.AccessibilityService;
import android.app.ActivityManager;
import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Path;
import android.graphics.Rect;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.util.List;

public class FactoryAccessibilityService extends AccessibilityService {
    private static volatile FactoryAccessibilityService activeInstance;
    private static final String CHATGPT = "com.openai.chatgpt";
    private static final String NICHE_CHAT = "Etsy PNG Niş Araştırması";
    private static final String FACTORY_CHAT = "Fabrika Hazır Onayı";
    private static final long HEARTBEAT_MS = 6000L;
    private static final long POPUP_SETUP_TIMEOUT_MS = 18000L;
    private static final long CHATGPT_MISSING_GRACE_MS = 20000L;
    private static final long LOCK_RETRY_MS = 90_000L;
    private static final long LOCK_BLOCKED_RETRY_MS = 5L * 60L * 1000L;

    private int popupCloseAttempts = 0;
    private int popupSetupAttempts = 0;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private long lastProcess = 0L;
    private long stateEntered = 0L;
    private String lastState = "";
    private BroadcastReceiver screenReceiver;
    private PowerManager.WakeLock lockedWakeLock;

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        activeInstance = this;
        registerScreenReceiver();
        SharedPreferences p = Prefs.get(this);
        int runtimeVersion = p.getInt(Prefs.RUNTIME_VERSION, 0);
        if (runtimeVersion >= 12 && runtimeVersion < 13) {
            // v0.13 yalnız ürün isimlendirme şemasını değiştirir; aktif v0.12 işi korunur.
            p.edit().putInt(Prefs.RUNTIME_VERSION, 13).apply();
        } else if (runtimeVersion < 12) {
            // v0.12 öncesindeki test state'lerini yeni state makinesine taşımıyoruz.
            p.edit()
                    .putInt(Prefs.RUNTIME_VERSION, 13)
                    .putBoolean(Prefs.ENABLED, false)
                    .putBoolean(Prefs.PAUSED, false)
                    .putBoolean(Prefs.RESUME_AVAILABLE, false)
                    .putString(Prefs.STATE, AutomationState.IDLE)
                    .remove(Prefs.RESUME_REASON)
                    .remove(Prefs.RESUME_TARGET_STATE)
                    .remove(Prefs.LAST_ERROR)
                    .remove(Prefs.NICHE)
                    .remove(Prefs.SUBNICHE)
                    .remove(Prefs.PRODUCT_STARTED)
                    .remove(Prefs.PRODUCT_COMMAND_SENT)
                    .remove(Prefs.DOWNLOAD_REQUESTED_AT)
                .remove(Prefs.EXPECTED_DOWNLOAD_NAME)
                    .remove(Prefs.DOWNLOAD_SNAPSHOT)
                    .remove(Prefs.DOWNLOAD_UI_BASELINE)
                    .remove(Prefs.PRODUCT_ACTIVE_SEEN)
                    .remove(Prefs.CHATGPT_MISSING_SINCE)
                    .remove(Prefs.STALL_ALERTED)
                    .remove(Prefs.LIMIT_RESUME_STATE)
                    .remove(Prefs.LIMIT_UNTIL)
                    .remove(Prefs.UPGRADE_RECOVERY)
                    .putInt(Prefs.POPUP_SETUP_STATE, 0)
                    .remove(Prefs.POPUP_SETUP_STARTED)
                    .putBoolean(Prefs.POPUP_CLOSE_REQUESTED, false)
                    .putBoolean(Prefs.AFTER_LIMIT, false)
                    .putInt(Prefs.ATTEMPTS, 0)
                    .apply();
            NotificationUtil.clearStatus(this);
            return;
        }
        if (p.getBoolean(Prefs.ENABLED, false)) {
            NotificationUtil.status(this, statusText(p));
            scheduleHeartbeat(1000L);
        }
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        SharedPreferences p = Prefs.get(this);
        boolean closeRequested = p.getBoolean(Prefs.POPUP_CLOSE_REQUESTED, false);
        if ((!p.getBoolean(Prefs.ENABLED, false) || p.getBoolean(Prefs.PAUSED, false)) && !closeRequested) return;

        // Düşük güç: esas olarak ChatGPT olaylarıyla uyan. Popup görünürken getWindows()
        // üzerinden ChatGPT penceresini, kurye uygulaması aktif pencere olsa bile bulabiliriz.
        CharSequence pkg = event.getPackageName();
        boolean popupOperation = p.getInt(Prefs.POPUP_SETUP_STATE, 0) > 0 || p.getBoolean(Prefs.POPUP_CLOSE_REQUESTED, false);
        if (!popupOperation && pkg != null && !CHATGPT.contentEquals(pkg)) return;

        long now = System.currentTimeMillis();
        if (now - lastProcess < 350) return;
        lastProcess = now;
        handler.removeCallbacks(processRunnable);
        handler.postDelayed(processRunnable, 250);
    }

    @Override public void onInterrupt() { }

    @Override public void onDestroy() {
        handler.removeCallbacks(processRunnable);
        handler.removeCallbacks(heartbeatRunnable);
        unregisterScreenReceiver();
        releaseLockedWakeLock();
        if (activeInstance == this) activeInstance = null;
        super.onDestroy();
    }

    static void onLockSessionReady(Context context) {
        SharedPreferences p = Prefs.get(context);
        p.edit().putBoolean(Prefs.SCREEN_LOCKED, false)
                .putBoolean(Prefs.LOCK_BLOCKED, false)
                .putBoolean(Prefs.LOCK_BLOCKED_ALERTED, false)
                .remove(Prefs.CHATGPT_MISSING_SINCE)
                .putString(Prefs.STATUS_DETAIL, "Ekran kontrol oturumu açıldı · mevcut ürün devam ediyor")
                .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis()).apply();
        FactoryAccessibilityService s = activeInstance;
        if (s != null) {
            s.releaseLockedWakeLock();
            s.handler.removeCallbacks(s.processRunnable);
            s.handler.postDelayed(s.processRunnable, 450L);
            s.scheduleHeartbeat(1200L);
        }
    }

    static void onLockSessionBlocked(Context context) {
        SharedPreferences p = Prefs.get(context);
        boolean already = p.getBoolean(Prefs.LOCK_BLOCKED_ALERTED, false);
        p.edit().putBoolean(Prefs.SCREEN_LOCKED, true)
                .putBoolean(Prefs.LOCK_BLOCKED, true)
                .putBoolean(Prefs.LOCK_BLOCKED_ALERTED, true)
                .putString(Prefs.STATUS_DETAIL, "Güvenli ekran kilidi bekleniyor · ürün state'i korunuyor")
                .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis()).apply();
        NotificationUtil.status(context, "Ekran kilitli · mevcut ürün korunuyor");
        if (!already) {
            NotificationUtil.alert(context, "Ekran kilidi otomasyonu bekliyor",
                    "Güvenli kilit otomatik açılamadı. Kilidi açınca aynı ürün kaldığı yerden devam eder. Tam otomatik kullanım için Samsung Extend Unlock kullanılabilir.");
        }
        FactoryAccessibilityService s = activeInstance;
        if (s != null) s.scheduleHeartbeat(30_000L);
    }

    private void registerScreenReceiver() {
        if (screenReceiver != null) return;
        screenReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                String action = intent == null ? null : intent.getAction();
                SharedPreferences p = Prefs.get(FactoryAccessibilityService.this);
                if (Intent.ACTION_SCREEN_OFF.equals(action)) {
                    if (p.getBoolean(Prefs.ENABLED, false)) {
                        p.edit().putBoolean(Prefs.SCREEN_LOCKED, true)
                                .putString(Prefs.STATUS_DETAIL, "Ekran kilitli · mevcut ürün korunuyor")
                                .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis()).apply();
                        acquireLockedWakeLock();
                        handler.removeCallbacks(processRunnable);
                        handler.postDelayed(processRunnable, 1200L);
                    }
                } else if (Intent.ACTION_USER_PRESENT.equals(action)) {
                    p.edit().putBoolean(Prefs.SCREEN_LOCKED, false)
                            .putBoolean(Prefs.LOCK_BLOCKED, false)
                            .putBoolean(Prefs.LOCK_BLOCKED_ALERTED, false)
                            .remove(Prefs.CHATGPT_MISSING_SINCE).apply();
                    releaseLockedWakeLock();
                    handler.removeCallbacks(processRunnable);
                    handler.postDelayed(processRunnable, 350L);
                } else if (Intent.ACTION_SCREEN_ON.equals(action)) {
                    handler.removeCallbacks(processRunnable);
                    handler.postDelayed(processRunnable, 500L);
                }
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_SCREEN_ON);
        f.addAction(Intent.ACTION_USER_PRESENT);
        try {
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED);
            else registerReceiver(screenReceiver, f);
        } catch (Throwable ignored) { }
    }

    private void unregisterScreenReceiver() {
        if (screenReceiver == null) return;
        try { unregisterReceiver(screenReceiver); } catch (Throwable ignored) { }
        screenReceiver = null;
    }

    private boolean deviceNeedsWakeSession() {
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        boolean interactive = pm == null || pm.isInteractive();
        boolean keyguard = km != null && km.isKeyguardLocked();
        return !interactive || keyguard;
    }

    private void acquireLockedWakeLock() {
        try {
            if (lockedWakeLock == null) {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                if (pm != null) lockedWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                        getPackageName() + ":factory-lock");
            }
            if (lockedWakeLock != null && !lockedWakeLock.isHeld()) lockedWakeLock.acquire(10L * 60L * 1000L);
        } catch (Throwable ignored) { }
    }

    private void releaseLockedWakeLock() {
        try { if (lockedWakeLock != null && lockedWakeLock.isHeld()) lockedWakeLock.release(); }
        catch (Throwable ignored) { }
    }

    private void handleLockedDevice(SharedPreferences p) {
        acquireLockedWakeLock();
        long now = System.currentTimeMillis();
        boolean blocked = p.getBoolean(Prefs.LOCK_BLOCKED, false);
        long last = p.getLong(Prefs.LAST_UNLOCK_ATTEMPT, 0L);
        long retry = blocked ? LOCK_BLOCKED_RETRY_MS : LOCK_RETRY_MS;
        p.edit().putBoolean(Prefs.SCREEN_LOCKED, true)
                .remove(Prefs.CHATGPT_MISSING_SINCE)
                .putString(Prefs.STATUS_DETAIL, blocked
                        ? "Güvenli ekran kilidi bekleniyor · ürün state'i korunuyor"
                        : "Ekran kilitli · ChatGPT kontrolü otomatik hazırlanıyor")
                .putLong(Prefs.STATUS_UPDATED, now).apply();
        if (now - last >= retry) {
            p.edit().putLong(Prefs.LAST_UNLOCK_ATTEMPT, now).apply();
            try {
                Intent i = new Intent(this, LockWakeActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                startActivity(i);
            } catch (Throwable t) {
                onLockSessionBlocked(this);
            }
        }
        scheduleHeartbeat(blocked ? 30_000L : 8_000L);
    }

    static void kickIfVisible() {
        FactoryAccessibilityService s = activeInstance;
        if (s == null) return;
        s.handler.removeCallbacks(s.processRunnable);
        s.handler.postDelayed(s.processRunnable, 150);
        s.scheduleHeartbeat(1200L);
    }

    static boolean requestAutoPopupStart(Context context) {
        SharedPreferences p = Prefs.get(context);
        p.edit()
                .putInt(Prefs.POPUP_SETUP_STATE, 1)
                .putLong(Prefs.POPUP_SETUP_STARTED, System.currentTimeMillis())
                .putBoolean(Prefs.POPUP_CLOSE_REQUESTED, false)
                .putString(Prefs.STATUS_DETAIL, "ChatGPT açılır penceresi hazırlanıyor")
                .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis())
                .apply();
        boolean launched = AppLauncher.openChatGPTPopup(context);
        FactoryAccessibilityService s = activeInstance;
        if (s != null) {
            s.popupSetupAttempts = 0;
            s.handler.removeCallbacks(s.processRunnable);
            s.handler.postDelayed(s.processRunnable, 700);
            s.scheduleHeartbeat(1200L);
        }
        return launched;
    }

    /** Kullanıcının açıkça Durdur demesi mevcut işi iptal eder. */
    static void stopAndClose(Context context) {
        SharedPreferences p = Prefs.get(context);
        p.edit()
                .putBoolean(Prefs.ENABLED, false)
                .putBoolean(Prefs.PAUSED, false)
                .putBoolean(Prefs.RESUME_AVAILABLE, false)
                .putString(Prefs.STATE, AutomationState.IDLE)
                .remove(Prefs.RESUME_REASON)
                .remove(Prefs.RESUME_TARGET_STATE)
                .remove(Prefs.LAST_ERROR)
                .remove(Prefs.NICHE)
                .remove(Prefs.SUBNICHE)
                .remove(Prefs.PRODUCT_STARTED)
                .remove(Prefs.PRODUCT_COMMAND_SENT)
                .remove(Prefs.DOWNLOAD_REQUESTED_AT)
                .remove(Prefs.EXPECTED_DOWNLOAD_NAME)
                .remove(Prefs.DOWNLOAD_SNAPSHOT)
                .remove(Prefs.DOWNLOAD_UI_BASELINE)
                .remove(Prefs.PRODUCT_ACTIVE_SEEN)
                .remove(Prefs.CHATGPT_MISSING_SINCE)
                .remove(Prefs.STALL_ALERTED)
                .putBoolean(Prefs.SCREEN_LOCKED, false)
                .putBoolean(Prefs.LOCK_BLOCKED, false)
                .putBoolean(Prefs.LOCK_BLOCKED_ALERTED, false)
                .remove(Prefs.LAST_UNLOCK_ATTEMPT)
                .remove(Prefs.LIMIT_RESUME_STATE)
                .remove(Prefs.LIMIT_UNTIL)
                .putBoolean(Prefs.AFTER_LIMIT, false)
                .putInt(Prefs.POPUP_SETUP_STATE, 0)
                .putBoolean(Prefs.POPUP_CLOSE_REQUESTED, true)
                .putString(Prefs.STATUS_DETAIL, "Fabrika durduruldu")
                .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis())
                .commit();
        requestCloseProcessing(context);
    }

    /**
     * Uygulama görevi veya ChatGPT kapanırsa işi iptal etmez. State, niş, ürün başlangıç
     * snapshot'ı ve gönderilmiş komut korunur; kullanıcı daha sonra Üretime devam et der.
     */
    static void interruptAndClose(Context context, String reason) {
        SharedPreferences p = Prefs.get(context);
        String current = p.getString(Prefs.STATE, AutomationState.IDLE);
        String resumeTarget = AutomationState.RESUME_ROUTE.equals(current)
                ? p.getString(Prefs.RESUME_TARGET_STATE, current) : current;
        if (!hasResumableWork(p)) {
            stopAndClose(context);
            return;
        }
        p.edit()
                .putBoolean(Prefs.ENABLED, false)
                .putBoolean(Prefs.PAUSED, false)
                .putBoolean(Prefs.RESUME_AVAILABLE, true)
                .putString(Prefs.RESUME_TARGET_STATE, resumeTarget)
                .putString(Prefs.RESUME_REASON, reason == null ? "Üretim kesildi" : reason)
                .remove(Prefs.LAST_ERROR)
                .remove(Prefs.CHATGPT_MISSING_SINCE)
                .putInt(Prefs.POPUP_SETUP_STATE, 0)
                .putBoolean(Prefs.POPUP_CLOSE_REQUESTED, true)
                .putString(Prefs.STATUS_DETAIL, "Üretim kesildi · kaldığı yerden devam edilebilir")
                .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis())
                .commit();
        NotificationUtil.status(context, "Üretim kesildi · uygulamadan devam et");
        requestCloseProcessing(context);
    }

    private static void interruptWithoutClose(Context context, String reason) {
        SharedPreferences p = Prefs.get(context);
        String current = p.getString(Prefs.STATE, AutomationState.IDLE);
        String resumeTarget = AutomationState.RESUME_ROUTE.equals(current)
                ? p.getString(Prefs.RESUME_TARGET_STATE, current) : current;
        if (!hasResumableWork(p)) return;
        p.edit()
                .putBoolean(Prefs.ENABLED, false)
                .putBoolean(Prefs.PAUSED, false)
                .putBoolean(Prefs.RESUME_AVAILABLE, true)
                .putString(Prefs.RESUME_TARGET_STATE, resumeTarget)
                .putString(Prefs.RESUME_REASON, reason == null ? "ChatGPT penceresi kapandı" : reason)
                .remove(Prefs.LAST_ERROR)
                .remove(Prefs.CHATGPT_MISSING_SINCE)
                .putString(Prefs.STATUS_DETAIL, "Üretim kesildi · kaldığı yerden devam edilebilir")
                .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis())
                .apply();
        NotificationUtil.status(context, "Üretim kesildi · uygulamadan devam et");
        NotificationUtil.alert(context, "Üretim beklemede", "PNG Fabrikası'nı açıp Üretime devam et seçeneğine dokun.");
    }

    private static boolean hasResumableWork(SharedPreferences p) {
        String state = p.getString(Prefs.STATE, AutomationState.IDLE);
        return !AutomationState.IDLE.equals(state) && !AutomationState.ERROR.equals(state);
    }

    private static void requestCloseProcessing(Context context) {
        FactoryAccessibilityService s = activeInstance;
        if (s != null) {
            s.popupCloseAttempts = 0;
            s.handler.removeCallbacks(s.processRunnable);
            s.handler.post(s.processRunnable);
        } else {
            NotificationUtil.clearStatus(context);
        }
    }

    private final Runnable processRunnable = new Runnable() {
        @Override public void run() { process(); }
    };

    private final Runnable heartbeatRunnable = new Runnable() {
        @Override public void run() {
            SharedPreferences p = Prefs.get(FactoryAccessibilityService.this);
            if (p.getBoolean(Prefs.POPUP_CLOSE_REQUESTED, false)) {
                process();
                return;
            }
            if (!p.getBoolean(Prefs.ENABLED, false)) {
                releaseLockedWakeLock();
                return;
            }
            if (p.getBoolean(Prefs.PAUSED, false)) {
                // Limit/manual pause sırasında üretim yapma; yalnız Agent task'ı gerçekten
                // kapatıldı mı diye seyrek kontrol et ki ChatGPT popup açık kalmasın.
                if (!ownTaskExists()) {
                    interruptAndClose(FactoryAccessibilityService.this, "PNG Fabrikası uygulaması kapandı");
                    return;
                }
                scheduleHeartbeat(15000L);
                return;
            }
            process();
        }
    };

    private void scheduleHeartbeat(long delay) {
        handler.removeCallbacks(heartbeatRunnable);
        handler.postDelayed(heartbeatRunnable, delay);
    }

    private void userStatus(String detail) {
        if (detail == null) detail = "";
        SharedPreferences p = Prefs.get(this);
        if (detail.equals(p.getString(Prefs.STATUS_DETAIL, ""))) return;
        p.edit().putString(Prefs.STATUS_DETAIL, detail)
                .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis()).apply();
    }

    /**
     * Popup Engine'in temel farkı: aktif pencereyi değil, tüm interaktif accessibility
     * pencerelerini tarar. Böylece kurye uygulaması odakta kalırken ekranda açık olan
     * ChatGPT Samsung popup penceresinin kök ağacına erişebiliriz.
     */
    private AccessibilityNodeInfo findChatGptRoot() {
        List<AccessibilityWindowInfo> windows = getWindows();
        if (windows != null) {
            AccessibilityNodeInfo fallback = null;
            int bestLayer = Integer.MIN_VALUE;
            for (AccessibilityWindowInfo w : windows) {
                if (w == null) continue;
                AccessibilityNodeInfo root = null;
                try { root = w.getRoot(); } catch (Throwable ignored) { }
                if (root == null) continue;
                CharSequence pkg = root.getPackageName();
                if (pkg == null || !CHATGPT.contentEquals(pkg)) continue;

                // Üst katmandaki görünür ChatGPT penceresini tercih et. Samsung popup genelde
                // ana uygulama penceresinin üzerinde ayrı bir application window olarak görünür.
                if (w.getLayer() >= bestLayer) {
                    fallback = root;
                    bestLayer = w.getLayer();
                }
            }
            if (fallback != null) return fallback;
        }

        // Tam ekran testinde / bazı One UI sürümlerinde yedek yol.
        AccessibilityNodeInfo active = getRootInActiveWindow();
        if (active != null && active.getPackageName() != null && CHATGPT.contentEquals(active.getPackageName())) return active;
        return null;
    }


    private boolean ownTaskExists() {
        try {
            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            List<ActivityManager.AppTask> tasks = am == null ? null : am.getAppTasks();
            return tasks != null && !tasks.isEmpty();
        } catch (Throwable ignored) {
            return true;
        }
    }

    private AccessibilityWindowInfo findChatGptWindow() {
        List<AccessibilityWindowInfo> windows = getWindows();
        if (windows == null) return null;
        AccessibilityWindowInfo best = null;
        int layer = Integer.MIN_VALUE;
        for (AccessibilityWindowInfo w : windows) {
            if (w == null) continue;
            AccessibilityNodeInfo root = null;
            try { root = w.getRoot(); } catch (Throwable ignored) { }
            if (root == null || root.getPackageName() == null || !CHATGPT.contentEquals(root.getPackageName())) continue;
            if (w.getLayer() >= layer) { best = w; layer = w.getLayer(); }
        }
        return best;
    }

    private boolean isPopup(AccessibilityWindowInfo w) {
        if (w == null) return false;
        Rect b = new Rect();
        try { w.getBoundsInScreen(b); } catch (Throwable ignored) { return false; }
        int sw = Math.max(1, getResources().getDisplayMetrics().widthPixels);
        int sh = Math.max(1, getResources().getDisplayMetrics().heightPixels);
        return b.width() < sw * 0.90f || b.height() < sh * 0.82f;
    }

    private AccessibilityNodeInfo findAcrossSystemUi(String... needles) {
        List<AccessibilityWindowInfo> windows = getWindows();
        if (windows == null) return null;
        for (int i = windows.size() - 1; i >= 0; i--) {
            AccessibilityWindowInfo w = windows.get(i);
            if (w == null) continue;
            AccessibilityNodeInfo root = null;
            try { root = w.getRoot(); } catch (Throwable ignored) { }
            if (root == null) continue;
            CharSequence pkg = root.getPackageName();
            if (pkg != null && CHATGPT.contentEquals(pkg)) continue;
            AccessibilityNodeInfo n = NodeUtil.findByTextOrDescription(root, needles);
            if (n != null) return n;
        }
        return null;
    }

    private void handlePopupSetup() {
        SharedPreferences p = Prefs.get(this);
        long started = p.getLong(Prefs.POPUP_SETUP_STARTED, System.currentTimeMillis());
        if (System.currentTimeMillis() - started > POPUP_SETUP_TIMEOUT_MS) {
            p.edit().putInt(Prefs.POPUP_SETUP_STATE, 0).apply();
            String st = p.getString(Prefs.STATE, AutomationState.IDLE);
            if (AutomationState.RESUME_ROUTE.equals(st) || p.getBoolean(Prefs.PRODUCT_COMMAND_SENT, false)) {
                interruptWithoutClose(this, "ChatGPT popup yeniden açılamadı");
            } else {
                fail("Popup açılamadı", "ChatGPT Samsung Açılır görünümü otomatik oluşturulamadı. One UI arayüzü değişmiş olabilir.");
            }
            return;
        }

        int phase = p.getInt(Prefs.POPUP_SETUP_STATE, 1);
        AccessibilityWindowInfo chatWindow = findChatGptWindow();
        if (chatWindow != null && isPopup(chatWindow)) {
            p.edit().putInt(Prefs.POPUP_SETUP_STATE, 0).remove(Prefs.POPUP_SETUP_STARTED).apply();
            NotificationUtil.status(this, "ChatGPT popup hazır · üretim başlıyor");
            handler.postDelayed(processRunnable, 450);
            return;
        }

        if (phase == 1) {
            if (chatWindow == null) {
                handler.postDelayed(processRunnable, 700);
                return;
            }
            performGlobalAction(GLOBAL_ACTION_RECENTS);
            p.edit().putInt(Prefs.POPUP_SETUP_STATE, 2).apply();
            handler.postDelayed(processRunnable, 850);
            return;
        }

        if (phase == 2) {
            AccessibilityNodeInfo chat = findAcrossSystemUi("ChatGPT");
            if (chat != null && NodeUtil.click(chat)) {
                p.edit().putInt(Prefs.POPUP_SETUP_STATE, 3).apply();
                handler.postDelayed(processRunnable, 650);
                return;
            }
            popupSetupAttempts++;
            if (popupSetupAttempts <= 2) {
                handler.postDelayed(processRunnable, 600);
                return;
            }
            // Samsung Recents'te uygulama ikonunun bulunduğu üst-orta bölgeye son çare dokunma.
            int sw = getResources().getDisplayMetrics().widthPixels;
            int sh = getResources().getDisplayMetrics().heightPixels;
            dispatchTap(sw * 0.50f, sh * 0.16f);
            p.edit().putInt(Prefs.POPUP_SETUP_STATE, 3).apply();
            handler.postDelayed(processRunnable, 650);
            return;
        }

        if (phase == 3) {
            AccessibilityNodeInfo popup = findAcrossSystemUi(
                    "Açılır görünümde aç", "Acilir gorunumde ac", "Açılır görünüm", "Acilir gorunum",
                    "Open in pop-up view", "Pop-up view");
            if (popup != null && NodeUtil.click(popup)) {
                p.edit().putInt(Prefs.POPUP_SETUP_STATE, 4).apply();
                handler.postDelayed(processRunnable, 900);
                return;
            }
            popupSetupAttempts++;
            if (popupSetupAttempts % 3 == 0) {
                p.edit().putInt(Prefs.POPUP_SETUP_STATE, 2).apply();
            }
            handler.postDelayed(processRunnable, 650);
            return;
        }

        handler.postDelayed(processRunnable, 700);
    }

    private void handlePopupClose() {
        SharedPreferences p = Prefs.get(this);
        AccessibilityWindowInfo w = findChatGptWindow();
        if (w == null) {
            finishPopupClose();
            return;
        }

        Rect wb = new Rect();
        try { w.getBoundsInScreen(wb); } catch (Throwable ignored) { }

        if (popupCloseAttempts < 3) {
            AccessibilityNodeInfo close = findAcrossSystemUi("Pencereyi kapat", "Kapat", "Close window", "Close");
            if (close != null && NodeUtil.click(close)) {
                popupCloseAttempts++;
                handler.postDelayed(processRunnable, 600);
                return;
            }
        }

        // Samsung popup araç çubuğu görünmüyorsa pencerenin üst tutamacına dokunup tekrar ara.
        if (popupCloseAttempts < 2 && !wb.isEmpty()) {
            popupCloseAttempts++;
            dispatchTap(wb.exactCenterX(), wb.top + Math.max(12, Math.min(38, wb.height() / 18)));
            handler.postDelayed(processRunnable, 550);
            return;
        }

        // Son çare: Recents üzerinden yalnız ChatGPT görevini yukarı süpür.
        if (popupCloseAttempts == 2) {
            popupCloseAttempts++;
            performGlobalAction(GLOBAL_ACTION_RECENTS);
            handler.postDelayed(processRunnable, 800);
            return;
        }

        if (popupCloseAttempts <= 5) {
            AccessibilityNodeInfo chat = findAcrossSystemUi("ChatGPT");
            if (chat != null) {
                Rect b = largestUsefulBounds(chat);
                if (!b.isEmpty()) {
                    popupCloseAttempts = 6;
                    dispatchSwipe(b.exactCenterX(), b.exactCenterY(), b.exactCenterX(), Math.max(5, b.top - b.height()));
                    handler.postDelayed(processRunnable, 900);
                    return;
                }
            }
            popupCloseAttempts++;
            handler.postDelayed(processRunnable, 500);
            return;
        }

        // Kapatma başarısızsa fabrikanın kendisi yine kapalı kalır; kullanıcıya yalnız bir uyarı ver.
        p.edit().putBoolean(Prefs.POPUP_CLOSE_REQUESTED, false).apply();
        NotificationUtil.clearStatus(this);
        NotificationUtil.alert(this, "ChatGPT popup kapanmadı", "Fabrika durdu ancak Samsung popup kapatma kontrolü bulunamadı.");
    }

    private void finishPopupClose() {
        Prefs.get(this).edit()
                .putBoolean(Prefs.POPUP_CLOSE_REQUESTED, false)
                .putInt(Prefs.POPUP_SETUP_STATE, 0)
                .remove(Prefs.POPUP_SETUP_STARTED)
                .apply();
        popupCloseAttempts = 0;
        NotificationUtil.clearStatus(this);
    }

    private Rect largestUsefulBounds(AccessibilityNodeInfo node) {
        Rect best = new Rect();
        AccessibilityNodeInfo p = node;
        int sw = getResources().getDisplayMetrics().widthPixels;
        int sh = getResources().getDisplayMetrics().heightPixels;
        for (int i = 0; p != null && i < 7; i++, p = p.getParent()) {
            Rect b = new Rect();
            p.getBoundsInScreen(b);
            if (b.isEmpty()) continue;
            long area = (long)b.width() * b.height();
            long bestArea = (long)best.width() * best.height();
            if (area > bestArea && b.width() < sw * 0.95f && b.height() < sh * 0.90f) best.set(b);
        }
        if (best.isEmpty()) node.getBoundsInScreen(best);
        return best;
    }

    private void dispatchTap(float x, float y) {
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, 80);
        dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
    }

    private void dispatchSwipe(float x1, float y1, float x2, float y2) {
        Path path = new Path();
        path.moveTo(x1, y1);
        path.lineTo(x2, y2);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, 320);
        dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
    }

    private void process() {
        SharedPreferences p = Prefs.get(this);

        if (p.getBoolean(Prefs.POPUP_CLOSE_REQUESTED, false)) {
            handlePopupClose();
            return;
        }
        if (!p.getBoolean(Prefs.ENABLED, false) || p.getBoolean(Prefs.PAUSED, false)) return;

        // Ekran/keyguard kapalıyken ChatGPT penceresini "kayboldu" sayma. Kısa bir
        // wake+dismiss oturumu açmayı dener; güvenli kilit izin vermezse state'i korur.
        if (deviceNeedsWakeSession()) {
            handleLockedDevice(p);
            return;
        }
        if (p.getBoolean(Prefs.SCREEN_LOCKED, false) || p.getBoolean(Prefs.LOCK_BLOCKED, false)) {
            p.edit().putBoolean(Prefs.SCREEN_LOCKED, false)
                    .putBoolean(Prefs.LOCK_BLOCKED, false)
                    .putBoolean(Prefs.LOCK_BLOCKED_ALERTED, false)
                    .remove(Prefs.LAST_UNLOCK_ATTEMPT)
                    .remove(Prefs.CHATGPT_MISSING_SINCE).apply();
            releaseLockedWakeLock();
        }

        // Kullanıcı Agent görevini Son Uygulamalar'dan kaldırdıysa fabrika da kapanır.
        // Home/başka uygulamaya geçişte görev Recents'te kaldığı için bu tetiklenmez.
        if (!ownTaskExists()) {
            interruptAndClose(this, "PNG Fabrikası uygulaması kapandı");
            return;
        }

        if (p.getInt(Prefs.POPUP_SETUP_STATE, 0) > 0) {
            handlePopupSetup();
            return;
        }

        String state = p.getString(Prefs.STATE, AutomationState.OPEN_NICHE_CHAT);

        // Limit alarmından aynı state'e döndüğümüzde eski stateEntered süresi taşınırsa
        // WAIT_PRODUCT 4 dakikalık timeout'u anında tetiklenebiliyor. Limit sonrası
        // state zamanlayıcısını sıfırla ve ChatGPT'nin kaldığı işi toparlaması için yeni
        // bir bekleme penceresi ver.
        if (p.getBoolean(Prefs.AFTER_LIMIT, false)) {
            lastState = "";
            stateEntered = System.currentTimeMillis();
        }
        if (!state.equals(lastState)) {
            lastState = state;
            stateEntered = System.currentTimeMillis();
        }

        // Ana güvenlik kuralı: bir üretim komutu gönderildiyse final ZIP hedef klasörde
        // doğrulanmadan state'in yeni niş/ürün aşamasına kaçmasına izin verme.
        boolean productCommandSent = p.getBoolean(Prefs.PRODUCT_COMMAND_SENT, false);
        if (productCommandSent
                && !AutomationState.WAIT_PRODUCT.equals(state)
                && !AutomationState.ARCHIVE.equals(state)
                && !AutomationState.RESUME_ROUTE.equals(state)) {
            int seq = p.getInt(Prefs.PRODUCT_SEQ, 1);
            String niche = p.getString(Prefs.NICHE, "");
            String sub = p.getString(Prefs.SUBNICHE, "product");
            long started = p.getLong(Prefs.PRODUCT_STARTED, 0L);
            if (StorageUtil.hasVerifiedProductZip(this, seq, niche, sub, started)) {
                completeCurrentProduct();
            } else {
                p.edit().putString(Prefs.STATE, AutomationState.WAIT_PRODUCT)
                        .putString(Prefs.STATUS_DETAIL, "Önce mevcut ürünün final ZIP'i tamamlanıyor")
                        .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis()).apply();
                lastState = "";
            }
            scheduleHeartbeat(700L);
            return;
        }

        // Arşivleme ChatGPT penceresine bağlı değildir.
        if (AutomationState.ARCHIVE.equals(state)) {
            try { archiveAndNext(); }
            catch (Throwable t) { fail("Arşivleme hatası", t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage())); }
            scheduleHeartbeat(HEARTBEAT_MS);
            return;
        }

        AccessibilityNodeInfo root = findChatGptRoot();
        if (root == null) {
            long now = System.currentTimeMillis();
            long missingSince = p.getLong(Prefs.CHATGPT_MISSING_SINCE, 0L);
            if (missingSince == 0L) {
                p.edit().putLong(Prefs.CHATGPT_MISSING_SINCE, now).apply();
                missingSince = now;
            }
            userStatus("ChatGPT açılır penceresi bekleniyor");
            NotificationUtil.status(this, popupWaitingStatusText(p));
            if (now - missingSince >= CHATGPT_MISSING_GRACE_MS) {
                interruptWithoutClose(this, "ChatGPT açılır penceresi kapandı");
                return;
            }
            scheduleHeartbeat(HEARTBEAT_MS);
            return;
        }
        if (p.contains(Prefs.CHATGPT_MISSING_SINCE)) p.edit().remove(Prefs.CHATGPT_MISSING_SINCE).apply();

        String dump = NodeUtil.dumpText(root);
        p.edit().putString(Prefs.LAST_TREE, dump.length() > 30000 ? dump.substring(0, 30000) : dump).apply();
        NotificationUtil.status(this, statusText(p));

        if (LimitUtil.looksLimited(dump) && !AutomationState.ERROR.equals(state)) {
            long until = LimitUtil.estimateUntil(dump);
            p.edit()
                    .putString(Prefs.LIMIT_RESUME_STATE, state)
                    .putLong(Prefs.LIMIT_UNTIL, until)
                    .putBoolean(Prefs.PAUSED, true)
                    .remove(Prefs.LAST_ERROR)
                    .putString(Prefs.STATUS_DETAIL, "ChatGPT kullanım hakkının yenilenmesi bekleniyor")
                    .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis())
                    .apply();
            LimitUtil.schedule(this, until);
            NotificationUtil.status(this, "ChatGPT kullanım hakkı · yenilenme saati bekleniyor");
            scheduleHeartbeat(15000L);
            return;
        }

        if (p.getBoolean(Prefs.AFTER_LIMIT, false)) {
            AccessibilityNodeInfo retry = NodeUtil.findByTextOrDescription(root, "tekrar dene", "yeniden dene", "retry", "try again", "devam et", "continue");
            if (retry != null) NodeUtil.click(retry);
            p.edit().putBoolean(Prefs.AFTER_LIMIT, false).apply();
        }

        try {
            switch (state) {
                case AutomationState.OPEN_NICHE_CHAT:
                    openChat(root, NICHE_CHAT, AutomationState.SEND_NICHE);
                    break;
                case AutomationState.SEND_NICHE:
                    sendText(root, "niş bul", AutomationState.WAIT_NICHE_REPLY, true);
                    break;
                case AutomationState.WAIT_NICHE_REPLY:
                    waitNiche(root, dump);
                    break;
                case AutomationState.OPEN_FACTORY_CHAT:
                    openChat(root, FACTORY_CHAT, AutomationState.SEND_FACTORY);
                    break;
                case AutomationState.SEND_FACTORY:
                    // Geçmiş mesajlardaki "Çalışıyor"/"Gönderilmeyi bekliyor" metinlerine bakma.
                    // Yalnız ekrandaki GERÇEK aktif Dur düğmesi yeni komut göndermeyi engeller.
                    if (NodeUtil.hasActiveStopControl(root) || NodeUtil.generatingNearBottom(dump) || NodeUtil.queuedNearBottom(dump)) {
                        userStatus("Fabrika sohbetindeki mevcut işin bitmesi bekleniyor");
                        NotificationUtil.status(this, "Fabrika şu an meşgul · yeni komut gönderilmiyor");
                        break;
                    }
                    String niche = p.getString(Prefs.NICHE, "");
                    String sub = p.getString(Prefs.SUBNICHE, "");
                    String cmd = "üretime başla | niş: " + niche + " | alt niş: " + sub;
                    sendText(root, cmd, AutomationState.WAIT_PRODUCT, false);
                    break;
                case AutomationState.WAIT_PRODUCT:
                    waitProduct(root, dump);
                    break;
                case AutomationState.RESUME_ROUTE:
                    resumeRoute(root, dump);
                    break;
                case AutomationState.ERROR:
                case AutomationState.IDLE:
                default:
                    break;
            }
        } catch (Throwable t) {
            fail("Otomasyon hatası", t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage()));
        }

        if (p.getBoolean(Prefs.ENABLED, false) && !p.getBoolean(Prefs.PAUSED, false)) scheduleHeartbeat(HEARTBEAT_MS);
    }

    private void openChat(AccessibilityNodeInfo root, String title, String nextState) {
        AccessibilityNodeInfo chat = NodeUtil.findTextLoose(root, title);
        if (chat != null && NodeUtil.click(chat)) {
            transition(nextState, "Sohbet açıldı: " + title);
            return;
        }
        if (elapsed() > 45_000) {
            fail("Sohbet bulunamadı", title + " sohbeti ChatGPT popup penceresinde bulunamadı. Popup çok küçükse biraz büyütüp tekrar dene.");
            return;
        }
        if (NodeUtil.openDrawerFallback(this, root)) {
            handler.removeCallbacks(processRunnable);
            handler.postDelayed(processRunnable, 1000);
        }
    }

    private void sendText(AccessibilityNodeInfo root, String text, String nextState, boolean nicheStep) {
        AccessibilityNodeInfo input = NodeUtil.findEditable(root);
        if (input == null) {
            if (elapsed() > 25_000) fail("Mesaj alanı bulunamadı", "ChatGPT popup penceresi mesaj alanını göstermiyor. Popup'ı biraz büyütüp tekrar dene.");
            return;
        }
        if (!NodeUtil.setTextPopupSafe(input, text)) return;
        SharedPreferences p = Prefs.get(this);
        String uiBaseline = nicheStep ? "" : NodeUtil.downloadBaseline(root);
        AccessibilityNodeInfo send = NodeUtil.findByTextOrDescription(root, "gönder", "gonder", "send message", "send");
        if (send != null && NodeUtil.click(send)) {
            SharedPreferences.Editor e = p.edit().putString(Prefs.STATE, nextState)
                    .putLong(Prefs.LAST_ACTION, System.currentTimeMillis())
                    .putString(Prefs.STATUS_DETAIL, nicheStep ? "Niş sonucu bekleniyor" : "Üretim komutu gönderildi; ChatGPT çalışması bekleniyor")
                    .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis());
            if (!nicheStep) {
                long now = System.currentTimeMillis();
                e.putLong(Prefs.PRODUCT_STARTED, now)
                        .putString(Prefs.DOWNLOAD_SNAPSHOT, StorageUtil.snapshot(this))
                        .putString(Prefs.DOWNLOAD_UI_BASELINE, uiBaseline)
                        .putBoolean(Prefs.PRODUCT_COMMAND_SENT, true)
                        .remove(Prefs.DOWNLOAD_REQUESTED_AT)
                .remove(Prefs.EXPECTED_DOWNLOAD_NAME)
                        .putBoolean(Prefs.PRODUCT_ACTIVE_SEEN, false)
                        .putBoolean(Prefs.STALL_ALERTED, false);
            }
            if (nicheStep) e.apply(); else e.commit();
            lastState = "";
            NotificationUtil.status(this, statusText(p));
        } else if (elapsed() > 25_000) {
            fail("Gönder düğmesi bulunamadı", "Mesaj yazıldı ancak ChatGPT popup penceresindeki gönder düğmesi algılanamadı.");
        }
    }

    private void waitNiche(AccessibilityNodeInfo root, String dump) {
        if (NodeUtil.looksGenerating(dump)) {
            userStatus("ChatGPT yeni nişleri araştırıyor");
            return;
        }
        if (elapsed() < 6_000) return;
        String[] parsed = NicheParser.parse(dump);
        if (parsed != null) {
            Prefs.get(this).edit()
                    .putString(Prefs.NICHE, parsed[0])
                    .putString(Prefs.SUBNICHE, parsed[1])
                    .putString(Prefs.STATE, AutomationState.OPEN_FACTORY_CHAT)
                    .putString(Prefs.STATUS_DETAIL, "Niş bulundu; fabrika sohbetine geçiliyor")
                    .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis())
                    .putInt(Prefs.ATTEMPTS, 0)
                    .apply();
            lastState = "";
            handler.postDelayed(processRunnable, 500);
            return;
        }
        if (elapsed() > 180_000) fail("Niş okunamadı", "Cevap tamamlandı ancak niş ve alt niş sonucu okunamadı.");
    }

    private void waitProduct(AccessibilityNodeInfo root, String dump) {
        SharedPreferences p = Prefs.get(this);
        int seq = p.getInt(Prefs.PRODUCT_SEQ, 1);
        String niche = p.getString(Prefs.NICHE, "");
        String sub = p.getString(Prefs.SUBNICHE, "product");
        long started = p.getLong(Prefs.PRODUCT_STARTED, 0L);
        String snapshot = p.getString(Prefs.DOWNLOAD_SNAPSHOT, "");

        // 1) Hedef ürün klasöründe final ZIP zaten doğrulanmışsa bu ürün tamamdır.
        // Bu kontrol özellikle uygulama arşivlemeden hemen sonra kapanırsa işe yarar.
        if (StorageUtil.hasVerifiedProductZip(this, seq, niche, sub, started)) {
            completeCurrentProduct();
            return;
        }

        boolean generating = NodeUtil.hasActiveStopControl(root) || NodeUtil.generatingNearBottom(dump);
        boolean queued = !generating && NodeUtil.latestFactoryQueued(dump,
                p.getString(Prefs.NICHE, ""), p.getString(Prefs.SUBNICHE, ""));

        if (queued) {
            userStatus("Üretim komutu ChatGPT'de sırada bekliyor");
            return;
        }

        if (generating) {
            if (!p.getBoolean(Prefs.PRODUCT_ACTIVE_SEEN, false)) {
                p.edit().putBoolean(Prefs.PRODUCT_ACTIVE_SEEN, true)
                        .putString(Prefs.STATUS_DETAIL, "ChatGPT mevcut ürünü üretiyor")
                        .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis()).apply();
            } else {
                userStatus("ChatGPT mevcut ürünü üretiyor");
            }
            return;
        }

        // Üretim aktif değilken final ZIP fiziksel olarak Download'a zaten düştüyse
        // arşivlemeye geç. Aktif çalışma varken ZIP görsek bile ürünün bitmesini bekleriz.
        if (StorageUtil.hasNewZipInDownload(this, snapshot, started)) {
            transition(AutomationState.ARCHIVE, "Final ZIP bulundu; ürün klasörüne aktarılıyor");
            return;
        }

        // Stop/Çalışıyor kontrolünün kaybolması TAMAMLANDI demek değildir. Final ZIP UI'da
        // görünene kadar bu state'te kal. Böylece ara tool/image adımlarında yeni ürüne geçilmez.
        List<AccessibilityNodeInfo> files = NodeUtil.newClickableZipDownloads(root,
                p.getString(Prefs.DOWNLOAD_UI_BASELINE, ""));
        if (!files.isEmpty()) {
            // Baseline sonrasında oluşan ZIP'ler içinden en son görüneni final çıktı kabul et.
            // Tek dosyayı indir; eski/başka ürün dosyalarının karışmasını engelle.
            AccessibilityNodeInfo finalZipNode = files.get(files.size() - 1);
            String expectedName = NodeUtil.downloadFileName(finalZipNode);
            if (NodeUtil.click(finalZipNode)) {
                long now = System.currentTimeMillis();
                SharedPreferences.Editor e = p.edit()
                        .putLong(Prefs.DOWNLOAD_REQUESTED_AT, now)
                        .putString(Prefs.STATUS_DETAIL, "Final ZIP indiriliyor; fiziksel dosya doğrulanıyor")
                        .putLong(Prefs.STATUS_UPDATED, now);
                if (!expectedName.isEmpty()) e.putString(Prefs.EXPECTED_DOWNLOAD_NAME, expectedName);
                else e.remove(Prefs.EXPECTED_DOWNLOAD_NAME);
                e.apply();
                transition(AutomationState.ARCHIVE, "Final ZIP indiriliyor; fiziksel dosya doğrulanıyor");
                return;
            }
        }

        userStatus("ChatGPT yanıtı ve final ZIP bekleniyor");
        long age = started <= 0 ? 0L : System.currentTimeMillis() - started;
        if (age > 60L * 60L * 1000L && !p.getBoolean(Prefs.STALL_ALERTED, false)) {
            p.edit().putBoolean(Prefs.STALL_ALERTED, true).apply();
            NotificationUtil.alert(this, "Üretim uzun sürüyor", "Mevcut ürün hâlâ final ZIP bekliyor. Yeni ürüne geçilmedi.");
        }
    }

    private void archiveAndNext() throws Exception {
        SharedPreferences p = Prefs.get(this);
        int seq = p.getInt(Prefs.PRODUCT_SEQ, 1);
        String niche = p.getString(Prefs.NICHE, "");
        String sub = p.getString(Prefs.SUBNICHE, "product");
        long started = p.getLong(Prefs.PRODUCT_STARTED, 0L);
        String snapshot = p.getString(Prefs.DOWNLOAD_SNAPSHOT, "");

        // Uygulama copy işleminden sonra kapanmışsa tekrar kopyalamadan doğrula.
        if (StorageUtil.hasVerifiedProductZip(this, seq, niche, sub, started)) {
            completeCurrentProduct();
            return;
        }

        int count = StorageUtil.archiveNewFiles(this, seq, niche, sub, snapshot, started);
        if (count > 0 && StorageUtil.hasVerifiedProductZip(this, seq, niche, sub, started)) {
            completeCurrentProduct();
            return;
        }

        // Android indirme yöneticisinin dosyayı SAF ağacında görünür kılması zaman alabilir.
        // Asla yeni ürüne atlama. 30 sn sonra ChatGPT final ZIP düğmesini tekrar kontrol et.
        long requested = p.getLong(Prefs.DOWNLOAD_REQUESTED_AT, 0L);
        if (requested > 0 && System.currentTimeMillis() - requested > 30_000L) {
            p.edit().putString(Prefs.STATE, AutomationState.WAIT_PRODUCT)
                    .putString(Prefs.STATUS_DETAIL, "İndirme henüz görünmedi; final ZIP tekrar kontrol ediliyor")
                    .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis()).apply();
            lastState = "";
            handler.postDelayed(processRunnable, 1000L);
            return;
        }
        userStatus("Final ZIP'in Download klasörüne düşmesi bekleniyor");
        handler.postDelayed(processRunnable, 5000L);
    }

    private void completeCurrentProduct() {
        SharedPreferences p = Prefs.get(this);
        int seq = p.getInt(Prefs.PRODUCT_SEQ, 1);
        String niche = p.getString(Prefs.NICHE, "");
        String subNiche = p.getString(Prefs.SUBNICHE, "");
        String completedLabel = ProductNaming.completedLabel(niche, subNiche);
        String completedFile = ProductNaming.finalZipName(seq, niche, subNiche);
        p.edit()
                .putInt(Prefs.PRODUCT_SEQ, seq + 1)
                .putInt(Prefs.LAST_COMPLETED_SEQ, seq)
                .putString(Prefs.LAST_COMPLETED_LABEL, completedLabel)
                .putString(Prefs.LAST_COMPLETED_FILE, completedFile)
                .putLong(Prefs.LAST_COMPLETED_AT, System.currentTimeMillis())
                .putString(Prefs.STATE, AutomationState.OPEN_NICHE_CHAT)
                .putString(Prefs.STATUS_DETAIL, "Final ZIP doğrulandı; sıradaki ürün için yeni niş aranıyor")
                .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis())
                .putBoolean(Prefs.RESUME_AVAILABLE, false)
                .remove(Prefs.RESUME_REASON)
                .remove(Prefs.RESUME_TARGET_STATE)
                .remove(Prefs.NICHE).remove(Prefs.SUBNICHE)
                .remove(Prefs.PRODUCT_STARTED)
                .remove(Prefs.PRODUCT_COMMAND_SENT)
                .remove(Prefs.DOWNLOAD_REQUESTED_AT)
                .remove(Prefs.EXPECTED_DOWNLOAD_NAME)
                .remove(Prefs.DOWNLOAD_SNAPSHOT)
                .remove(Prefs.DOWNLOAD_UI_BASELINE)
                .remove(Prefs.PRODUCT_ACTIVE_SEEN)
                .remove(Prefs.CHATGPT_MISSING_SINCE)
                .remove(Prefs.STALL_ALERTED)
                .putBoolean(Prefs.SCREEN_LOCKED, false)
                .putBoolean(Prefs.LOCK_BLOCKED, false)
                .putBoolean(Prefs.LOCK_BLOCKED_ALERTED, false)
                .remove(Prefs.LAST_UNLOCK_ATTEMPT)
                .remove(Prefs.LIMIT_RESUME_STATE)
                .remove(Prefs.LIMIT_UNTIL)
                .putBoolean(Prefs.AFTER_LIMIT, false)
                .putInt(Prefs.ATTEMPTS, 0)
                .apply();
        lastState = "";
        NotificationUtil.status(this, ProductNaming.displayName(seq, niche, subNiche) + " · final ZIP doğrulandı");
        handler.postDelayed(processRunnable, 700L);
    }

    private void resumeRoute(AccessibilityNodeInfo root, String dump) {
        SharedPreferences p = Prefs.get(this);
        String target = p.getString(Prefs.RESUME_TARGET_STATE, p.getString(Prefs.STATE, AutomationState.IDLE));
        boolean productSent = p.getBoolean(Prefs.PRODUCT_COMMAND_SENT, false);

        if (productSent) {
            int seq = p.getInt(Prefs.PRODUCT_SEQ, 1);
            String niche = p.getString(Prefs.NICHE, "");
            String sub = p.getString(Prefs.SUBNICHE, "product");
            long started = p.getLong(Prefs.PRODUCT_STARTED, 0L);
            String snapshot = p.getString(Prefs.DOWNLOAD_SNAPSHOT, "");
            if (StorageUtil.hasVerifiedProductZip(this, seq, niche, sub, started)) {
                completeCurrentProduct();
                return;
            }
            if (StorageUtil.hasNewZipInDownload(this, snapshot, started)) {
                transition(AutomationState.ARCHIVE, "İnmiş final ZIP bulundu; ürün doğrulanıyor");
                return;
            }
            userStatus("Mevcut ürünün fabrika sohbeti açılıyor");
            openChat(root, FACTORY_CHAT, AutomationState.WAIT_PRODUCT);
            return;
        }

        // Üretim komutu henüz gönderilmediyse exact eski state'e dönmek güvenlidir.
        if (AutomationState.WAIT_NICHE_REPLY.equals(target) || AutomationState.SEND_NICHE.equals(target)
                || AutomationState.OPEN_NICHE_CHAT.equals(target)) {
            openChat(root, NICHE_CHAT, target);
            return;
        }
        if (AutomationState.OPEN_FACTORY_CHAT.equals(target) || AutomationState.SEND_FACTORY.equals(target)) {
            openChat(root, FACTORY_CHAT, target);
            return;
        }
        transition(target, "Kaldığı aşamadan devam ediliyor");
    }

    private void transition(String state, String note) {
        Prefs.get(this).edit().putString(Prefs.STATE, state)
                .putLong(Prefs.LAST_ACTION, System.currentTimeMillis())
                .putString(Prefs.STATUS_DETAIL, note)
                .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis()).apply();
        lastState = "";
        NotificationUtil.status(this, note);
        handler.postDelayed(processRunnable, 500);
    }

    private void fail(String title, String detail) {
        Prefs.get(this).edit().putString(Prefs.STATE, AutomationState.ERROR).putBoolean(Prefs.PAUSED, true)
                .putString(Prefs.LAST_ERROR, detail)
                .putString(Prefs.STATUS_DETAIL, title)
                .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis()).apply();
        lastState = AutomationState.ERROR;
        handler.removeCallbacks(heartbeatRunnable);
        NotificationUtil.status(this, "Durdu · müdahale gerekiyor");
        NotificationUtil.alert(this, title, detail);
    }

    private long elapsed() {
        if (stateEntered == 0) stateEntered = System.currentTimeMillis();
        return System.currentTimeMillis() - stateEntered;
    }

    private String popupWaitingStatusText(SharedPreferences p) {
        if (!p.getBoolean(Prefs.ENABLED, false)) return "Kapalı";
        if (p.getBoolean(Prefs.PAUSED, false)) return "Duraklatıldı";
        int seq = p.getInt(Prefs.PRODUCT_SEQ, 1);
        return ProductNaming.displayName(seq, p.getString(Prefs.NICHE, ""), p.getString(Prefs.SUBNICHE, ""))
                + " · ChatGPT popup bekleniyor";
    }

    private String statusText(SharedPreferences p) {
        if (!p.getBoolean(Prefs.ENABLED, false)) return "Kapalı";
        if (p.getBoolean(Prefs.PAUSED, false)) return "Duraklatıldı";
        String s = p.getString(Prefs.STATE, AutomationState.IDLE);
        int seq = p.getInt(Prefs.PRODUCT_SEQ, 1);
        return ProductNaming.displayName(seq, p.getString(Prefs.NICHE, ""), p.getString(Prefs.SUBNICHE, ""))
                + " · " + pretty(s);
    }

    private String pretty(String s) {
        switch (s) {
            case AutomationState.OPEN_NICHE_CHAT: return "Niş sohbeti";
            case AutomationState.SEND_NICHE: return "Niş komutu";
            case AutomationState.WAIT_NICHE_REPLY: return "Niş bekleniyor";
            case AutomationState.OPEN_FACTORY_CHAT: return "Fabrika sohbeti";
            case AutomationState.SEND_FACTORY: return "Üretim başlatılıyor";
            case AutomationState.WAIT_PRODUCT: return "Ürün üretiliyor";
            case AutomationState.ARCHIVE: return "Dosyalar doğrulanıyor";
            case AutomationState.RESUME_ROUTE: return "Devam hazırlanıyor";
            case AutomationState.ERROR: return "Hata";
            default: return s;
        }
    }
}
