package com.deniz.etsypngfactory;

import android.accessibilityservice.AccessibilityService;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.util.List;

public class FactoryAccessibilityService extends AccessibilityService {
    private static volatile FactoryAccessibilityService activeInstance;
    private static final String CHATGPT = "com.openai.chatgpt";
    private static final String NICHE_CHAT = "Etsy PNG Niş Araştırması";
    private static final String FACTORY_CHAT = "Fabrika Hazır Onayı";
    private static final long HEARTBEAT_MS = 6000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private long lastProcess = 0L;
    private long stateEntered = 0L;
    private String lastState = "";

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        activeInstance = this;
        SharedPreferences p = Prefs.get(this);
        if (p.getInt(Prefs.RUNTIME_VERSION, 0) < 6) {
            p.edit()
                    .putInt(Prefs.RUNTIME_VERSION, 6)
                    .putBoolean(Prefs.ENABLED, false)
                    .putBoolean(Prefs.PAUSED, false)
                    .putString(Prefs.STATE, AutomationState.IDLE)
                    .remove(Prefs.LAST_ERROR)
                    .remove(Prefs.NICHE)
                    .remove(Prefs.SUBNICHE)
                    .remove(Prefs.PRODUCT_STARTED)
                    .remove(Prefs.DOWNLOAD_SNAPSHOT)
                    .remove(Prefs.DOWNLOAD_UI_BASELINE)
                    .remove(Prefs.LIMIT_RESUME_STATE)
                    .remove(Prefs.LIMIT_UNTIL)
                    .putBoolean(Prefs.AFTER_LIMIT, false)
                    .putInt(Prefs.ATTEMPTS, 0)
                    .apply();
            NotificationUtil.clearStatus(this);
            return;
        }
        if (p.getBoolean(Prefs.ENABLED, false)) {
            NotificationUtil.status(this, statusText(p));
            scheduleHeartbeat(1000L);
        }
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        SharedPreferences p = Prefs.get(this);
        if (!p.getBoolean(Prefs.ENABLED, false) || p.getBoolean(Prefs.PAUSED, false)) return;

        // Düşük güç: esas olarak ChatGPT olaylarıyla uyan. Popup görünürken getWindows()
        // üzerinden ChatGPT penceresini, kurye uygulaması aktif pencere olsa bile bulabiliriz.
        CharSequence pkg = event.getPackageName();
        if (pkg != null && !CHATGPT.contentEquals(pkg)) return;

        long now = System.currentTimeMillis();
        if (now - lastProcess < 350) return;
        lastProcess = now;
        handler.removeCallbacks(processRunnable);
        handler.postDelayed(processRunnable, 250);
    }

    @Override public void onInterrupt() { }

    @Override public void onDestroy() {
        handler.removeCallbacks(processRunnable);
        handler.removeCallbacks(heartbeatRunnable);
        if (activeInstance == this) activeInstance = null;
        super.onDestroy();
    }

    static void kickIfVisible() {
        FactoryAccessibilityService s = activeInstance;
        if (s == null) return;
        s.handler.removeCallbacks(s.processRunnable);
        s.handler.postDelayed(s.processRunnable, 150);
        s.scheduleHeartbeat(1200L);
    }

    private final Runnable processRunnable = new Runnable() {
        @Override public void run() { process(); }
    };

    private final Runnable heartbeatRunnable = new Runnable() {
        @Override public void run() {
            SharedPreferences p = Prefs.get(FactoryAccessibilityService.this);
            if (!p.getBoolean(Prefs.ENABLED, false) || p.getBoolean(Prefs.PAUSED, false)) return;
            process();
        }
    };

    private void scheduleHeartbeat(long delay) {
        handler.removeCallbacks(heartbeatRunnable);
        handler.postDelayed(heartbeatRunnable, delay);
    }

    /**
     * Popup Engine'in temel farkı: aktif pencereyi değil, tüm interaktif accessibility
     * pencerelerini tarar. Böylece kurye uygulaması odakta kalırken ekranda açık olan
     * ChatGPT Samsung popup penceresinin kök ağacına erişebiliriz.
     */
    private AccessibilityNodeInfo findChatGptRoot() {
        List<AccessibilityWindowInfo> windows = getWindows();
        if (windows != null) {
            AccessibilityNodeInfo fallback = null;
            int bestLayer = Integer.MIN_VALUE;
            for (AccessibilityWindowInfo w : windows) {
                if (w == null) continue;
                AccessibilityNodeInfo root = null;
                try { root = w.getRoot(); } catch (Throwable ignored) { }
                if (root == null) continue;
                CharSequence pkg = root.getPackageName();
                if (pkg == null || !CHATGPT.contentEquals(pkg)) continue;

                // Üst katmandaki görünür ChatGPT penceresini tercih et. Samsung popup genelde
                // ana uygulama penceresinin üzerinde ayrı bir application window olarak görünür.
                if (w.getLayer() >= bestLayer) {
                    fallback = root;
                    bestLayer = w.getLayer();
                }
            }
            if (fallback != null) return fallback;
        }

        // Tam ekran testinde / bazı One UI sürümlerinde yedek yol.
        AccessibilityNodeInfo active = getRootInActiveWindow();
        if (active != null && active.getPackageName() != null && CHATGPT.contentEquals(active.getPackageName())) return active;
        return null;
    }

    private void process() {
        SharedPreferences p = Prefs.get(this);
        if (!p.getBoolean(Prefs.ENABLED, false) || p.getBoolean(Prefs.PAUSED, false)) return;
        String state = p.getString(Prefs.STATE, AutomationState.OPEN_NICHE_CHAT);
        if (!state.equals(lastState)) {
            lastState = state;
            stateEntered = System.currentTimeMillis();
        }

        // Arşivleme ChatGPT penceresine bağlı değildir.
        if (AutomationState.ARCHIVE.equals(state)) {
            try { archiveAndNext(); }
            catch (Throwable t) { fail("Arşivleme hatası", t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage())); }
            scheduleHeartbeat(HEARTBEAT_MS);
            return;
        }

        AccessibilityNodeInfo root = findChatGptRoot();
        if (root == null) {
            NotificationUtil.status(this, popupWaitingStatusText(p));
            scheduleHeartbeat(HEARTBEAT_MS);
            return;
        }

        String dump = NodeUtil.dumpText(root);
        p.edit().putString(Prefs.LAST_TREE, dump.length() > 30000 ? dump.substring(0, 30000) : dump).apply();
        NotificationUtil.status(this, statusText(p));

        if (LimitUtil.looksLimited(dump) && !AutomationState.ERROR.equals(state)) {
            long until = LimitUtil.estimateUntil(dump);
            p.edit().putString(Prefs.LIMIT_RESUME_STATE, state).putLong(Prefs.LIMIT_UNTIL, until).putBoolean(Prefs.PAUSED, true).apply();
            LimitUtil.schedule(this, until);
            NotificationUtil.status(this, "ChatGPT limiti · sessizce bekleniyor");
            return;
        }

        if (p.getBoolean(Prefs.AFTER_LIMIT, false)) {
            AccessibilityNodeInfo retry = NodeUtil.findByTextOrDescription(root, "tekrar dene", "yeniden dene", "retry", "try again", "devam et", "continue");
            if (retry != null) NodeUtil.click(retry);
            p.edit().putBoolean(Prefs.AFTER_LIMIT, false).apply();
        }

        try {
            switch (state) {
                case AutomationState.OPEN_NICHE_CHAT:
                    openChat(root, NICHE_CHAT, AutomationState.SEND_NICHE);
                    break;
                case AutomationState.SEND_NICHE:
                    sendText(root, "niş bul", AutomationState.WAIT_NICHE_REPLY, true);
                    break;
                case AutomationState.WAIT_NICHE_REPLY:
                    waitNiche(root, dump);
                    break;
                case AutomationState.OPEN_FACTORY_CHAT:
                    openChat(root, FACTORY_CHAT, AutomationState.SEND_FACTORY);
                    break;
                case AutomationState.SEND_FACTORY:
                    String niche = p.getString(Prefs.NICHE, "");
                    String sub = p.getString(Prefs.SUBNICHE, "");
                    String cmd = "üretime başla | niş: " + niche + " | alt niş: " + sub;
                    sendText(root, cmd, AutomationState.WAIT_PRODUCT, false);
                    break;
                case AutomationState.WAIT_PRODUCT:
                    waitProduct(root, dump);
                    break;
                case AutomationState.ERROR:
                case AutomationState.IDLE:
                default:
                    break;
            }
        } catch (Throwable t) {
            fail("Otomasyon hatası", t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage()));
        }

        if (p.getBoolean(Prefs.ENABLED, false) && !p.getBoolean(Prefs.PAUSED, false)) scheduleHeartbeat(HEARTBEAT_MS);
    }

    private void openChat(AccessibilityNodeInfo root, String title, String nextState) {
        AccessibilityNodeInfo chat = NodeUtil.findTextLoose(root, title);
        if (chat != null && NodeUtil.click(chat)) {
            transition(nextState, "Sohbet açıldı: " + title);
            return;
        }
        if (elapsed() > 45_000) {
            fail("Sohbet bulunamadı", title + " sohbeti ChatGPT popup penceresinde bulunamadı. Popup çok küçükse biraz büyütüp tekrar dene.");
            return;
        }
        if (NodeUtil.openDrawerFallback(this, root)) {
            handler.removeCallbacks(processRunnable);
            handler.postDelayed(processRunnable, 1000);
        }
    }

    private void sendText(AccessibilityNodeInfo root, String text, String nextState, boolean nicheStep) {
        AccessibilityNodeInfo input = NodeUtil.findEditable(root);
        if (input == null) {
            if (elapsed() > 25_000) fail("Mesaj alanı bulunamadı", "ChatGPT popup penceresi mesaj alanını göstermiyor. Popup'ı biraz büyütüp tekrar dene.");
            return;
        }
        if (!NodeUtil.setTextPopupSafe(input, text)) return;
        SharedPreferences p = Prefs.get(this);
        String uiBaseline = nicheStep ? "" : NodeUtil.downloadBaseline(root);
        AccessibilityNodeInfo send = NodeUtil.findByTextOrDescription(root, "gönder", "gonder", "send message", "send");
        if (send != null && NodeUtil.click(send)) {
            SharedPreferences.Editor e = p.edit().putString(Prefs.STATE, nextState).putLong(Prefs.LAST_ACTION, System.currentTimeMillis());
            if (!nicheStep) {
                long now = System.currentTimeMillis();
                e.putLong(Prefs.PRODUCT_STARTED, now)
                        .putString(Prefs.DOWNLOAD_SNAPSHOT, StorageUtil.snapshot(this))
                        .putString(Prefs.DOWNLOAD_UI_BASELINE, uiBaseline);
            }
            e.apply();
            lastState = "";
            NotificationUtil.status(this, statusText(p));
        } else if (elapsed() > 25_000) {
            fail("Gönder düğmesi bulunamadı", "Mesaj yazıldı ancak ChatGPT popup penceresindeki gönder düğmesi algılanamadı.");
        }
    }

    private void waitNiche(AccessibilityNodeInfo root, String dump) {
        if (NodeUtil.looksGenerating(dump)) return;
        if (elapsed() < 6_000) return;
        String[] parsed = NicheParser.parse(dump);
        if (parsed != null) {
            Prefs.get(this).edit()
                    .putString(Prefs.NICHE, parsed[0])
                    .putString(Prefs.SUBNICHE, parsed[1])
                    .putString(Prefs.STATE, AutomationState.OPEN_FACTORY_CHAT)
                    .putInt(Prefs.ATTEMPTS, 0)
                    .apply();
            lastState = "";
            handler.postDelayed(processRunnable, 500);
            return;
        }
        if (elapsed() > 60_000) fail("Niş okunamadı", "Cevap tamamlandı ancak son 'Niş:' ve 'Alt niş:' alanları bulunamadı.");
    }

    private void waitProduct(AccessibilityNodeInfo root, String dump) {
        if (NodeUtil.looksGenerating(dump)) return;
        if (elapsed() < 12_000) return;
        List<AccessibilityNodeInfo> files = NodeUtil.newClickableDownloads(root, Prefs.get(this).getString(Prefs.DOWNLOAD_UI_BASELINE, ""));
        if (!files.isEmpty()) {
            int clicked = 0;
            for (AccessibilityNodeInfo n : files) {
                if (NodeUtil.click(n)) clicked++;
                if (clicked >= 6) break;
            }
            if (clicked > 0) {
                transition(AutomationState.ARCHIVE, "Yeni ürün dosyaları indiriliyor");
                handler.postDelayed(processRunnable, 12_000);
                return;
            }
        }
        if (elapsed() > 240_000) {
            fail("Ürün dosyası bulunamadı", "Yeni üretime ait indirilebilir dosya algılanamadı.");
        }
    }

    private void archiveAndNext() throws Exception {
        SharedPreferences p = Prefs.get(this);
        int seq = p.getInt(Prefs.PRODUCT_SEQ, 1);
        int count = StorageUtil.archiveNewFiles(this, seq, p.getString(Prefs.SUBNICHE, "product"),
                p.getString(Prefs.DOWNLOAD_SNAPSHOT, ""), p.getLong(Prefs.PRODUCT_STARTED, 0L));
        if (count <= 0) {
            if (elapsed() < 60_000) {
                handler.postDelayed(processRunnable, 8_000);
                return;
            }
            fail("İndirilen dosya bulunamadı", "ChatGPT indirme klasöründe bu yeni üretime ait dosya görünmedi.");
            return;
        }
        p.edit()
                .putInt(Prefs.PRODUCT_SEQ, seq + 1)
                .putString(Prefs.STATE, AutomationState.OPEN_NICHE_CHAT)
                .remove(Prefs.NICHE).remove(Prefs.SUBNICHE)
                .remove(Prefs.PRODUCT_STARTED)
                .remove(Prefs.DOWNLOAD_SNAPSHOT)
                .remove(Prefs.DOWNLOAD_UI_BASELINE)
                .putInt(Prefs.ATTEMPTS, 0)
                .apply();
        lastState = "";
        NotificationUtil.status(this, "P" + String.format("%04d", seq) + " kaydedildi · sıradaki ürün hazırlanıyor");
        handler.postDelayed(processRunnable, 700);
    }

    private void transition(String state, String note) {
        Prefs.get(this).edit().putString(Prefs.STATE, state).putLong(Prefs.LAST_ACTION, System.currentTimeMillis()).apply();
        lastState = "";
        NotificationUtil.status(this, note);
        handler.postDelayed(processRunnable, 500);
    }

    private void fail(String title, String detail) {
        Prefs.get(this).edit().putString(Prefs.STATE, AutomationState.ERROR).putBoolean(Prefs.PAUSED, true).putString(Prefs.LAST_ERROR, detail).apply();
        lastState = AutomationState.ERROR;
        handler.removeCallbacks(heartbeatRunnable);
        NotificationUtil.status(this, "Durdu · müdahale gerekiyor");
        NotificationUtil.alert(this, title, detail);
    }

    private long elapsed() {
        if (stateEntered == 0) stateEntered = System.currentTimeMillis();
        return System.currentTimeMillis() - stateEntered;
    }

    private String popupWaitingStatusText(SharedPreferences p) {
        if (!p.getBoolean(Prefs.ENABLED, false)) return "Kapalı";
        if (p.getBoolean(Prefs.PAUSED, false)) return "Duraklatıldı";
        int seq = p.getInt(Prefs.PRODUCT_SEQ, 1);
        return "P" + String.format("%04d", seq) + " · ChatGPT popup bekleniyor";
    }

    private String statusText(SharedPreferences p) {
        if (!p.getBoolean(Prefs.ENABLED, false)) return "Kapalı";
        if (p.getBoolean(Prefs.PAUSED, false)) return "Duraklatıldı";
        String s = p.getString(Prefs.STATE, AutomationState.IDLE);
        int seq = p.getInt(Prefs.PRODUCT_SEQ, 1);
        return "P" + String.format("%04d", seq) + " · Popup · " + pretty(s);
    }

    private String pretty(String s) {
        switch (s) {
            case AutomationState.OPEN_NICHE_CHAT: return "Niş sohbeti";
            case AutomationState.SEND_NICHE: return "Niş komutu";
            case AutomationState.WAIT_NICHE_REPLY: return "Niş bekleniyor";
            case AutomationState.OPEN_FACTORY_CHAT: return "Fabrika sohbeti";
            case AutomationState.SEND_FACTORY: return "Üretim başlatılıyor";
            case AutomationState.WAIT_PRODUCT: return "Ürün üretiliyor";
            case AutomationState.ARCHIVE: return "Dosyalar kaydediliyor";
            case AutomationState.ERROR: return "Hata";
            default: return s;
        }
    }
}
