package com.deniz.etsypngfactory;

import android.accessibilityservice.AccessibilityService;
import android.app.ActivityManager;
import android.content.Context;
import android.graphics.Path;
import android.graphics.Rect;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.util.List;

public class FactoryAccessibilityService extends AccessibilityService {
    private static volatile FactoryAccessibilityService activeInstance;
    private static final String CHATGPT = "com.openai.chatgpt";
    private static final String NICHE_CHAT = "Etsy PNG Niş Araştırması";
    private static final String FACTORY_CHAT = "Fabrika Hazır Onayı";
    private static final long HEARTBEAT_MS = 6000L;
    private static final long POPUP_SETUP_TIMEOUT_MS = 18000L;

    private int popupCloseAttempts = 0;
    private int popupSetupAttempts = 0;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private long lastProcess = 0L;
    private long stateEntered = 0L;
    private String lastState = "";

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        activeInstance = this;
        SharedPreferences p = Prefs.get(this);
        if (p.getInt(Prefs.RUNTIME_VERSION, 0) < 10) {
            // v0.10: yükseltme sırasında eski/yarım işi kurtarmaya çalışma.
            // Klasör izinleri ve ürün sıra numarası korunur; çalışma state'i temiz başlar.
            p.edit()
                    .putInt(Prefs.RUNTIME_VERSION, 10)
                    .putBoolean(Prefs.ENABLED, false)
                    .putBoolean(Prefs.PAUSED, false)
                    .putString(Prefs.STATE, AutomationState.IDLE)
                    .remove(Prefs.LAST_ERROR)
                    .remove(Prefs.NICHE)
                    .remove(Prefs.SUBNICHE)
                    .remove(Prefs.PRODUCT_STARTED)
                    .remove(Prefs.DOWNLOAD_SNAPSHOT)
                    .remove(Prefs.DOWNLOAD_UI_BASELINE)
                    .remove(Prefs.PRODUCT_ACTIVE_SEEN)
                    .remove(Prefs.LIMIT_RESUME_STATE)
                    .remove(Prefs.LIMIT_UNTIL)
                    .remove(Prefs.UPGRADE_RECOVERY)
                    .putInt(Prefs.POPUP_SETUP_STATE, 0)
                    .remove(Prefs.POPUP_SETUP_STARTED)
                    .putBoolean(Prefs.POPUP_CLOSE_REQUESTED, false)
                    .putBoolean(Prefs.AFTER_LIMIT, false)
                    .putInt(Prefs.ATTEMPTS, 0)
                    .apply();
            NotificationUtil.clearStatus(this);
            return;
        }
        if (p.getBoolean(Prefs.ENABLED, false)) {
            NotificationUtil.status(this, statusText(p));
            scheduleHeartbeat(1000L);
        }
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        SharedPreferences p = Prefs.get(this);
        boolean closeRequested = p.getBoolean(Prefs.POPUP_CLOSE_REQUESTED, false);
        if ((!p.getBoolean(Prefs.ENABLED, false) || p.getBoolean(Prefs.PAUSED, false)) && !closeRequested) return;

        // Düşük güç: esas olarak ChatGPT olaylarıyla uyan. Popup görünürken getWindows()
        // üzerinden ChatGPT penceresini, kurye uygulaması aktif pencere olsa bile bulabiliriz.
        CharSequence pkg = event.getPackageName();
        boolean popupOperation = p.getInt(Prefs.POPUP_SETUP_STATE, 0) > 0 || p.getBoolean(Prefs.POPUP_CLOSE_REQUESTED, false);
        if (!popupOperation && pkg != null && !CHATGPT.contentEquals(pkg)) return;

        long now = System.currentTimeMillis();
        if (now - lastProcess < 350) return;
        lastProcess = now;
        handler.removeCallbacks(processRunnable);
        handler.postDelayed(processRunnable, 250);
    }

    @Override public void onInterrupt() { }

    @Override public void onDestroy() {
        handler.removeCallbacks(processRunnable);
        handler.removeCallbacks(heartbeatRunnable);
        if (activeInstance == this) activeInstance = null;
        super.onDestroy();
    }

    static void kickIfVisible() {
        FactoryAccessibilityService s = activeInstance;
        if (s == null) return;
        s.handler.removeCallbacks(s.processRunnable);
        s.handler.postDelayed(s.processRunnable, 150);
        s.scheduleHeartbeat(1200L);
    }

    static boolean requestAutoPopupStart(Context context) {
        SharedPreferences p = Prefs.get(context);
        p.edit()
                .putInt(Prefs.POPUP_SETUP_STATE, 1)
                .putLong(Prefs.POPUP_SETUP_STARTED, System.currentTimeMillis())
                .putBoolean(Prefs.POPUP_CLOSE_REQUESTED, false)
                .putString(Prefs.STATUS_DETAIL, "ChatGPT açılır penceresi hazırlanıyor")
                .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis())
                .apply();
        boolean launched = AppLauncher.openChatGPTPopup(context);
        FactoryAccessibilityService s = activeInstance;
        if (s != null) {
            s.popupSetupAttempts = 0;
            s.handler.removeCallbacks(s.processRunnable);
            s.handler.postDelayed(s.processRunnable, 700);
            s.scheduleHeartbeat(1200L);
        }
        return launched;
    }

    static void stopAndClose(Context context) {
        SharedPreferences p = Prefs.get(context);
        p.edit()
                .putBoolean(Prefs.ENABLED, false)
                .putBoolean(Prefs.PAUSED, false)
                .putString(Prefs.STATE, AutomationState.IDLE)
                .putInt(Prefs.POPUP_SETUP_STATE, 0)
                .putBoolean(Prefs.POPUP_CLOSE_REQUESTED, true)
                .putString(Prefs.STATUS_DETAIL, "Fabrika kapatılıyor")
                .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis())
                .apply();
        FactoryAccessibilityService s = activeInstance;
        if (s != null) {
            s.popupCloseAttempts = 0;
            s.handler.removeCallbacks(s.processRunnable);
            s.handler.post(s.processRunnable);
        } else {
            NotificationUtil.clearStatus(context);
        }
    }

    private final Runnable processRunnable = new Runnable() {
        @Override public void run() { process(); }
    };

    private final Runnable heartbeatRunnable = new Runnable() {
        @Override public void run() {
            SharedPreferences p = Prefs.get(FactoryAccessibilityService.this);
            if (p.getBoolean(Prefs.POPUP_CLOSE_REQUESTED, false)) {
                process();
                return;
            }
            if (!p.getBoolean(Prefs.ENABLED, false)) return;
            if (p.getBoolean(Prefs.PAUSED, false)) {
                // Limit/manual pause sırasında üretim yapma; yalnız Agent task'ı gerçekten
                // kapatıldı mı diye seyrek kontrol et ki ChatGPT popup açık kalmasın.
                if (!ownTaskExists()) {
                    stopAndClose(FactoryAccessibilityService.this);
                    return;
                }
                scheduleHeartbeat(15000L);
                return;
            }
            process();
        }
    };

    private void scheduleHeartbeat(long delay) {
        handler.removeCallbacks(heartbeatRunnable);
        handler.postDelayed(heartbeatRunnable, delay);
    }

    private void userStatus(String detail) {
        if (detail == null) detail = "";
        SharedPreferences p = Prefs.get(this);
        if (detail.equals(p.getString(Prefs.STATUS_DETAIL, ""))) return;
        p.edit().putString(Prefs.STATUS_DETAIL, detail)
                .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis()).apply();
    }

    /**
     * Popup Engine'in temel farkı: aktif pencereyi değil, tüm interaktif accessibility
     * pencerelerini tarar. Böylece kurye uygulaması odakta kalırken ekranda açık olan
     * ChatGPT Samsung popup penceresinin kök ağacına erişebiliriz.
     */
    private AccessibilityNodeInfo findChatGptRoot() {
        List<AccessibilityWindowInfo> windows = getWindows();
        if (windows != null) {
            AccessibilityNodeInfo fallback = null;
            int bestLayer = Integer.MIN_VALUE;
            for (AccessibilityWindowInfo w : windows) {
                if (w == null) continue;
                AccessibilityNodeInfo root = null;
                try { root = w.getRoot(); } catch (Throwable ignored) { }
                if (root == null) continue;
                CharSequence pkg = root.getPackageName();
                if (pkg == null || !CHATGPT.contentEquals(pkg)) continue;

                // Üst katmandaki görünür ChatGPT penceresini tercih et. Samsung popup genelde
                // ana uygulama penceresinin üzerinde ayrı bir application window olarak görünür.
                if (w.getLayer() >= bestLayer) {
                    fallback = root;
                    bestLayer = w.getLayer();
                }
            }
            if (fallback != null) return fallback;
        }

        // Tam ekran testinde / bazı One UI sürümlerinde yedek yol.
        AccessibilityNodeInfo active = getRootInActiveWindow();
        if (active != null && active.getPackageName() != null && CHATGPT.contentEquals(active.getPackageName())) return active;
        return null;
    }


    private boolean ownTaskExists() {
        try {
            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            List<ActivityManager.AppTask> tasks = am == null ? null : am.getAppTasks();
            return tasks != null && !tasks.isEmpty();
        } catch (Throwable ignored) {
            return true;
        }
    }

    private AccessibilityWindowInfo findChatGptWindow() {
        List<AccessibilityWindowInfo> windows = getWindows();
        if (windows == null) return null;
        AccessibilityWindowInfo best = null;
        int layer = Integer.MIN_VALUE;
        for (AccessibilityWindowInfo w : windows) {
            if (w == null) continue;
            AccessibilityNodeInfo root = null;
            try { root = w.getRoot(); } catch (Throwable ignored) { }
            if (root == null || root.getPackageName() == null || !CHATGPT.contentEquals(root.getPackageName())) continue;
            if (w.getLayer() >= layer) { best = w; layer = w.getLayer(); }
        }
        return best;
    }

    private boolean isPopup(AccessibilityWindowInfo w) {
        if (w == null) return false;
        Rect b = new Rect();
        try { w.getBoundsInScreen(b); } catch (Throwable ignored) { return false; }
        int sw = Math.max(1, getResources().getDisplayMetrics().widthPixels);
        int sh = Math.max(1, getResources().getDisplayMetrics().heightPixels);
        return b.width() < sw * 0.90f || b.height() < sh * 0.82f;
    }

    private AccessibilityNodeInfo findAcrossSystemUi(String... needles) {
        List<AccessibilityWindowInfo> windows = getWindows();
        if (windows == null) return null;
        for (int i = windows.size() - 1; i >= 0; i--) {
            AccessibilityWindowInfo w = windows.get(i);
            if (w == null) continue;
            AccessibilityNodeInfo root = null;
            try { root = w.getRoot(); } catch (Throwable ignored) { }
            if (root == null) continue;
            CharSequence pkg = root.getPackageName();
            if (pkg != null && CHATGPT.contentEquals(pkg)) continue;
            AccessibilityNodeInfo n = NodeUtil.findByTextOrDescription(root, needles);
            if (n != null) return n;
        }
        return null;
    }

    private void handlePopupSetup() {
        SharedPreferences p = Prefs.get(this);
        long started = p.getLong(Prefs.POPUP_SETUP_STARTED, System.currentTimeMillis());
        if (System.currentTimeMillis() - started > POPUP_SETUP_TIMEOUT_MS) {
            p.edit().putInt(Prefs.POPUP_SETUP_STATE, 0).apply();
            fail("Popup açılamadı", "ChatGPT Samsung Açılır görünümü otomatik oluşturulamadı. One UI arayüzü değişmiş olabilir.");
            return;
        }

        int phase = p.getInt(Prefs.POPUP_SETUP_STATE, 1);
        AccessibilityWindowInfo chatWindow = findChatGptWindow();
        if (chatWindow != null && isPopup(chatWindow)) {
            p.edit().putInt(Prefs.POPUP_SETUP_STATE, 0).remove(Prefs.POPUP_SETUP_STARTED).apply();
            NotificationUtil.status(this, "ChatGPT popup hazır · üretim başlıyor");
            handler.postDelayed(processRunnable, 450);
            return;
        }

        if (phase == 1) {
            if (chatWindow == null) {
                handler.postDelayed(processRunnable, 700);
                return;
            }
            performGlobalAction(GLOBAL_ACTION_RECENTS);
            p.edit().putInt(Prefs.POPUP_SETUP_STATE, 2).apply();
            handler.postDelayed(processRunnable, 850);
            return;
        }

        if (phase == 2) {
            AccessibilityNodeInfo chat = findAcrossSystemUi("ChatGPT");
            if (chat != null && NodeUtil.click(chat)) {
                p.edit().putInt(Prefs.POPUP_SETUP_STATE, 3).apply();
                handler.postDelayed(processRunnable, 650);
                return;
            }
            popupSetupAttempts++;
            if (popupSetupAttempts <= 2) {
                handler.postDelayed(processRunnable, 600);
                return;
            }
            // Samsung Recents'te uygulama ikonunun bulunduğu üst-orta bölgeye son çare dokunma.
            int sw = getResources().getDisplayMetrics().widthPixels;
            int sh = getResources().getDisplayMetrics().heightPixels;
            dispatchTap(sw * 0.50f, sh * 0.16f);
            p.edit().putInt(Prefs.POPUP_SETUP_STATE, 3).apply();
            handler.postDelayed(processRunnable, 650);
            return;
        }

        if (phase == 3) {
            AccessibilityNodeInfo popup = findAcrossSystemUi(
                    "Açılır görünümde aç", "Acilir gorunumde ac", "Açılır görünüm", "Acilir gorunum",
                    "Open in pop-up view", "Pop-up view");
            if (popup != null && NodeUtil.click(popup)) {
                p.edit().putInt(Prefs.POPUP_SETUP_STATE, 4).apply();
                handler.postDelayed(processRunnable, 900);
                return;
            }
            popupSetupAttempts++;
            if (popupSetupAttempts % 3 == 0) {
                p.edit().putInt(Prefs.POPUP_SETUP_STATE, 2).apply();
            }
            handler.postDelayed(processRunnable, 650);
            return;
        }

        handler.postDelayed(processRunnable, 700);
    }

    private void handlePopupClose() {
        SharedPreferences p = Prefs.get(this);
        AccessibilityWindowInfo w = findChatGptWindow();
        if (w == null) {
            finishPopupClose();
            return;
        }

        Rect wb = new Rect();
        try { w.getBoundsInScreen(wb); } catch (Throwable ignored) { }

        if (popupCloseAttempts < 3) {
            AccessibilityNodeInfo close = findAcrossSystemUi("Pencereyi kapat", "Kapat", "Close window", "Close");
            if (close != null && NodeUtil.click(close)) {
                popupCloseAttempts++;
                handler.postDelayed(processRunnable, 600);
                return;
            }
        }

        // Samsung popup araç çubuğu görünmüyorsa pencerenin üst tutamacına dokunup tekrar ara.
        if (popupCloseAttempts < 2 && !wb.isEmpty()) {
            popupCloseAttempts++;
            dispatchTap(wb.exactCenterX(), wb.top + Math.max(12, Math.min(38, wb.height() / 18)));
            handler.postDelayed(processRunnable, 550);
            return;
        }

        // Son çare: Recents üzerinden yalnız ChatGPT görevini yukarı süpür.
        if (popupCloseAttempts == 2) {
            popupCloseAttempts++;
            performGlobalAction(GLOBAL_ACTION_RECENTS);
            handler.postDelayed(processRunnable, 800);
            return;
        }

        if (popupCloseAttempts <= 5) {
            AccessibilityNodeInfo chat = findAcrossSystemUi("ChatGPT");
            if (chat != null) {
                Rect b = largestUsefulBounds(chat);
                if (!b.isEmpty()) {
                    popupCloseAttempts = 6;
                    dispatchSwipe(b.exactCenterX(), b.exactCenterY(), b.exactCenterX(), Math.max(5, b.top - b.height()));
                    handler.postDelayed(processRunnable, 900);
                    return;
                }
            }
            popupCloseAttempts++;
            handler.postDelayed(processRunnable, 500);
            return;
        }

        // Kapatma başarısızsa fabrikanın kendisi yine kapalı kalır; kullanıcıya yalnız bir uyarı ver.
        p.edit().putBoolean(Prefs.POPUP_CLOSE_REQUESTED, false).apply();
        NotificationUtil.clearStatus(this);
        NotificationUtil.alert(this, "ChatGPT popup kapanmadı", "Fabrika durdu ancak Samsung popup kapatma kontrolü bulunamadı.");
    }

    private void finishPopupClose() {
        Prefs.get(this).edit()
                .putBoolean(Prefs.POPUP_CLOSE_REQUESTED, false)
                .putInt(Prefs.POPUP_SETUP_STATE, 0)
                .remove(Prefs.POPUP_SETUP_STARTED)
                .apply();
        popupCloseAttempts = 0;
        NotificationUtil.clearStatus(this);
    }

    private Rect largestUsefulBounds(AccessibilityNodeInfo node) {
        Rect best = new Rect();
        AccessibilityNodeInfo p = node;
        int sw = getResources().getDisplayMetrics().widthPixels;
        int sh = getResources().getDisplayMetrics().heightPixels;
        for (int i = 0; p != null && i < 7; i++, p = p.getParent()) {
            Rect b = new Rect();
            p.getBoundsInScreen(b);
            if (b.isEmpty()) continue;
            long area = (long)b.width() * b.height();
            long bestArea = (long)best.width() * best.height();
            if (area > bestArea && b.width() < sw * 0.95f && b.height() < sh * 0.90f) best.set(b);
        }
        if (best.isEmpty()) node.getBoundsInScreen(best);
        return best;
    }

    private void dispatchTap(float x, float y) {
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, 80);
        dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
    }

    private void dispatchSwipe(float x1, float y1, float x2, float y2) {
        Path path = new Path();
        path.moveTo(x1, y1);
        path.lineTo(x2, y2);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, 320);
        dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
    }

    private void process() {
        SharedPreferences p = Prefs.get(this);

        if (p.getBoolean(Prefs.POPUP_CLOSE_REQUESTED, false)) {
            handlePopupClose();
            return;
        }
        if (!p.getBoolean(Prefs.ENABLED, false) || p.getBoolean(Prefs.PAUSED, false)) return;

        // Kullanıcı Agent görevini Son Uygulamalar'dan kaldırdıysa fabrika da kapanır.
        // Home/başka uygulamaya geçişte görev Recents'te kaldığı için bu tetiklenmez.
        if (!ownTaskExists()) {
            stopAndClose(this);
            return;
        }

        if (p.getInt(Prefs.POPUP_SETUP_STATE, 0) > 0) {
            handlePopupSetup();
            return;
        }

        String state = p.getString(Prefs.STATE, AutomationState.OPEN_NICHE_CHAT);

        // Limit alarmından aynı state'e döndüğümüzde eski stateEntered süresi taşınırsa
        // WAIT_PRODUCT 4 dakikalık timeout'u anında tetiklenebiliyor. Limit sonrası
        // state zamanlayıcısını sıfırla ve ChatGPT'nin kaldığı işi toparlaması için yeni
        // bir bekleme penceresi ver.
        if (p.getBoolean(Prefs.AFTER_LIMIT, false)) {
            lastState = "";
            stateEntered = System.currentTimeMillis();
        }
        if (!state.equals(lastState)) {
            lastState = state;
            stateEntered = System.currentTimeMillis();
        }

        // Arşivleme ChatGPT penceresine bağlı değildir.
        if (AutomationState.ARCHIVE.equals(state)) {
            try { archiveAndNext(); }
            catch (Throwable t) { fail("Arşivleme hatası", t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage())); }
            scheduleHeartbeat(HEARTBEAT_MS);
            return;
        }

        AccessibilityNodeInfo root = findChatGptRoot();
        if (root == null) {
            userStatus("ChatGPT açılır penceresi bekleniyor");
            NotificationUtil.status(this, popupWaitingStatusText(p));
            scheduleHeartbeat(HEARTBEAT_MS);
            return;
        }

        String dump = NodeUtil.dumpText(root);
        p.edit().putString(Prefs.LAST_TREE, dump.length() > 30000 ? dump.substring(0, 30000) : dump).apply();
        NotificationUtil.status(this, statusText(p));

        if (LimitUtil.looksLimited(dump) && !AutomationState.ERROR.equals(state)) {
            long until = LimitUtil.estimateUntil(dump);
            p.edit()
                    .putString(Prefs.LIMIT_RESUME_STATE, state)
                    .putLong(Prefs.LIMIT_UNTIL, until)
                    .putBoolean(Prefs.PAUSED, true)
                    .remove(Prefs.LAST_ERROR)
                    .putString(Prefs.STATUS_DETAIL, "ChatGPT kullanım hakkının yenilenmesi bekleniyor")
                    .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis())
                    .apply();
            LimitUtil.schedule(this, until);
            NotificationUtil.status(this, "ChatGPT kullanım hakkı · yenilenme saati bekleniyor");
            scheduleHeartbeat(15000L);
            return;
        }

        if (p.getBoolean(Prefs.AFTER_LIMIT, false)) {
            AccessibilityNodeInfo retry = NodeUtil.findByTextOrDescription(root, "tekrar dene", "yeniden dene", "retry", "try again", "devam et", "continue");
            if (retry != null) NodeUtil.click(retry);
            p.edit().putBoolean(Prefs.AFTER_LIMIT, false).apply();
        }

        try {
            switch (state) {
                case AutomationState.OPEN_NICHE_CHAT:
                    openChat(root, NICHE_CHAT, AutomationState.SEND_NICHE);
                    break;
                case AutomationState.SEND_NICHE:
                    sendText(root, "niş bul", AutomationState.WAIT_NICHE_REPLY, true);
                    break;
                case AutomationState.WAIT_NICHE_REPLY:
                    waitNiche(root, dump);
                    break;
                case AutomationState.OPEN_FACTORY_CHAT:
                    openChat(root, FACTORY_CHAT, AutomationState.SEND_FACTORY);
                    break;
                case AutomationState.SEND_FACTORY:
                    // Geçmiş mesajlardaki "Çalışıyor"/"Gönderilmeyi bekliyor" metinlerine bakma.
                    // Yalnız ekrandaki GERÇEK aktif Dur düğmesi yeni komut göndermeyi engeller.
                    if (NodeUtil.hasActiveStopControl(root)) {
                        userStatus("Fabrika sohbetindeki mevcut işin bitmesi bekleniyor");
                        NotificationUtil.status(this, "Fabrika şu an meşgul · yeni komut bekliyor");
                        break;
                    }
                    String niche = p.getString(Prefs.NICHE, "");
                    String sub = p.getString(Prefs.SUBNICHE, "");
                    String cmd = "üretime başla | niş: " + niche + " | alt niş: " + sub;
                    sendText(root, cmd, AutomationState.WAIT_PRODUCT, false);
                    break;
                case AutomationState.WAIT_PRODUCT:
                    waitProduct(root, dump);
                    break;
                case AutomationState.ERROR:
                case AutomationState.IDLE:
                default:
                    break;
            }
        } catch (Throwable t) {
            fail("Otomasyon hatası", t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage()));
        }

        if (p.getBoolean(Prefs.ENABLED, false) && !p.getBoolean(Prefs.PAUSED, false)) scheduleHeartbeat(HEARTBEAT_MS);
    }

    private void openChat(AccessibilityNodeInfo root, String title, String nextState) {
        AccessibilityNodeInfo chat = NodeUtil.findTextLoose(root, title);
        if (chat != null && NodeUtil.click(chat)) {
            transition(nextState, "Sohbet açıldı: " + title);
            return;
        }
        if (elapsed() > 45_000) {
            fail("Sohbet bulunamadı", title + " sohbeti ChatGPT popup penceresinde bulunamadı. Popup çok küçükse biraz büyütüp tekrar dene.");
            return;
        }
        if (NodeUtil.openDrawerFallback(this, root)) {
            handler.removeCallbacks(processRunnable);
            handler.postDelayed(processRunnable, 1000);
        }
    }

    private void sendText(AccessibilityNodeInfo root, String text, String nextState, boolean nicheStep) {
        AccessibilityNodeInfo input = NodeUtil.findEditable(root);
        if (input == null) {
            if (elapsed() > 25_000) fail("Mesaj alanı bulunamadı", "ChatGPT popup penceresi mesaj alanını göstermiyor. Popup'ı biraz büyütüp tekrar dene.");
            return;
        }
        if (!NodeUtil.setTextPopupSafe(input, text)) return;
        SharedPreferences p = Prefs.get(this);
        String uiBaseline = nicheStep ? "" : NodeUtil.downloadBaseline(root);
        AccessibilityNodeInfo send = NodeUtil.findByTextOrDescription(root, "gönder", "gonder", "send message", "send");
        if (send != null && NodeUtil.click(send)) {
            SharedPreferences.Editor e = p.edit().putString(Prefs.STATE, nextState)
                    .putLong(Prefs.LAST_ACTION, System.currentTimeMillis())
                    .putString(Prefs.STATUS_DETAIL, nicheStep ? "Niş sonucu bekleniyor" : "Üretim komutu gönderildi; ChatGPT çalışması bekleniyor")
                    .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis());
            if (!nicheStep) {
                long now = System.currentTimeMillis();
                e.putLong(Prefs.PRODUCT_STARTED, now)
                        .putString(Prefs.DOWNLOAD_SNAPSHOT, StorageUtil.snapshot(this))
                        .putString(Prefs.DOWNLOAD_UI_BASELINE, uiBaseline)
                        .putBoolean(Prefs.PRODUCT_ACTIVE_SEEN, false);
            }
            e.apply();
            lastState = "";
            NotificationUtil.status(this, statusText(p));
        } else if (elapsed() > 25_000) {
            fail("Gönder düğmesi bulunamadı", "Mesaj yazıldı ancak ChatGPT popup penceresindeki gönder düğmesi algılanamadı.");
        }
    }

    private void waitNiche(AccessibilityNodeInfo root, String dump) {
        if (NodeUtil.looksGenerating(dump)) {
            userStatus("ChatGPT yeni nişleri araştırıyor");
            return;
        }
        if (elapsed() < 6_000) return;
        String[] parsed = NicheParser.parse(dump);
        if (parsed != null) {
            Prefs.get(this).edit()
                    .putString(Prefs.NICHE, parsed[0])
                    .putString(Prefs.SUBNICHE, parsed[1])
                    .putString(Prefs.STATE, AutomationState.OPEN_FACTORY_CHAT)
                    .putString(Prefs.STATUS_DETAIL, "Niş bulundu; fabrika sohbetine geçiliyor")
                    .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis())
                    .putInt(Prefs.ATTEMPTS, 0)
                    .apply();
            lastState = "";
            handler.postDelayed(processRunnable, 500);
            return;
        }
        if (elapsed() > 60_000) fail("Niş okunamadı", "Cevap tamamlandı ancak son 'Niş:' ve 'Alt niş:' alanları bulunamadı.");
    }

    private void waitProduct(AccessibilityNodeInfo root, String dump) {
        SharedPreferences p = Prefs.get(this);

        // Status bütün sohbet geçmişinden değil, bu ürünün komutundan ve gerçek aktif
        // Stop/Dur kontrolünden okunur. Böylece eski "Gönderilmeyi bekliyor" satırı yeni
        // çalışan ürünü yanlışlıkla kuyruğa düşürmez.
        String niche = p.getString(Prefs.NICHE, "");
        String sub = p.getString(Prefs.SUBNICHE, "");
        boolean generating = NodeUtil.hasActiveStopControl(root);
        boolean queued = !generating && NodeUtil.latestFactoryQueued(dump, niche, sub);
        if (queued) {
            userStatus("Üretim komutu ChatGPT'de sırada bekliyor");
            NotificationUtil.status(this, statusText(p) + " · komut sırada");
            return;
        }

        boolean activeSeen = p.getBoolean(Prefs.PRODUCT_ACTIVE_SEEN, false);

        // Komutun gerçekten çalıştığını gördüğümüzde yalnız state işaretini değiştir.
        // Dosya/UI baseline'ı komut gönderilmeden hemen önce alınmıştır ve ürün boyunca sabit kalır.
        if (!activeSeen && generating) {
            p.edit().putBoolean(Prefs.PRODUCT_ACTIVE_SEEN, true)
                    .putString(Prefs.STATUS_DETAIL, "ChatGPT mevcut ürünü üretiyor")
                    .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis()).apply();
            NotificationUtil.status(this, statusText(p) + " · mevcut komut çalışıyor");
            return;
        }

        if (generating) {
            userStatus("ChatGPT mevcut ürünü üretiyor");
            return;
        }

        // Çok hızlı cevaplarda "Çalışıyor" durumunu kaçırabiliriz. Komut gönderildikten
        // sonra kısa bir emniyet aralığı verip mevcut komutu aktif kabul ediyoruz.
        if (!activeSeen) {
            long started = p.getLong(Prefs.PRODUCT_STARTED, 0L);
            long age = started <= 0 ? 0 : System.currentTimeMillis() - started;
            if (age < 20_000L) return;
            p.edit().putBoolean(Prefs.PRODUCT_ACTIVE_SEEN, true).apply();
            activeSeen = true;
        }

        userStatus("Üretim tamamlandı; yeni indirilebilir dosya aranıyor");
        if (elapsed() < 12_000) return;
        List<AccessibilityNodeInfo> files = NodeUtil.newClickableDownloads(root, p.getString(Prefs.DOWNLOAD_UI_BASELINE, ""));
        if (!files.isEmpty()) {
            int clicked = 0;
            for (AccessibilityNodeInfo n : files) {
                if (NodeUtil.click(n)) clicked++;
                if (clicked >= 6) break;
            }
            if (clicked > 0) {
                userStatus("Yeni ürün dosyaları indiriliyor");
                transition(AutomationState.ARCHIVE, "Yeni ürün dosyaları indiriliyor");
                handler.postDelayed(processRunnable, 12_000);
                return;
            }
        }

        // Work üretimleri 10-20+ dakika sürebiliyor. Dört dakikalık eski timeout
        // gerçek üretimleri hata sanıyordu. Yalnız uzun süre tamamen sessiz kalırsa dur.
        long started = p.getLong(Prefs.PRODUCT_STARTED, 0L);
        if (started > 0 && System.currentTimeMillis() - started > 45L * 60L * 1000L) {
            fail("Ürün dosyası bulunamadı", "Mevcut üretim 45 dakika boyunca tamamlanmadı ve yeni indirilebilir dosya oluşmadı.");
        }
    }

    private void archiveAndNext() throws Exception {
        SharedPreferences p = Prefs.get(this);
        int seq = p.getInt(Prefs.PRODUCT_SEQ, 1);
        int count = StorageUtil.archiveNewFiles(this, seq, p.getString(Prefs.SUBNICHE, "product"),
                p.getString(Prefs.DOWNLOAD_SNAPSHOT, ""), p.getLong(Prefs.PRODUCT_STARTED, 0L));
        if (count <= 0) {
            if (elapsed() < 300_000) {
                userStatus("İndirilen dosyanın Download klasörüne düşmesi bekleniyor");
                handler.postDelayed(processRunnable, 8_000);
                return;
            }
            fail("İndirilen dosya bulunamadı", "ChatGPT indirme klasöründe bu yeni üretime ait dosya görünmedi.");
            return;
        }
        String completedLabel = p.getString(Prefs.SUBNICHE, "product");
        p.edit()
                .putInt(Prefs.PRODUCT_SEQ, seq + 1)
                .putInt(Prefs.LAST_COMPLETED_SEQ, seq)
                .putString(Prefs.LAST_COMPLETED_LABEL, completedLabel)
                .putLong(Prefs.LAST_COMPLETED_AT, System.currentTimeMillis())
                .putString(Prefs.STATE, AutomationState.OPEN_NICHE_CHAT)
                .putString(Prefs.STATUS_DETAIL, "Ürün kaydedildi; sıradaki ürün için yeni niş aranıyor")
                .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis())
                .remove(Prefs.NICHE).remove(Prefs.SUBNICHE)
                .remove(Prefs.PRODUCT_STARTED)
                .remove(Prefs.DOWNLOAD_SNAPSHOT)
                .remove(Prefs.DOWNLOAD_UI_BASELINE)
                .remove(Prefs.PRODUCT_ACTIVE_SEEN)
                .remove(Prefs.LIMIT_RESUME_STATE)
                .remove(Prefs.LIMIT_UNTIL)
                .putBoolean(Prefs.AFTER_LIMIT, false)
                .putInt(Prefs.ATTEMPTS, 0)
                .apply();
        lastState = "";
        NotificationUtil.status(this, "P" + String.format("%04d", seq) + " kaydedildi · sıradaki ürün hazırlanıyor");
        handler.postDelayed(processRunnable, 700);
    }

    private void transition(String state, String note) {
        Prefs.get(this).edit().putString(Prefs.STATE, state)
                .putLong(Prefs.LAST_ACTION, System.currentTimeMillis())
                .putString(Prefs.STATUS_DETAIL, note)
                .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis()).apply();
        lastState = "";
        NotificationUtil.status(this, note);
        handler.postDelayed(processRunnable, 500);
    }

    private void fail(String title, String detail) {
        Prefs.get(this).edit().putString(Prefs.STATE, AutomationState.ERROR).putBoolean(Prefs.PAUSED, true)
                .putString(Prefs.LAST_ERROR, detail)
                .putString(Prefs.STATUS_DETAIL, title)
                .putLong(Prefs.STATUS_UPDATED, System.currentTimeMillis()).apply();
        lastState = AutomationState.ERROR;
        handler.removeCallbacks(heartbeatRunnable);
        NotificationUtil.status(this, "Durdu · müdahale gerekiyor");
        NotificationUtil.alert(this, title, detail);
    }

    private long elapsed() {
        if (stateEntered == 0) stateEntered = System.currentTimeMillis();
        return System.currentTimeMillis() - stateEntered;
    }

    private String popupWaitingStatusText(SharedPreferences p) {
        if (!p.getBoolean(Prefs.ENABLED, false)) return "Kapalı";
        if (p.getBoolean(Prefs.PAUSED, false)) return "Duraklatıldı";
        int seq = p.getInt(Prefs.PRODUCT_SEQ, 1);
        return "P" + String.format("%04d", seq) + " · ChatGPT popup bekleniyor";
    }

    private String statusText(SharedPreferences p) {
        if (!p.getBoolean(Prefs.ENABLED, false)) return "Kapalı";
        if (p.getBoolean(Prefs.PAUSED, false)) return "Duraklatıldı";
        String s = p.getString(Prefs.STATE, AutomationState.IDLE);
        int seq = p.getInt(Prefs.PRODUCT_SEQ, 1);
        return "P" + String.format("%04d", seq) + " · Popup · " + pretty(s);
    }

    private String pretty(String s) {
        switch (s) {
            case AutomationState.OPEN_NICHE_CHAT: return "Niş sohbeti";
            case AutomationState.SEND_NICHE: return "Niş komutu";
            case AutomationState.WAIT_NICHE_REPLY: return "Niş bekleniyor";
            case AutomationState.OPEN_FACTORY_CHAT: return "Fabrika sohbeti";
            case AutomationState.SEND_FACTORY: return "Üretim başlatılıyor";
            case AutomationState.WAIT_PRODUCT: return "Ürün üretiliyor";
            case AutomationState.ARCHIVE: return "Dosyalar kaydediliyor";
            case AutomationState.ERROR: return "Hata";
            default: return s;
        }
    }
}
