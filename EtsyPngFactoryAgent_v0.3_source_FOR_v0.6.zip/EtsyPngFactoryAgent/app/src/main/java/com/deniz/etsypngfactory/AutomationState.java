package com.deniz.etsypngfactory;

final class AutomationState {
    static final String IDLE = "IDLE";
    static final String OPEN_NICHE_CHAT = "OPEN_NICHE_CHAT";
    static final String SEND_NICHE = "SEND_NICHE";
    static final String WAIT_NICHE_REPLY = "WAIT_NICHE_REPLY";
    static final String OPEN_FACTORY_CHAT = "OPEN_FACTORY_CHAT";
    static final String SEND_FACTORY = "SEND_FACTORY";
    static final String WAIT_PRODUCT = "WAIT_PRODUCT";
    static final String ARCHIVE = "ARCHIVE";
    static final String RESUME_ROUTE = "RESUME_ROUTE";
    static final String ERROR = "ERROR";
}
