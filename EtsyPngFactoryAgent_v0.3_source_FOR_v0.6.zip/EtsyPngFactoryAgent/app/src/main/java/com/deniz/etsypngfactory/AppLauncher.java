package com.deniz.etsypngfactory;

import android.app.ActivityOptions;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.util.DisplayMetrics;

final class AppLauncher {
    private static final String CHATGPT = "com.openai.chatgpt";

    static boolean openChatGPTPopup(Context context) {
        try {
            Intent launch = context.getPackageManager().getLaunchIntentForPackage(CHATGPT);
            if (launch == null) {
                launch = new Intent(Intent.ACTION_MAIN);
                launch.addCategory(Intent.CATEGORY_LAUNCHER);
                launch.setPackage(CHATGPT);
            }
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);

            // Önce public Android launch-bounds yolunu dene. One UI bunu freeform/popup
            // olarak kabul ederse Recents otomasyonuna hiç gerek kalmaz.
            DisplayMetrics dm = context.getResources().getDisplayMetrics();
            int w = Math.max(1, dm.widthPixels);
            int h = Math.max(1, dm.heightPixels);
            Rect bounds = new Rect((int)(w * 0.50f), (int)(h * 0.10f), (int)(w * 0.98f), (int)(h * 0.72f));
            ActivityOptions options = ActivityOptions.makeBasic();
            options.setLaunchBounds(bounds);
            context.startActivity(launch, options.toBundle());
            return true;
        } catch (ActivityNotFoundException | SecurityException ex) {
            return false;
        } catch (Throwable t) {
            try {
                Intent fallback = context.getPackageManager().getLaunchIntentForPackage(CHATGPT);
                if (fallback == null) return false;
                fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                context.startActivity(fallback);
                return true;
            } catch (Throwable ignored) {
                return false;
            }
        }
    }

    static boolean openChatGPT(Context context) {
        try {
            Intent launch = context.getPackageManager().getLaunchIntentForPackage(CHATGPT);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                context.startActivity(launch);
                return true;
            }
            Intent fallback = new Intent(Intent.ACTION_MAIN);
            fallback.addCategory(Intent.CATEGORY_LAUNCHER);
            fallback.setPackage(CHATGPT);
            fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            context.startActivity(fallback);
            return true;
        } catch (ActivityNotFoundException | SecurityException ex) {
            return false;
        }
    }

    private AppLauncher() { }
}
