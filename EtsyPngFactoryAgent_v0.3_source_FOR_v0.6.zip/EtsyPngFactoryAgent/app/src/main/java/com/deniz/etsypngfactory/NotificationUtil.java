package com.deniz.etsypngfactory;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

final class NotificationUtil {
    static final String CHANNEL_STATUS = "factory_status";
    static final String CHANNEL_ALERT = "factory_alert";
    static final int STATUS_ID = 4101;
    static final int ALERT_ID = 4102;

    static void ensureChannels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel status = new NotificationChannel(CHANNEL_STATUS, "PNG Fabrikası", NotificationManager.IMPORTANCE_LOW);
        status.setDescription("Sessiz üretim durumu");
        status.setSound(null, null);
        status.enableVibration(false);
        nm.createNotificationChannel(status);
        NotificationChannel alert = new NotificationChannel(CHANNEL_ALERT, "PNG Fabrikası Sorunları", NotificationManager.IMPORTANCE_HIGH);
        alert.setDescription("Yalnız büyük sorunlar");
        nm.createNotificationChannel(alert);
    }

    static void status(Context c, String text) {
        ensureChannels(c);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        Intent open = new Intent(c, MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        PendingIntent pause = action(c, "PAUSE", 11);
        PendingIntent stop = action(c, "STOP", 12);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CHANNEL_STATUS) : new Notification.Builder(c);
        b.setSmallIcon(com.deniz.etsypngfactory.R.drawable.ic_factory)
                .setContentTitle("PNG Fabrikası")
                .setContentText(text)
                .setContentIntent(content)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .addAction(new Notification.Action.Builder(0, "Duraklat", pause).build())
                .addAction(new Notification.Action.Builder(0, "Durdur", stop).build());
        nm.notify(STATUS_ID, b.build());
    }

    static void alert(Context c, String title, String text) {
        ensureChannels(c);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        Intent open = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 2, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CHANNEL_ALERT) : new Notification.Builder(c);
        b.setSmallIcon(com.deniz.etsypngfactory.R.drawable.ic_factory)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(pi);
        nm.notify(ALERT_ID, b.build());
    }

    static void clearStatus(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.cancel(STATUS_ID);
    }

    private static PendingIntent action(Context c, String action, int request) {
        Intent i = new Intent(c, ControlReceiver.class).setAction(action);
        return PendingIntent.getBroadcast(c, request, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
