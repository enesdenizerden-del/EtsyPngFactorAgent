package com.deniz.etsypngfactory;

import android.app.Activity;
import android.app.KeyguardManager;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;

/**
 * Ekran kapanınca otomasyonun kısa bir kontrol oturumu açabilmesi için ekranı uyandırır.
 * Güvenli keyguard Android tarafından gerçekten kilitlenmişse kimlik doğrulamayı atlamaz.
 * Samsung Extend Unlock / güvenilir durum aktifse keyguard kullanıcı etkileşimi olmadan
 * dismiss edilebilir ve ChatGPT popup otomasyonu devam eder.
 */
public class LockWakeActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        dismissKeyguard();
    }

    private void dismissKeyguard() {
        KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        if (km == null || !km.isKeyguardLocked()) {
            FactoryAccessibilityService.onLockSessionReady(this);
            finish();
            return;
        }
        if (Build.VERSION.SDK_INT >= 26) {
            km.requestDismissKeyguard(this, new KeyguardManager.KeyguardDismissCallback() {
                @Override public void onDismissSucceeded() {
                    FactoryAccessibilityService.onLockSessionReady(LockWakeActivity.this);
                    finish();
                }
                @Override public void onDismissCancelled() {
                    FactoryAccessibilityService.onLockSessionBlocked(LockWakeActivity.this);
                    finish();
                }
                @Override public void onDismissError() {
                    FactoryAccessibilityService.onLockSessionBlocked(LockWakeActivity.this);
                    finish();
                }
            });
        } else {
            FactoryAccessibilityService.onLockSessionBlocked(this);
            finish();
        }
    }
}
