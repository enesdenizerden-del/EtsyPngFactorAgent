package com.deniz.etsypngfactory;

import java.util.Locale;

final class ProductNaming {
    private ProductNaming() { }

    static String id(int seq) {
        return String.format(Locale.ROOT, "P%04d", seq);
    }

    static String displayName(int seq, String niche, String subNiche) {
        String n = cleanDisplay(niche);
        String s = cleanDisplay(subNiche);
        if (n.isEmpty() && s.isEmpty()) return id(seq) + " · Niş belirleniyor";
        if (s.isEmpty()) return id(seq) + " · " + n;
        if (n.isEmpty()) return id(seq) + " · " + s;
        return id(seq) + " · " + n + " · " + s;
    }

    static String folderName(int seq, String niche, String subNiche) {
        return id(seq) + "__" + safeSegment(niche, 52) + "__" + safeSegment(subNiche, 58);
    }

    static String finalZipName(int seq, String niche, String subNiche) {
        return folderName(seq, niche, subNiche) + "__SELLER_BUNDLE.zip";
    }

    static String completedLabel(String niche, String subNiche) {
        String n = cleanDisplay(niche);
        String s = cleanDisplay(subNiche);
        if (n.isEmpty()) return s;
        if (s.isEmpty()) return n;
        return n + " · " + s;
    }

    private static String cleanDisplay(String value) {
        if (value == null) return "";
        return value.replaceAll("\\s+", " ").trim();
    }

    private static String safeSegment(String value, int max) {
        String x = cleanDisplay(value);
        if (x.isEmpty()) return "Belirlenmedi";

        // Android/Windows dosya adlarında sorun çıkarabilen karakterleri kaldır.
        x = x.replaceAll("[\\\\/:*?\"<>|]", " ");
        x = x.replaceAll("[\\p{Cntrl}]", " ");
        x = x.replaceAll("\\s+", "_");
        x = x.replaceAll("_+", "_");
        x = x.replaceAll("^[._ ]+|[._ ]+$", "");
        if (x.length() > max) x = x.substring(0, max).replaceAll("[._ ]+$", "");
        return x.isEmpty() ? "Belirlenmedi" : x;
    }
}
