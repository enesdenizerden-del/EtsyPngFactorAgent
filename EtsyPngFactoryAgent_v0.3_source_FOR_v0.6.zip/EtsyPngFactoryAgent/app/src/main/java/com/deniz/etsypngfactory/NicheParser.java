package com.deniz.etsypngfactory;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class NicheParser {
    static String[] parse(String text) {
        String niche = match(text, "(?im)^\\s*(?:seçilen\\s+|secilen\\s+|ana\\s+)?niş\\s*[:\\-–—]\\s*(.+?)\\s*$", "(?im)^\\s*(?:selected\\s+|main\\s+)?niche\\s*[:\\-–—]\\s*(.+?)\\s*$");
        String sub = match(text, "(?im)^\\s*(?:seçilen\\s+|secilen\\s+)?alt\\s*niş\\s*[:\\-–—]\\s*(.+?)\\s*$", "(?im)^\\s*(?:selected\\s+)?sub[- ]?niche\\s*[:\\-–—]\\s*(.+?)\\s*$");
        if (niche == null || sub == null) return null;
        niche = clean(niche);
        sub = clean(sub);
        if (niche.length() < 2 || sub.length() < 2) return null;
        return new String[]{niche, sub};
    }

    private static String match(String text, String... patterns) {
        if (text == null) return null;
        for (String p : patterns) {
            Matcher m = Pattern.compile(p).matcher(text);
            String last = null;
            while (m.find()) last = m.group(1);
            if (last != null) return last;
        }
        return null;
    }

    private static String clean(String s) {
        return s.replace("**", "").replace("`", "").replace("#", "").trim();
    }
}
