package com.deniz.etsypngfactory;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class NicheParser {
    static String[] parse(String text) {
        if (text == null || text.isBlank()) return null;

        // Niş radarı çoğu zaman son seçimi doğrudan üretim komutu biçiminde verir:
        // üretime başla | niş: X | alt niş: Y
        String[] command = parseCommandLine(text);
        if (command != null) return command;

        String niche = match(text,
                "(?im)^\\s*(?:[-*#>]+\\s*)?(?:seçilen\\s+|secilen\\s+|ana\\s+)?niş\\s*[:\\-–—]\\s*(.+?)\\s*$",
                "(?im)^\\s*(?:[-*#>]+\\s*)?(?:selected\\s+|main\\s+)?niche\\s*[:\\-–—]\\s*(.+?)\\s*$");
        String sub = match(text,
                "(?im)^\\s*(?:[-*#>]+\\s*)?(?:seçilen\\s+|secilen\\s+)?alt\\s*niş\\s*[:\\-–—]\\s*(.+?)\\s*$",
                "(?im)^\\s*(?:[-*#>]+\\s*)?(?:selected\\s+)?sub[- ]?niche\\s*[:\\-–—]\\s*(.+?)\\s*$");
        if (niche == null || sub == null) return null;
        niche = clean(niche);
        sub = clean(sub);
        if (!valid(niche, sub)) return null;
        return new String[]{niche, sub};
    }

    private static String[] parseCommandLine(String text) {
        Pattern p = Pattern.compile(
                "(?i)(?:üretime|uretime)\\s+(?:başla|basla)");
        Matcher m = p.matcher(text);
        int lastStart = -1;
        while (m.find()) lastStart = m.start();
        if (lastStart < 0) return null;

        String tail = text.substring(lastStart);
        Pattern line = Pattern.compile(
                "(?is)(?:üretime|uretime)\\s+(?:başla|basla)\\s*\\|\\s*(?:niş|nis)\\s*:\\s*([^|\\r\\n]+?)\\s*\\|\\s*(?:alt\\s*(?:niş|nis)|sub[- ]?niche)\\s*:\\s*([^\\r\\n]+)");
        Matcher lm = line.matcher(tail);
        String niche = null, sub = null;
        while (lm.find()) {
            niche = clean(lm.group(1));
            sub = clean(lm.group(2));
        }
        if (!valid(niche, sub)) return null;
        return new String[]{niche, sub};
    }

    private static boolean valid(String niche, String sub) {
        return niche != null && sub != null && niche.length() >= 2 && sub.length() >= 2;
    }

    private static String match(String text, String... patterns) {
        for (String p : patterns) {
            Matcher m = Pattern.compile(p).matcher(text);
            String last = null;
            while (m.find()) last = m.group(1);
            if (last != null) return last;
        }
        return null;
    }

    private static String clean(String s) {
        if (s == null) return null;
        String x = s.replace("**", "").replace("`", "").replace("#", "").trim();
        // Aynı satırda açıklama eklenmişse yalnız alan değerini tut.
        int pipe = x.indexOf('|');
        if (pipe >= 0) x = x.substring(0, pipe).trim();
        return x;
    }
}
