# PNG Factory Agent — Test 0.1

Samsung Galaxy A36 için ilk teknik prototip.

## Bu sürüm neyi test eder?
- ChatGPT Android uygulamasındaki erişilebilirlik ağacında sabit sohbet adlarını bulma.
- `Etsy PNG Niş Araştırması` sohbetine girip `niş bul` gönderme.
- Cevaptan `Niş:` ve `Alt niş:` alanlarını otomatik çıkarma.
- `Fabrika Hazır Onayı` sohbetine geçip `üretime başla | niş: ... | alt niş: ...` gönderme.
- Yanıt tamamlandığında erişilebilir görünen dosya bağlantılarına basmayı deneme.
- Kullanıcının seçtiği ChatGPT indirme klasöründeki yeni dosyaları, seçilen Fabrika klasöründe `P0001_<alt_nis>` gibi ayrı klasörlere kopyalama.
- Başarılı ürün sonrası yeniden niş araştırmasına geçerek döngüyü sürdürme.
- ChatGPT kullanım limiti algılanırsa saat/dakika bilgisini çıkarmayı deneyip AlarmManager ile düşük güçte bekleme; süre dolunca yalnız ChatGPT hâlâ öndeyse devam etme.
- Büyük bir sorun olduğunda otomasyonu duraklatıp bildirim gönderme.

## Kurye güvenli modu
Bu prototip **yalnız `com.openai.chatgpt` ön plandayken** UI işlemi yapar. Başka bir uygulama — kurye/navigasyon uygulaması dahil — öndeyken tıklama veya yazma yapmaz. Bu yüzden kullanıcı ChatGPT'den ayrılırsa üretim de bekler; kurye uygulamasını kendiliğinden ekrandan atmaz.

## İlk kurulum
1. Uygulamayı aç.
2. `Ürün klasörünü seç`: ör. `Download/EtsyPNGFactory`.
3. `ChatGPT indirme klasörünü seç`: ChatGPT'nin dosyaları indirdiği klasör, genellikle `Download`.
4. Erişilebilirlik ayarlarında `PNG Factory Agent` servisini aç.
5. `SÜREKLİ ÜRETİMİ BAŞLAT` düğmesine bas.
6. Uygulama ChatGPT'yi açar ve test akışına başlar.

## Önemli
ChatGPT'nin Android arayüzündeki erişilebilirlik metinleri/sınıfları sürüme göre değişebilir. İlk cihaz testinin amacı gerçek A36 + mevcut ChatGPT sürümünde hangi düğümlerin görüldüğünü doğrulamaktır. Hata olursa uygulamadaki `Tanı metnini kopyala` düğmesiyle erişilebilirlik ağacını alın; buna göre selector'lar güncellenebilir.

## Derleme
Android Studio / Gradle:

```bash
./gradlew assembleDebug
```

Çıktı:
`app/build/outputs/apk/debug/app-debug.apk`
