package com.deniz.etsypngfactory;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Bundle;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

final class NodeUtil {
    static AccessibilityNodeInfo findText(AccessibilityNodeInfo root, String needle) {
        if (root == null || needle == null) return null;
        List<AccessibilityNodeInfo> found = root.findAccessibilityNodeInfosByText(needle);
        if (found == null || found.isEmpty()) return null;
        for (AccessibilityNodeInfo n : found) {
            CharSequence t = n.getText();
            CharSequence d = n.getContentDescription();
            String s = ((t == null ? "" : t.toString()) + " " + (d == null ? "" : d.toString())).toLowerCase(Locale.ROOT);
            if (s.contains(needle.toLowerCase(Locale.ROOT))) return n;
        }
        return found.get(0);
    }

    static AccessibilityNodeInfo findByTextOrDescription(AccessibilityNodeInfo root, String... needles) {
        if (root == null) return null;
        ArrayList<AccessibilityNodeInfo> all = new ArrayList<>();
        collect(root, all, 0, 1800);
        for (AccessibilityNodeInfo n : all) {
            String s = textAndDesc(n).toLowerCase(Locale.ROOT);
            for (String needle : needles) {
                if (needle != null && s.contains(needle.toLowerCase(Locale.ROOT))) return n;
            }
        }
        return null;
    }

    static AccessibilityNodeInfo findEditable(AccessibilityNodeInfo root) {
        if (root == null) return null;
        ArrayList<AccessibilityNodeInfo> all = new ArrayList<>();
        collect(root, all, 0, 1800);
        AccessibilityNodeInfo fallback = null;
        for (AccessibilityNodeInfo n : all) {
            if (n.isEditable()) return n;
            CharSequence cls = n.getClassName();
            if (cls != null && cls.toString().toLowerCase(Locale.ROOT).contains("edittext")) fallback = n;
        }
        return fallback;
    }

    static boolean click(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo n = node;
        for (int i = 0; n != null && i < 7; i++) {
            if (n.isClickable() && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            n = n.getParent();
        }
        return node != null && node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    static boolean setText(AccessibilityNodeInfo node, String text) {
        if (node == null) return false;
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }

    static String dumpText(AccessibilityNodeInfo root) {
        if (root == null) return "";
        ArrayList<AccessibilityNodeInfo> all = new ArrayList<>();
        collect(root, all, 0, 2500);
        Set<String> lines = new LinkedHashSet<>();
        for (AccessibilityNodeInfo n : all) {
            CharSequence t = n.getText();
            if (t != null) {
                String x = t.toString().trim();
                if (!x.isEmpty()) lines.add(x);
            }
            CharSequence d = n.getContentDescription();
            if (d != null) {
                String x = d.toString().trim();
                if (!x.isEmpty() && !lines.contains(x)) lines.add(x);
            }
        }
        StringBuilder sb = new StringBuilder();
        for (String s : lines) sb.append(s).append('\n');
        return sb.toString();
    }

    static List<AccessibilityNodeInfo> clickableDownloads(AccessibilityNodeInfo root) {
        ArrayList<AccessibilityNodeInfo> all = new ArrayList<>();
        collect(root, all, 0, 2500);
        ArrayList<AccessibilityNodeInfo> out = new ArrayList<>();
        for (AccessibilityNodeInfo n : all) {
            String s = textAndDesc(n).toLowerCase(Locale.ROOT);
            boolean file = s.contains(".zip") || s.contains(".png") || s.contains(".mp4") || s.contains(".json") || s.contains("download") || s.contains("indir");
            if (file && (n.isClickable() || hasClickableParent(n))) out.add(n);
        }
        return out;
    }

    static boolean looksGenerating(String dump) {
        String s = dump.toLowerCase(Locale.ROOT);
        return s.contains("yanıtı durdur") || s.contains("yaniti durdur") || s.contains("stop generating") || s.contains("durdur");
    }

    static boolean openDrawerFallback(AccessibilityService service, AccessibilityNodeInfo root) {
        AccessibilityNodeInfo n = findByTextOrDescription(root,
                "kenar çubuğunu aç", "kenar cubugunu ac", "menüyü aç", "menuyu ac",
                "open sidebar", "open navigation", "navigation menu");
        if (n != null && click(n)) return true;
        // ChatGPT'nin üst-sol menü düğmesi için son çare. Yalnız ChatGPT ön plandayken çağrılır.
        Path p = new Path();
        p.moveTo(42, 115);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(p, 0, 80);
        GestureDescription g = new GestureDescription.Builder().addStroke(stroke).build();
        return service.dispatchGesture(g, null, null);
    }

    private static boolean hasClickableParent(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo p = node;
        for (int i = 0; p != null && i < 5; i++, p = p.getParent()) if (p.isClickable()) return true;
        return false;
    }

    private static String textAndDesc(AccessibilityNodeInfo n) {
        CharSequence t = n.getText();
        CharSequence d = n.getContentDescription();
        return (t == null ? "" : t.toString()) + " " + (d == null ? "" : d.toString());
    }

    private static void collect(AccessibilityNodeInfo n, List<AccessibilityNodeInfo> out, int depth, int max) {
        if (n == null || out.size() >= max || depth > 40) return;
        out.add(n);
        for (int i = 0; i < n.getChildCount() && out.size() < max; i++) collect(n.getChild(i), out, depth + 1, max);
    }
}
