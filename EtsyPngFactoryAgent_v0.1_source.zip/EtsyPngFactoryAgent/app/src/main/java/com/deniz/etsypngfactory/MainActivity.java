package com.deniz.etsypngfactory;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_FACTORY = 201;
    private static final int REQ_DOWNLOAD = 202;
    private TextView status;
    private Button start;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        NotificationUtil.ensureChannels(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 55);
        }
        buildUi();
    }

    @Override protected void onResume() {
        super.onResume();
        refresh();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = dp(18);
        box.setPadding(p, p, p, p);
        scroll.addView(box);

        TextView title = new TextView(this);
        title.setText("PNG Factory Agent · Test 0.1");
        title.setTextSize(23);
        title.setTextColor(Color.WHITE);
        title.setPadding(0, dp(10), 0, dp(14));
        box.addView(title);

        TextView note = new TextView(this);
        note.setText("Kurye güvenli modu: yalnız ChatGPT ön plandayken otomasyon yapar. Başka uygulamaya dokunmaz. Normal işlemler sessizdir; büyük hatada bildirim verir.");
        note.setTextSize(15);
        note.setTextColor(0xFFCCCCCC);
        note.setPadding(0, 0, 0, dp(16));
        box.addView(note);

        status = new TextView(this);
        status.setTextSize(16);
        status.setTextColor(Color.WHITE);
        status.setBackgroundColor(0xFF1F1F1F);
        status.setPadding(dp(14), dp(14), dp(14), dp(14));
        box.addView(status);

        box.addView(button("1 · Ürün klasörünü seç", v -> pickTree(REQ_FACTORY)));
        box.addView(button("2 · ChatGPT indirme klasörünü seç", v -> pickTree(REQ_DOWNLOAD)));
        box.addView(button("3 · Erişilebilirlik iznini aç", v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));

        start = button("SÜREKLİ ÜRETİMİ BAŞLAT", v -> startFactory());
        box.addView(start);
        box.addView(button("Duraklat / Devam et", v -> togglePause()));
        box.addView(button("Durdur", v -> stopFactory()));
        box.addView(button("Tanı metnini kopyala", v -> copyDebug()));
        setContentView(scroll);
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(16);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(54));
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        b.setOnClickListener(l);
        return b;
    }

    private void pickTree(int req) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(i, req);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try { getContentResolver().takePersistableUriPermission(uri, flags); } catch (Exception ignored) { }
        String key = requestCode == REQ_FACTORY ? Prefs.FACTORY_TREE : Prefs.DOWNLOAD_TREE;
        Prefs.get(this).edit().putString(key, uri.toString()).apply();
        refresh();
    }

    private void startFactory() {
        SharedPreferences p = Prefs.get(this);
        if (p.getString(Prefs.FACTORY_TREE, null) == null || p.getString(Prefs.DOWNLOAD_TREE, null) == null) {
            Toast.makeText(this, "Önce iki klasörü seç.", Toast.LENGTH_LONG).show(); return;
        }
        if (!isAccessibilityEnabled()) {
            Toast.makeText(this, "Önce PNG Factory Agent erişilebilirlik servisini aç.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return;
        }
        p.edit().putBoolean(Prefs.ENABLED, true).putBoolean(Prefs.PAUSED, false).putString(Prefs.STATE, AutomationState.OPEN_NICHE_CHAT).remove(Prefs.LAST_ERROR).apply();
        NotificationUtil.status(this, "Başlatıldı · ChatGPT açılıyor");
        Intent launch = getPackageManager().getLaunchIntentForPackage("com.openai.chatgpt");
        if (launch == null) {
            p.edit().putBoolean(Prefs.PAUSED, true).putString(Prefs.STATE, AutomationState.ERROR).apply();
            NotificationUtil.alert(this, "ChatGPT bulunamadı", "com.openai.chatgpt cihazda bulunamadı.");
            return;
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(launch);
    }

    private void togglePause() {
        SharedPreferences p = Prefs.get(this);
        if (!p.getBoolean(Prefs.ENABLED, false)) return;
        boolean paused = !p.getBoolean(Prefs.PAUSED, false);
        p.edit().putBoolean(Prefs.PAUSED, paused).apply();
        NotificationUtil.status(this, paused ? "Duraklatıldı" : "Devam ediyor · ChatGPT'yi açınca sürer");
        refresh();
    }

    private void stopFactory() {
        Prefs.get(this).edit().putBoolean(Prefs.ENABLED, false).putBoolean(Prefs.PAUSED, false).putString(Prefs.STATE, AutomationState.IDLE).apply();
        NotificationUtil.clearStatus(this);
        refresh();
    }

    private void copyDebug() {
        SharedPreferences p = Prefs.get(this);
        String s = "STATE=" + p.getString(Prefs.STATE, "") + "\nERROR=" + p.getString(Prefs.LAST_ERROR, "") + "\nNICHE=" + p.getString(Prefs.NICHE, "") + "\nSUBNICHE=" + p.getString(Prefs.SUBNICHE, "") + "\n\nTREE:\n" + p.getString(Prefs.LAST_TREE, "");
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("PNG Factory debug", s));
        Toast.makeText(this, "Tanı metni kopyalandı.", Toast.LENGTH_SHORT).show();
    }

    private void refresh() {
        if (status == null) return;
        SharedPreferences p = Prefs.get(this);
        boolean enabled = p.getBoolean(Prefs.ENABLED, false);
        boolean paused = p.getBoolean(Prefs.PAUSED, false);
        StringBuilder s = new StringBuilder();
        s.append("Erişilebilirlik: ").append(isAccessibilityEnabled() ? "✓" : "—").append('\n');
        s.append("Ürün klasörü: ").append(p.getString(Prefs.FACTORY_TREE, null) != null ? "✓" : "—").append('\n');
        s.append("İndirme klasörü: ").append(p.getString(Prefs.DOWNLOAD_TREE, null) != null ? "✓" : "—").append('\n');
        s.append("Fabrika: ").append(!enabled ? "Kapalı" : paused ? "Duraklatıldı" : "Çalışıyor").append('\n');
        s.append("Durum: ").append(p.getString(Prefs.STATE, AutomationState.IDLE)).append('\n');
        s.append("Sıradaki ürün: P").append(String.format("%04d", p.getInt(Prefs.PRODUCT_SEQ, 1)));
        String err = p.getString(Prefs.LAST_ERROR, "");
        if (!err.isEmpty()) s.append("\n\nSon hata: ").append(err);
        status.setText(s.toString());
    }

    private boolean isAccessibilityEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        String flat = new ComponentName(this, FactoryAccessibilityService.class).flattenToString();
        return enabled.toLowerCase().contains(flat.toLowerCase());
    }

    private int dp(int x) { return Math.round(x * getResources().getDisplayMetrics().density); }
}
