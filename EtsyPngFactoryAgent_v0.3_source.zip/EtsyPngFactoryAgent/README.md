# PNG Factory Agent — Test 0.3

Samsung Galaxy A36 için teknik prototip.

## Bu sürüm neyi test eder?
- ChatGPT Android uygulamasındaki erişilebilirlik ağacında sabit sohbet adlarını bulma.
- `Etsy PNG Niş Araştırması` sohbetine girip `niş bul` gönderme.
- Cevaptan `Niş:` ve `Alt niş:` alanlarını otomatik çıkarma.
- `Fabrika Hazır Onayı` sohbetine geçip `üretime başla | niş: ... | alt niş: ...` gönderme.
- Yanıt tamamlandığında erişilebilir görünen dosya bağlantılarına basmayı deneme.
- Kullanıcının seçtiği ChatGPT indirme klasöründeki yeni dosyaları, seçilen Fabrika klasöründe `P0001_<alt_nis>` gibi ayrı klasörlere kopyalama.
- Başarılı ürün sonrası yeniden niş araştırmasına geçerek döngüyü sürdürme.
- ChatGPT kullanım limiti algılanırsa saat/dakika bilgisini çıkarıp AlarmManager ile düşük güçte bekleme.
- Büyük bir sorun olduğunda otomasyonu duraklatıp bildirim gönderme.

## Arka plan davranışı
Fabrika başlatıldıktan sonra uygulamanın ana ekranının açık kalması gerekmez. Accessibility servisi üretim state'ini korur ve düşük güçte bekler.

Android, görünmeyen başka bir uygulamanın UI öğelerine güvenilir biçimde tıklatmaz. Bu yüzden ChatGPT görünür değilken state kaybolmaz veya hata oluşmaz; otomasyon arka planda hazır kalır. Kullanıcı boş olduğunda kalıcı bildirimdeki `ChatGPT` düğmesine dokunur. ChatGPT görünür olur olmaz otomasyon kaldığı state'ten devam eder.

Pil/CPU tüketimini düşük tutmak için accessibility event filtresi yalnız ChatGPT olaylarını dinler; diğer uygulamaların içeriği okunmaz.

## Test 0.3 değişiklikleri
- Önceki özel uygulama-koruma modu kaldırıldı.
- Uygulama başka bir uygulamaya geçildiğinde üretimi hata durumuna düşürmez; arka planda state'i korur.
- Dosya arşivleme UI'dan bağımsız olarak arka planda tamamlanabilir.
- Kalıcı bildirime `ChatGPT` kısayolu eklendi; boş olduğunda tek dokunuşla ChatGPT'ye geçilip otomasyona devam edilir.
- Limit bitişinde state arka planda hazır hale gelir; ChatGPT açıldığında devam eder.
- Android 11+ ChatGPT package visibility düzeltmesi korunur.

## İlk kurulum
1. Uygulamayı aç.
2. `Ürün klasörünü seç`: ör. `Download/EtsyPNGFactory`.
3. `ChatGPT indirme klasörünü seç`: ChatGPT'nin dosyaları indirdiği klasör, genellikle `Download`.
4. Erişilebilirlik ayarlarında `PNG Factory Agent` servisini aç.
5. `SÜREKLİ ÜRETİMİ BAŞLAT` düğmesine bas.
6. ChatGPT açılır ve test akışı başlar.
7. Başka uygulamaya geçersen fabrika state'i korunur; bildirimde `ChatGPT`'ye dokununca kaldığı yerden sürer.

## Önemli
ChatGPT'nin Android arayüzündeki erişilebilirlik metinleri/sınıfları sürüme göre değişebilir. İlk cihaz testinin amacı gerçek A36 + mevcut ChatGPT sürümünde hangi düğümlerin görüldüğünü doğrulamaktır. Hata olursa uygulamadaki `Tanı metnini kopyala` düğmesiyle erişilebilirlik ağacını alın; selector'lar buna göre güncellenebilir.

## Derleme
Android Studio / Gradle:

```bash
./gradlew assembleDebug
```

Çıktı:
`app/build/outputs/apk/debug/app-debug.apk`
