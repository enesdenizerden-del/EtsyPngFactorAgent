package com.deniz.etsypngfactory;

import android.content.Context;
import android.net.Uri;

import androidx.documentfile.provider.DocumentFile;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

final class StorageUtil {
    static String snapshot(Context c) {
        String uri = Prefs.get(c).getString(Prefs.DOWNLOAD_TREE, null);
        if (uri == null) return "";
        DocumentFile tree = DocumentFile.fromTreeUri(c, Uri.parse(uri));
        if (tree == null) return "";
        StringBuilder sb = new StringBuilder();
        for (DocumentFile f : tree.listFiles()) {
            if (f.isFile()) sb.append(key(f)).append('\n');
        }
        return sb.toString();
    }

    static int archiveNewFiles(Context c, int seq, String subNiche, String oldSnapshot, long startedAt) throws Exception {
        String srcUri = Prefs.get(c).getString(Prefs.DOWNLOAD_TREE, null);
        String dstUri = Prefs.get(c).getString(Prefs.FACTORY_TREE, null);
        if (srcUri == null || dstUri == null) return 0;
        DocumentFile src = DocumentFile.fromTreeUri(c, Uri.parse(srcUri));
        DocumentFile dst = DocumentFile.fromTreeUri(c, Uri.parse(dstUri));
        if (src == null || dst == null) return 0;

        Set<String> old = new HashSet<>();
        if (oldSnapshot != null) for (String s : oldSnapshot.split("\\n")) if (!s.isBlank()) old.add(s);

        String folderName = String.format(Locale.ROOT, "P%04d_%s", seq, safeName(subNiche));
        DocumentFile folder = findDir(dst, folderName);
        if (folder == null) folder = dst.createDirectory(folderName);
        if (folder == null) throw new IllegalStateException("Ürün klasörü oluşturulamadı");

        int copied = 0;
        for (DocumentFile f : src.listFiles()) {
            if (!f.isFile()) continue;
            String name = f.getName() == null ? "file" : f.getName();
            String low = name.toLowerCase(Locale.ROOT);
            if (!(low.endsWith(".zip") || low.endsWith(".png") || low.endsWith(".mp4") || low.endsWith(".json") || low.endsWith(".txt") || low.endsWith(".md"))) continue;
            if (old.contains(key(f))) continue;
            if (f.lastModified() > 0 && f.lastModified() + 30_000L < startedAt) continue;
            if (copy(c, f, folder, name)) copied++;
        }
        return copied;
    }

    private static boolean copy(Context c, DocumentFile src, DocumentFile folder, String name) throws Exception {
        DocumentFile existing = folder.findFile(name);
        String finalName = name;
        if (existing != null) finalName = System.currentTimeMillis() + "_" + name;
        DocumentFile outFile = folder.createFile(src.getType() == null ? "application/octet-stream" : src.getType(), finalName);
        if (outFile == null) return false;
        try (InputStream in = c.getContentResolver().openInputStream(src.getUri());
             OutputStream out = c.getContentResolver().openOutputStream(outFile.getUri(), "w")) {
            if (in == null || out == null) return false;
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
            out.flush();
            return true;
        }
    }

    private static DocumentFile findDir(DocumentFile parent, String name) {
        DocumentFile f = parent.findFile(name);
        return f != null && f.isDirectory() ? f : null;
    }

    private static String key(DocumentFile f) {
        return (f.getName() == null ? "" : f.getName()) + "|" + f.length() + "|" + f.lastModified();
    }

    private static String safeName(String s) {
        if (s == null || s.isBlank()) return "product";
        String x = s.replaceAll("[^A-Za-z0-9ğüşöçıİĞÜŞÖÇ _-]", "").trim().replaceAll("\\s+", "_");
        if (x.length() > 55) x = x.substring(0, 55);
        return x.isBlank() ? "product" : x;
    }
}
