package com.deniz.etsypngfactory;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;

import java.util.Calendar;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class LimitUtil {
    static boolean looksLimited(String dump) {
        if (dump == null) return false;
        String s = dump.toLowerCase(Locale.ROOT);
        return (s.contains("limit") || s.contains("sınır") || s.contains("sinir")) &&
                (s.contains("ulaşt") || s.contains("ulast") || s.contains("reached") || s.contains("yeniden") || s.contains("again") || s.contains("kullanım") || s.contains("kullanim"));
    }

    static long estimateUntil(String dump) {
        long now = System.currentTimeMillis();
        if (dump == null) return now + 60 * 60_000L;

        Matcher hm = Pattern.compile("(?<!\\d)([01]?\\d|2[0-3])[:.]([0-5]\\d)(?!\\d)").matcher(dump);
        if (hm.find()) {
            int h = Integer.parseInt(hm.group(1));
            int m = Integer.parseInt(hm.group(2));
            Calendar c = Calendar.getInstance();
            c.set(Calendar.HOUR_OF_DAY, h); c.set(Calendar.MINUTE, m); c.set(Calendar.SECOND, 15); c.set(Calendar.MILLISECOND, 0);
            if (c.getTimeInMillis() <= now + 2 * 60_000L) c.add(Calendar.DAY_OF_YEAR, 1);
            return c.getTimeInMillis();
        }

        Matcher min = Pattern.compile("(?i)(\\d{1,3})\\s*(dakika|minute|min)\\b").matcher(dump);
        if (min.find()) return now + Long.parseLong(min.group(1)) * 60_000L + 30_000L;
        Matcher hr = Pattern.compile("(?i)(\\d{1,2})\\s*(saat|hour|hours|hr)\\b").matcher(dump);
        if (hr.find()) return now + Long.parseLong(hr.group(1)) * 60 * 60_000L + 30_000L;
        return now + 60 * 60_000L;
    }

    static void schedule(Context c, long wallClockUntil) {
        long delay = Math.max(60_000L, wallClockUntil - System.currentTimeMillis());
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(c, ControlReceiver.class).setAction("LIMIT_WAKE");
        PendingIntent pi = PendingIntent.getBroadcast(c, 77, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + delay, pi);
    }
}
