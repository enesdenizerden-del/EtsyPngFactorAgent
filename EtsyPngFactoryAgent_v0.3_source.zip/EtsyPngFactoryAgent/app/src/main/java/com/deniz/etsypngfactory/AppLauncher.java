package com.deniz.etsypngfactory;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;

final class AppLauncher {
    private static final String CHATGPT = "com.openai.chatgpt";

    static boolean openChatGPT(Context context) {
        try {
            Intent launch = context.getPackageManager().getLaunchIntentForPackage(CHATGPT);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                context.startActivity(launch);
                return true;
            }

            // Android 11+ package visibility can hide launcher discovery. A known-package
            // launcher intent still gives Android a chance to resolve the installed app.
            Intent fallback = new Intent(Intent.ACTION_MAIN);
            fallback.addCategory(Intent.CATEGORY_LAUNCHER);
            fallback.setPackage(CHATGPT);
            fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            context.startActivity(fallback);
            return true;
        } catch (ActivityNotFoundException | SecurityException ex) {
            return false;
        }
    }

    private AppLauncher() { }
}
