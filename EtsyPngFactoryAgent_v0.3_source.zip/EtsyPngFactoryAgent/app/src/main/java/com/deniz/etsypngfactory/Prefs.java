package com.deniz.etsypngfactory;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    static final String NAME = "factory_prefs";
    static final String ENABLED = "enabled";
    static final String PAUSED = "paused";
    static final String STATE = "state";
    static final String FACTORY_TREE = "factory_tree";
    static final String DOWNLOAD_TREE = "download_tree";
    static final String NICHE = "niche";
    static final String SUBNICHE = "subniche";
    static final String PRODUCT_SEQ = "product_seq";
    static final String PRODUCT_STARTED = "product_started";
    static final String DOWNLOAD_SNAPSHOT = "download_snapshot";
    static final String LAST_TREE = "last_tree";
    static final String LAST_ERROR = "last_error";
    static final String LAST_ACTION = "last_action";
    static final String ATTEMPTS = "attempts";
    static final String LIMIT_RESUME_STATE = "limit_resume_state";
    static final String LIMIT_UNTIL = "limit_until";
    static final String AFTER_LIMIT = "after_limit";

    static SharedPreferences get(Context c) {
        return c.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }
}
