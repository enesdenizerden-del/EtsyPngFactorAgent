package com.deniz.etsypngfactory;

import android.accessibilityservice.AccessibilityService;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;

public class FactoryAccessibilityService extends AccessibilityService {
    private static volatile FactoryAccessibilityService activeInstance;
    private static final String CHATGPT = "com.openai.chatgpt";
    private static final String NICHE_CHAT = "Etsy PNG Niş Araştırması";
    private static final String FACTORY_CHAT = "Fabrika Hazır Onayı";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long lastProcess = 0L;
    private long stateEntered = 0L;
    private String lastState = "";

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        activeInstance = this;
        SharedPreferences p = Prefs.get(this);
        if (p.getBoolean(Prefs.ENABLED, false)) NotificationUtil.status(this, statusText(p));
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        SharedPreferences p = Prefs.get(this);
        if (!p.getBoolean(Prefs.ENABLED, false) || p.getBoolean(Prefs.PAUSED, false)) return;
        CharSequence pkg = event.getPackageName();
        if (pkg == null || !CHATGPT.contentEquals(pkg)) return; // Yalnız ChatGPT olaylarını işleyerek pil/CPU kullanımını düşük tut.
        long now = System.currentTimeMillis();
        if (now - lastProcess < 450) return;
        lastProcess = now;
        handler.removeCallbacks(processRunnable);
        handler.postDelayed(processRunnable, 350);
    }

    @Override public void onInterrupt() { }

    @Override public void onDestroy() {
        if (activeInstance == this) activeInstance = null;
        super.onDestroy();
    }

    static void kickIfVisible() {
        FactoryAccessibilityService s = activeInstance;
        if (s == null) return;
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null || root.getPackageName() == null || !CHATGPT.contentEquals(root.getPackageName())) return;
        s.handler.removeCallbacks(s.processRunnable);
        s.handler.postDelayed(s.processRunnable, 250);
    }

    private final Runnable processRunnable = new Runnable() {
        @Override public void run() { process(); }
    };

    private void process() {
        SharedPreferences p = Prefs.get(this);
        if (!p.getBoolean(Prefs.ENABLED, false) || p.getBoolean(Prefs.PAUSED, false)) return;
        String state = p.getString(Prefs.STATE, AutomationState.OPEN_NICHE_CHAT);
        if (!state.equals(lastState)) {
            lastState = state;
            stateEntered = System.currentTimeMillis();
        }

        // Arşivleme bir UI işlemi değildir; ekran başka uygulamadayken de tamamlanabilir.
        if (AutomationState.ARCHIVE.equals(state)) {
            try { archiveAndNext(); }
            catch (Throwable t) { fail("Arşivleme hatası", t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage())); }
            return;
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || root.getPackageName() == null || !CHATGPT.contentEquals(root.getPackageName())) {
            // Servis ve üretim durumu arka planda açık kalır. ChatGPT tekrar görünür olduğunda
            // accessibility olayı gelir ve state machine kaldığı yerden devam eder.
            NotificationUtil.status(this, backgroundStatusText(p));
            return;
        }

        String dump = NodeUtil.dumpText(root);
        p.edit().putString(Prefs.LAST_TREE, dump.length() > 30000 ? dump.substring(0, 30000) : dump).apply();
        NotificationUtil.status(this, statusText(p));

        if (LimitUtil.looksLimited(dump) && !AutomationState.ERROR.equals(state)) {
            long until = LimitUtil.estimateUntil(dump);
            p.edit().putString(Prefs.LIMIT_RESUME_STATE, state).putLong(Prefs.LIMIT_UNTIL, until).putBoolean(Prefs.PAUSED, true).apply();
            LimitUtil.schedule(this, until);
            NotificationUtil.status(this, "ChatGPT limiti · sessizce bekleniyor");
            return;
        }

        if (p.getBoolean(Prefs.AFTER_LIMIT, false)) {
            AccessibilityNodeInfo retry = NodeUtil.findByTextOrDescription(root, "tekrar dene", "yeniden dene", "retry", "try again", "devam et", "continue");
            if (retry != null) NodeUtil.click(retry);
            p.edit().putBoolean(Prefs.AFTER_LIMIT, false).apply();
        }

        try {
            switch (state) {
                case AutomationState.OPEN_NICHE_CHAT:
                    openChat(root, NICHE_CHAT, AutomationState.SEND_NICHE);
                    break;
                case AutomationState.SEND_NICHE:
                    sendText(root, "niş bul", AutomationState.WAIT_NICHE_REPLY, true);
                    break;
                case AutomationState.WAIT_NICHE_REPLY:
                    waitNiche(root, dump);
                    break;
                case AutomationState.OPEN_FACTORY_CHAT:
                    openChat(root, FACTORY_CHAT, AutomationState.SEND_FACTORY);
                    break;
                case AutomationState.SEND_FACTORY:
                    String niche = p.getString(Prefs.NICHE, "");
                    String sub = p.getString(Prefs.SUBNICHE, "");
                    String cmd = "üretime başla | niş: " + niche + " | alt niş: " + sub;
                    sendText(root, cmd, AutomationState.WAIT_PRODUCT, false);
                    break;
                case AutomationState.WAIT_PRODUCT:
                    waitProduct(root, dump);
                    break;
                case AutomationState.ERROR:
                case AutomationState.IDLE:
                default:
                    break;
            }
        } catch (Throwable t) {
            fail("Otomasyon hatası", t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage()));
        }
    }

    private void openChat(AccessibilityNodeInfo root, String title, String nextState) {
        AccessibilityNodeInfo chat = NodeUtil.findTextLoose(root, title);
        if (chat != null && NodeUtil.click(chat)) {
            transition(nextState, "Sohbet açıldı: " + title);
            return;
        }
        if (elapsed() > 35_000) {
            fail("Sohbet bulunamadı", title + " sohbeti yan menüde bulunamadı. ChatGPT arayüzü değişmiş olabilir.");
            return;
        }
        if (NodeUtil.openDrawerFallback(this, root)) {
            handler.removeCallbacks(processRunnable);
            handler.postDelayed(processRunnable, 1200);
        }
    }

    private void sendText(AccessibilityNodeInfo root, String text, String nextState, boolean nicheStep) {
        AccessibilityNodeInfo input = NodeUtil.findEditable(root);
        if (input == null) {
            if (elapsed() > 18_000) fail("Mesaj alanı bulunamadı", "ChatGPT arayüzü değişmiş olabilir.");
            return;
        }
        if (!NodeUtil.setText(input, text)) return;
        AccessibilityNodeInfo send = NodeUtil.findByTextOrDescription(root, "gönder", "gonder", "send message", "send");
        if (send != null && NodeUtil.click(send)) {
            SharedPreferences p = Prefs.get(this);
            SharedPreferences.Editor e = p.edit().putString(Prefs.STATE, nextState).putLong(Prefs.LAST_ACTION, System.currentTimeMillis());
            if (!nicheStep) {
                long now = System.currentTimeMillis();
                e.putLong(Prefs.PRODUCT_STARTED, now).putString(Prefs.DOWNLOAD_SNAPSHOT, StorageUtil.snapshot(this));
            }
            e.apply();
            lastState = "";
            NotificationUtil.status(this, statusText(p));
        } else if (elapsed() > 18_000) {
            fail("Gönder düğmesi bulunamadı", "Mesaj yazıldı ancak gönder düğmesi algılanamadı.");
        }
    }

    private void waitNiche(AccessibilityNodeInfo root, String dump) {
        if (NodeUtil.looksGenerating(dump)) return;
        if (elapsed() < 6_000) return;
        String[] parsed = NicheParser.parse(dump);
        if (parsed != null) {
            Prefs.get(this).edit()
                    .putString(Prefs.NICHE, parsed[0])
                    .putString(Prefs.SUBNICHE, parsed[1])
                    .putString(Prefs.STATE, AutomationState.OPEN_FACTORY_CHAT)
                    .putInt(Prefs.ATTEMPTS, 0)
                    .apply();
            lastState = "";
            handler.postDelayed(processRunnable, 600);
            return;
        }
        if (elapsed() > 45_000) fail("Niş okunamadı", "Cevap tamamlandı ancak 'Niş:' ve 'Alt niş:' alanları bulunamadı.");
    }

    private void waitProduct(AccessibilityNodeInfo root, String dump) {
        if (NodeUtil.looksGenerating(dump)) return;
        if (elapsed() < 12_000) return;
        List<AccessibilityNodeInfo> files = NodeUtil.clickableDownloads(root);
        if (!files.isEmpty()) {
            int clicked = 0;
            for (AccessibilityNodeInfo n : files) {
                if (NodeUtil.click(n)) clicked++;
                if (clicked >= 6) break;
            }
            if (clicked > 0) {
                transition(AutomationState.ARCHIVE, "Ürün dosyaları indiriliyor");
                handler.postDelayed(processRunnable, 12_000);
                return;
            }
        }
        if (elapsed() > 180_000) {
            fail("Ürün dosyası bulunamadı", "Yanıt bitmiş görünüyor ancak indirilebilir dosya algılanamadı.");
        }
    }

    private void archiveAndNext() throws Exception {
        SharedPreferences p = Prefs.get(this);
        int seq = p.getInt(Prefs.PRODUCT_SEQ, 1);
        int count = StorageUtil.archiveNewFiles(this, seq, p.getString(Prefs.SUBNICHE, "product"),
                p.getString(Prefs.DOWNLOAD_SNAPSHOT, ""), p.getLong(Prefs.PRODUCT_STARTED, 0L));
        if (count <= 0) {
            if (elapsed() < 45_000) {
                handler.postDelayed(processRunnable, 8_000);
                return;
            }
            fail("İndirilen dosya bulunamadı", "ChatGPT indirme klasöründe bu ürüne ait yeni dosya görünmedi.");
            return;
        }
        p.edit()
                .putInt(Prefs.PRODUCT_SEQ, seq + 1)
                .putString(Prefs.STATE, AutomationState.OPEN_NICHE_CHAT)
                .remove(Prefs.NICHE).remove(Prefs.SUBNICHE)
                .putInt(Prefs.ATTEMPTS, 0)
                .apply();
        lastState = "";
        NotificationUtil.status(this, "P" + String.format("%04d", seq) + " kaydedildi · sıradaki ürün hazırlanıyor");
        handler.postDelayed(processRunnable, 900);
    }

    private void transition(String state, String note) {
        Prefs.get(this).edit().putString(Prefs.STATE, state).putLong(Prefs.LAST_ACTION, System.currentTimeMillis()).apply();
        lastState = "";
        NotificationUtil.status(this, note);
        handler.postDelayed(processRunnable, 700);
    }

    private void fail(String title, String detail) {
        Prefs.get(this).edit().putString(Prefs.STATE, AutomationState.ERROR).putBoolean(Prefs.PAUSED, true).putString(Prefs.LAST_ERROR, detail).apply();
        lastState = AutomationState.ERROR;
        NotificationUtil.status(this, "Durdu · müdahale gerekiyor");
        NotificationUtil.alert(this, title, detail);
    }

    private long elapsed() {
        if (stateEntered == 0) stateEntered = System.currentTimeMillis();
        return System.currentTimeMillis() - stateEntered;
    }


    private String backgroundStatusText(SharedPreferences p) {
        if (!p.getBoolean(Prefs.ENABLED, false)) return "Kapalı";
        if (p.getBoolean(Prefs.PAUSED, false)) return "Duraklatıldı";
        int seq = p.getInt(Prefs.PRODUCT_SEQ, 1);
        return "P" + String.format("%04d", seq) + " · arka planda hazır";
    }

    private String statusText(SharedPreferences p) {
        if (!p.getBoolean(Prefs.ENABLED, false)) return "Kapalı";
        if (p.getBoolean(Prefs.PAUSED, false)) return "Duraklatıldı";
        String s = p.getString(Prefs.STATE, AutomationState.IDLE);
        int seq = p.getInt(Prefs.PRODUCT_SEQ, 1);
        return "P" + String.format("%04d", seq) + " · " + pretty(s);
    }

    private String pretty(String s) {
        switch (s) {
            case AutomationState.OPEN_NICHE_CHAT: return "Niş sohbeti";
            case AutomationState.SEND_NICHE: return "Niş komutu";
            case AutomationState.WAIT_NICHE_REPLY: return "Niş bekleniyor";
            case AutomationState.OPEN_FACTORY_CHAT: return "Fabrika sohbeti";
            case AutomationState.SEND_FACTORY: return "Üretim başlatılıyor";
            case AutomationState.WAIT_PRODUCT: return "Ürün üretiliyor";
            case AutomationState.ARCHIVE: return "Dosyalar kaydediliyor";
            case AutomationState.ERROR: return "Hata";
            default: return s;
        }
    }
}
