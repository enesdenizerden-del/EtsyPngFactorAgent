package com.deniz.etsypngfactory;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class ControlReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String a = intent.getAction();
        SharedPreferences p = Prefs.get(context);
        if ("OPEN_CHATGPT".equals(a)) {
            if (!AppLauncher.openChatGPT(context)) {
                NotificationUtil.alert(context, "ChatGPT açılamadı", "ChatGPT uygulaması başlatılamadı.");
            }
        } else if ("STOP".equals(a)) {
            p.edit().putBoolean(Prefs.ENABLED, false).putBoolean(Prefs.PAUSED, false).putString(Prefs.STATE, AutomationState.IDLE).apply();
            NotificationUtil.clearStatus(context);
        } else if ("PAUSE".equals(a)) {
            p.edit().putBoolean(Prefs.PAUSED, true).apply();
            NotificationUtil.status(context, "Duraklatıldı — uygulamayı açarak devam ettir");
        } else if ("LIMIT_WAKE".equals(a)) {
            if (!p.getBoolean(Prefs.ENABLED, false)) return;
            String resume = p.getString(Prefs.LIMIT_RESUME_STATE, AutomationState.WAIT_PRODUCT);
            p.edit().putBoolean(Prefs.PAUSED, false).putString(Prefs.STATE, resume).putBoolean(Prefs.AFTER_LIMIT, true).apply();
            NotificationUtil.status(context, "Limit beklemesi bitti · arka planda hazır");
            FactoryAccessibilityService.kickIfVisible();
        }
    }
}
